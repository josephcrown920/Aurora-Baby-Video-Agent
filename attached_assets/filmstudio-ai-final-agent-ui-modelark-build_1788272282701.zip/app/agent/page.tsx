"use client";
import {useState} from "react";

const nav=["Agent","Projects","Storyboard","Characters","Assets","Models","Render"];
const models=[
 ["Seedance 2.5","BytePlus","Video"],
 ["Seedream 4.5","BytePlus","Image"],
 ["Veo 3.1","Google","Video"],
 ["Kling 3.0","Kling","Video"],
 ["Runway Gen-4.5","Runway","Video"],
];

export default function AgentPage(){
 const [brief,setBrief]=useState("");
 const [running,setRunning]=useState(false);
 const [message,setMessage]=useState("");
 async function create(){
   if(!brief.trim())return;
   setRunning(true);setMessage("Planning production…");
   try{
    const r=await fetch("/api/modelark/responses",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({input:[{role:"user",content:[{type:"input_text",text:
       `Create a complete video production plan. Include characters, storyboard, shots, camera, behavior, continuity and model recommendations.\n\n${brief}`}]}]})});
    if(!r.ok)throw new Error("Agent request failed");
    setMessage("Production plan ready");
   }catch(e){setMessage("Configure ModelArk to run the agent");}
   finally{setRunning(false)}
 }
 return <main className="min-h-screen bg-[#f6f7f9] text-[#111318]">
  <div className="flex min-h-screen">
   <aside className="w-[248px] bg-white border-r border-black/5 p-5 hidden md:block">
    <div className="text-xl font-semibold tracking-tight mb-8">FilmStudio</div>
    <div className="space-y-1">{nav.map((x,i)=><div key={x} className={`px-3 py-2.5 rounded-xl text-sm ${i===0?"bg-black text-white":"text-black/60 hover:bg-black/5"}`}>{x}</div>)}</div>
    <div className="mt-auto pt-12">
      <div className="text-[11px] uppercase tracking-widest text-black/35 mb-2">AI stack</div>
      <div className="rounded-2xl border border-black/5 p-3 bg-[#fafafa]">
       <div className="flex justify-between text-xs"><span>ModelArk</span><span className="text-emerald-600">● Ready</span></div>
       <div className="flex justify-between text-xs mt-2"><span>Seedream</span><span className="text-emerald-600">● Ready</span></div>
       <div className="flex justify-between text-xs mt-2"><span>Seedance</span><span className="text-amber-600">● Config</span></div>
      </div>
    </div>
   </aside>
   <section className="flex-1">
    <header className="h-16 bg-white border-b border-black/5 flex items-center justify-between px-5 md:px-8">
      <div className="font-medium">Individual Agent</div>
      <div className="flex gap-2"><button className="px-3 py-2 rounded-lg border text-xs">Models</button><button className="px-3 py-2 rounded-lg bg-black text-white text-xs">New production</button></div>
    </header>
    <div className="max-w-6xl mx-auto p-5 md:p-10">
      <div className="grid lg:grid-cols-[1.4fr_.6fr] gap-6">
       <div className="bg-white rounded-3xl border border-black/5 p-7 shadow-sm">
        <div className="text-xs uppercase tracking-[.2em] text-black/35 mb-3">Autonomous video agent</div>
        <h1 className="text-4xl md:text-5xl font-semibold tracking-[-.04em] leading-tight">Turn an idea into a finished film.</h1>
        <p className="text-black/50 mt-4 max-w-xl">Research, script, storyboard, characters, camera direction, generation, continuity, QA and final render — orchestrated as one production.</p>
        <textarea value={brief} onChange={e=>setBrief(e.target.value)} placeholder="Describe the video you want to make…" className="mt-7 w-full min-h-40 rounded-2xl bg-[#f7f7f8] border-0 p-5 outline-none resize-none text-sm"/>
        <div className="flex items-center justify-between mt-4"><span className="text-xs text-black/40">{message||"ModelArk brain → Seedream → Seedance → QA → Render"}</span><button onClick={create} disabled={running||!brief.trim()} className="px-5 py-3 rounded-xl bg-black text-white text-sm disabled:opacity-30">{running?"Planning…":"Create production"}</button></div>
       </div>
       <div className="space-y-4">
        <div className="bg-white rounded-3xl border border-black/5 p-6"><div className="font-medium mb-5">Production pipeline</div>{["Brief & research","Character Bible","Storyboard & camera","Seedream references","Seedance shots","Continuity QA","Final render"].map((x,i)=><div className="flex gap-3 items-center py-2 text-sm" key={x}><span className={`w-2 h-2 rounded-full ${i<1?"bg-black":"bg-black/15"}`}/>{x}<span className="ml-auto text-[11px] text-black/30">{i<1?"READY":"AUTO"}</span></div>)}</div>
        <div className="bg-white rounded-3xl border border-black/5 p-6"><div className="font-medium mb-4">Model routing</div>{models.map(m=><div className="flex justify-between py-2 text-xs" key={m[0]}><span>{m[0]}</span><span className="text-black/35">{m[1]} · {m[2]}</span></div>)}</div>
       </div>
      </div>
    </div>
   </section>
  </div>
 </main>
