# FilmStudio AI — All-in-One Individual Video Agent

## Goal

An independent individual autonomous video agent whose **capability baseline is the current
InVideo product**, with the agent operating across the entire production workspace.

## One-pass architecture

**User brief**
→ intent
→ producer plan
→ script
→ storyboard
→ shots
→ generated/stock assets
→ voice/music/SFX
→ Slate timeline
→ captions/translation
→ QA
→ targeted revision
→ render
→ platform variants

## Included in this ZIP

- Agent brain and production planning
- Capability parity matrix
- Product architecture
- FAL / Replicate / Vast GPU provider adapters
- Provider/model registry and scoring
- Generation runtime/job contract
- Project API and local persistence
- Natural-language editor command API
- Slate-style editor prototype
- Notebook concept
- Stock/URL/repurpose/QA API surfaces
- Feature registry covering the full product surface
- Workbench navigation
- Docker configuration
- Environment templates
- Production infrastructure map

## Real infrastructure

Third-party credentials and infrastructure are external dependencies. Configure the
provider environment variables and production services listed in `PRODUCTION_ROADMAP.md`.

The ZIP is source code, not a claim that external SaaS accounts, licensed media catalogs,
GPU instances, databases or payment accounts have been provisioned.
