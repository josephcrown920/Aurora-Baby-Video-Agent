import {NextResponse} from "next/server";
const keys=["FAL_KEY","REPLICATE_API_TOKEN","BYTEPLUS_API_KEY","VAST_API_KEY","DATABASE_URL","REDIS_URL","S3_BUCKET","AUTH_SECRET"];
export async function GET(){
 const status=Object.fromEntries(keys.map(k=>[k,Boolean(process.env[k])]));
 const ready=Object.values(status).every(Boolean);
 return NextResponse.json({ready,status,required:keys});
}
