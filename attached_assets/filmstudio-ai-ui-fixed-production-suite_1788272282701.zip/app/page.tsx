"use client";

import { useEffect, useState } from "react";
import type { VideoProject } from "../lib/types";

const nav = [
  ["▣", "Workspace"], ["✣", "Workbench"], ["✂", "Editor"],
  ["", ""], ["✣", "Capabilities"], ["▦", "Coverage map"]
];

export default function Home() {
  const [projects, setProjects] = useState<VideoProject[]>([]);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [showBrief, setShowBrief] = useState(false);

  async function refresh() {
    try { const r = await fetch("/api/projects"); if (r.ok) setProjects(await r.json()); } catch {}
  }
  useEffect(() => { refresh(); }, []);

  async function create() {
    if (!prompt.trim()) { setShowBrief(true); return; }
    setBusy(true);
    try {
      const r = await fetch("/api/projects", {method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({prompt,name:prompt.slice(0,48),durationSeconds:60,aspectRatio:"16:9",tone:"cinematic",language:"English"})});
      if (r.ok) { const p=await r.json(); window.location.href=`/projects/${p.id}`; }
    } finally { setBusy(false); }
  }

  return <main className="studio-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">◉</div><div><strong>FilmStudio</strong><span>AUTONOMOUS VIDEO</span></div></div>
      <div className="nav-label">DIRECTING DESK</div>
      <nav>{nav.map(([icon,label],i)=>label ? <a key={label} className={label==="Workspace"?"active":""} href={label==="Editor"?"/editor":"#"}><b>{icon}</b>{label}{label==="Workbench"&&<em>LIVE</em>}</a> : <div key={i} className="nav-gap" />)}</nav>
      <div className="plan-card"><div className="plan-title">STUDIO PLAN <strong>04 / 10</strong></div><div className="plan-bar"><i/></div><small>6 productions remaining</small></div>
    </aside>

    <section className="workspace">
      <header className="topbar"><div><div className="date">TUESDAY · 18 JUNE 2024</div><h1>Good morning, Mira.</h1></div><div className="top-actions"><button className="new-btn" onClick={()=>setShowBrief(v=>!v)}>＋ New production</button><button className="icon-btn">♧</button></div></header>

      {showBrief && <section className="brief card"><div className="eyebrow">NEW PRODUCTION</div><h2>Start with the messy bit.</h2><p>Give the agent a direction. It will find the shape.</p><textarea autoFocus value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="A two-minute film about a signal that only appears when everyone is asleep…" />
        <div className="brief-foot"><span>✣ Agent-ready briefs can be rough, poetic, or precise.</span><button onClick={create}>{busy?"Planning…":"Start planning →"}</button></div></section>}

      <div className="dashboard-grid">
        <section className="main-column">
          <div className="hero-card"><div className="hero-overlay"><span className="status">● IN PRODUCTION</span><span className="code">FS / 001</span><div className="hero-copy"><div className="eyebrow">CURRENT PRODUCTION</div><div className="hero-title">The Last Frequency</div><div className="meta">00:44　·　2.39:1　·　quiet / speculative</div></div></div></div>
          <div className="readiness card"><div><span>Production readiness</span><strong>68%</strong></div><div className="progress"><i/></div><button onClick={()=>window.location.href="/editor"}>Open workbench　→</button></div>
          <div className="section-head"><h3>Recent projects</h3><a href="#">View archive →</a></div>
          <div className="project-list">{(projects.length?projects:[{id:"1",name:"A Field Guide to Quiet",status:"delivered",scenes:[1],durationSeconds:72},{id:"2",name:"Moss / Memory",status:"draft",scenes:[1,2],durationSeconds:38},{id:"3",name:"Northbound",status:"delivered",scenes:[1,2],durationSeconds:124} as any]).slice(0,6).map((p:any,i)=><a key={p.id} href={`/projects/${p.id}`} className="project-row"><div className={`thumb t${i%3}`}>▦</div><div className="project-name"><strong>{p.name}</strong><span>{i===0?"observational · 01:12":i===1?"textural / warm · 00:38":"restless / human · 02:04"}</span></div><span className={`tag ${p.status}`}>● {String(p.status).toUpperCase()}</span><small>{i===0?"18 Jun":i===1?"04 Jun":"22 May"}</small><b>•••</b></a>)}</div>
        </section>

        <aside className="right-column">
          <div className="stats"><div className="stat card"><span>SCENES</span><strong>03</strong><small>8 shots mapped</small></div><div className="stat card"><span>GENERATED</span><strong>04:18</strong><small>of 12:40 compute</small></div><div className="stat card"><span>ASSETS</span><strong>24</strong><small>18 approved</small></div><div className="stat card"><span>HEALTH</span><strong>Good</strong><small>No blocked jobs</small></div></div>
          <div className="section-head agent-head"><h3>Agent health</h3></div>
          <div className="health card"><div className="health-title"><span>⌁</span><strong>All systems in rhythm</strong><em>● HEALTHY</em></div><small>Last checked 38 seconds ago</small><hr/><div><span>Planning agent</span><b>● Ready</b></div><div><span>Generation queue</span><b className="warn">● 2 jobs active</b></div><div><span>Asset indexing</span><b>● Up to date</b></div></div>
        </aside>
      </div>
    </section>
  </main>;
}
