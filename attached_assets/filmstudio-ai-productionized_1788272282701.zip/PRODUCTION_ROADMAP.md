# All-in-one implementation map

This release consolidates the prototype into one product architecture.

## Runtime layers

1. Next.js application
2. Individual AI agent/orchestrator
3. Provider router
4. Async job queue contract
5. Media asset store contract
6. Timeline/editor state
7. QA/revision engine
8. Render/export worker contract
9. Usage/credits contract
10. Auth/billing/webhook contracts

## Model execution

FAL, Replicate and Vast GPU/ComfyUI are peers behind the same normalized interface.
A production worker can run jobs asynchronously and emit progress events.

## Editor

The project model is the source of truth. The agent edits the same timeline the user edits.
Natural-language changes become timeline mutations or targeted generation jobs.

## Production dependencies to configure

- FAL credentials/model endpoints
- Replicate token/model versions
- Vast GPU ComfyUI API
- Postgres
- Redis
- S3-compatible object storage
- FFmpeg worker
- authentication provider
- payment provider
- licensed stock provider
- transcription/translation provider

No proprietary InVideo source code is copied. This is an independent implementation
of the publicly described capability model.
