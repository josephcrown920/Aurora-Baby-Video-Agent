import {describe,it,expect} from "vitest"; import {compileShot} from "../lib/camera-compiler";
describe("camera compiler",()=>it("keeps camera intent",()=>{const x=compileShot({subject:"actor",action:"walk",environment:"street",camera:{angle:"low-angle",lensMm:35,movement:"tracking"}});expect(x).toContain("35mm");expect(x).toContain("low-angle");expect(x).toContain("tracking");}));
