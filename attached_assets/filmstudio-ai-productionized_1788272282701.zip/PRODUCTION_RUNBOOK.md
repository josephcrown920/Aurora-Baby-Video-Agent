# Production runbook

## 1. Deploy
Use Node 22 and `npm run build && npm start`, or the included Dockerfile.

## 2. Connect infrastructure
Postgres for durable data, Redis for queues/events, S3-compatible storage for media,
and FFmpeg workers for final rendering.

## 3. Connect AI
FAL and Replicate use the provider adapters. Vast GPU should expose a secured ComfyUI
worker/API. Put model-specific configuration behind the provider registry.

## 4. Long-running jobs
Move generation/render work out of Next.js request handlers into queue workers.
Persist job state and emit progress events.

## 5. Security
Never expose provider secrets to the browser. Add auth, authorization, rate limiting,
signed upload URLs, signed media URLs, moderation and audit logging.

## 6. Billing
Reserve credits before generation, settle on completion, refund failed jobs, and keep
an immutable usage ledger.

## 7. Product parity
Use CURRENT_INVIDEO_BENCHMARK.md and CAPABILITY_MANIFEST.json as the acceptance checklist.
