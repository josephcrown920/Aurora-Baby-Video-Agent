# Model integration guide

## Provider abstraction

Every generation request is normalized:

- modality: video | image | voice | music | sfx | avatar | upscale
- prompt
- negative prompt
- duration
- width / height / FPS
- reference assets
- identity references
- camera specification
- motion specification
- seed
- model preference
- quality / cost budget

The router chooses a model from the registry, then the provider adapter converts this
normalized request into the vendor-specific API payload.

## FAL

Use FAL for hosted image/video/audio models. Configure:
- FAL_KEY
- FAL_MODEL_ENDPOINT or model-specific endpoint registry

The adapter should preserve provider request IDs and output URLs and should support
polling/webhooks for long jobs.

## Replicate

Configure:
- REPLICATE_API_TOKEN
- model/version IDs

Model versions should live in the model registry, not inside UI code.

## Vast GPU + ComfyUI

Vast is the custom execution layer. A Vast GPU worker should expose a secured API that:
1. receives a normalized generation request,
2. selects a ComfyUI workflow,
3. injects prompt/reference/camera/motion parameters,
4. executes the workflow,
5. uploads outputs,
6. returns job ID + output metadata.

Recommended custom workflow families:
- identity-locked character video
- cinematic image-to-video
- performance lip-sync
- controlled camera movement
- multi-shot consistency
- upscaling / restoration
- background replacement

## Future provider adapters

The same contract can support additional vendors without changing the agent:
- text/LLM provider
- TTS provider
- music provider
- stock provider
- transcription/translation provider
- avatar provider
