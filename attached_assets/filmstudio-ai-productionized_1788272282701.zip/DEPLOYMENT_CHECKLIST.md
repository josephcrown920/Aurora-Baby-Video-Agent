# Production deployment checklist

## Application
- [ ] Deploy Next.js app
- [ ] Configure environment secrets
- [ ] Configure domain
- [ ] Enable error monitoring

## Database/storage
- [ ] Postgres
- [ ] S3-compatible object storage
- [ ] Redis

## AI
- [ ] FAL API key + model endpoints
- [ ] Replicate token + model versions
- [ ] Vast GPU instance
- [ ] ComfyUI API/worker
- [ ] Provider webhooks

## Media
- [ ] FFmpeg render workers
- [ ] Thumbnail worker
- [ ] Transcription
- [ ] Translation/dubbing
- [ ] Stock provider/license tracking

## Product
- [ ] Authentication
- [ ] Credits/usage
- [ ] Billing
- [ ] User/project permissions
- [ ] Collaboration
- [ ] Audit log
- [ ] Rate limiting
- [ ] Moderation

## Agent
- [ ] Persistent memory
- [ ] Agent event stream
- [ ] Tool registry
- [ ] Long-running job orchestration
- [ ] Retry/idempotency
- [ ] Cost guardrails
- [ ] QA/revision thresholds
