# FilmStudio AI product architecture

## 01 — Individual Agent

The user speaks to one agent. The agent can invoke specialized internal roles:

- Producer
- Scriptwriter
- Storyboard artist
- Cinematographer
- Editor
- Sound designer
- Music designer
- Colorist
- Caption/translation specialist
- QA/revision specialist

These are orchestration roles, not separate products.

## 02 — Workbench

### Prompt workspace
- natural-language brief
- workflow selection
- platform / duration / aspect ratio
- visual style
- voice / accent / language
- stock vs generated media preference
- quality tier
- budget / credit limit

### Notebook
An individual-generation surface where a user can test a model/shot without losing
project state, then hand the approved output back to the agent.

### Slate
Timeline editor with:
- video/image/audio/text/caption tracks
- clip trim/split/reorder
- transitions/effects
- prompt-based edits
- replace/regenerate shot
- voice/music
- captions
- aspect-ratio variants
- undo/version history

## 03 — Media intelligence

Every asset has:
- source
- provider
- model
- prompt
- seed/request id when available
- duration
- dimensions
- license/source
- project links
- semantic tags
- continuity tags
- cost

This enables the agent to reuse the right asset rather than regenerate it.

## 04 — Provider router

The router scores providers by:
quality, consistency, latency, cost, availability, modality,
resolution, duration, reference-image support, and current queue.

Primary configured layers:
- FAL
- Replicate
- Vast GPU / ComfyUI

Additional providers can be registered without touching the editor.

## 05 — Render pipeline

Render job:
timeline → asset fetch → decode → effects → audio mix → captions →
aspect ratio → codec → QC → object storage → export URL.

## 06 — Persistence

Production target:
- Postgres
- object storage
- Redis
- queue workers
- FFmpeg
- WebSocket/SSE job events

Local prototype uses filesystem storage so it can boot without credentials.

## 07 — Safety and reliability

- provider timeout
- retry policy
- idempotent jobs
- failed-shot isolation
- credit reservation/refund
- asset license tracking
- prompt/version history
- moderation boundary
- audit events
