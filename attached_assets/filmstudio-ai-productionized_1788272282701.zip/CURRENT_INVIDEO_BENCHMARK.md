# Current InVideo benchmark for FilmStudio AI

This document is the product benchmark for the prototype. It is intentionally broader than
"prompt-to-video."

Current InVideo describes Agent One as an agentic workflow that can take a film/brand campaign/
microdrama/performance-ad brief through script, storyboard, generation and editing, routing across
200+ AI models. Its current product also exposes model selection/routing, script-to-video, stock
media, text-prompt editing, avatars/voice clones, image/video/audio tools, templates, timeline
editing, collaboration, repurposing, and Agent Two concepts such as Notebooks, Slate and Stock.

Our prototype therefore treats the following as first-class product domains:

1. Agent brain
2. Projects/workspaces
3. Briefs and workflows
4. Script + storyboard
5. Shots + continuity
6. Multi-model generation
7. Image/video/audio
8. Stock search and agentic stock placement
9. Notebooks for individual model generations
10. Slate-style timeline/editor
11. Natural-language editing / Magic Box
12. Avatars and voice clones
13. Captions/subtitles
14. Translation/dubbing
15. Templates
16. Brand kits
17. Repurposing / platform variants
18. Thumbnails
19. AI enhancement/background removal/face tools
20. QA + autonomous revision
21. Rendering/export
22. Projects/assets/version history
23. Collaboration
24. Credits/usage/billing
25. Provider/model registry
26. GPU worker / ComfyUI execution
27. Observability and job recovery

The target is not to copy proprietary source code. It is to reproduce the capability model and build our
own implementation around open contracts and provider adapters.
