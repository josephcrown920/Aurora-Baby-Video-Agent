# System architecture

Browser
  ↓
Next.js / API
  ↓
Individual Agent Orchestrator
  ├─ Intent + Planner
  ├─ Memory / Bibles
  ├─ Shot & Camera Compiler
  ├─ Model Router
  ├─ Asset/Stock Planner
  ├─ Editor Command Compiler
  └─ QA / Revision Loop
       ↓
Job Queue
  ├─ FAL
  ├─ Replicate
  ├─ Vast GPU / ComfyUI
  ├─ TTS / Music / Avatar
  ├─ Stock
  └─ Render / FFmpeg
       ↓
Object Storage
  ↓
Project Database
  ↓
Slate Timeline
  ↓
QA
  ↓
Render
  ↓
Platform Exports

The key principle is that the Agent and Slate manipulate the same project graph.
