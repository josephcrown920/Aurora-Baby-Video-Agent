# Camera, behavior and shot specification

The agent should never treat a shot prompt as only a paragraph. It should compile a
structured shot specification.

## Camera

### Framing
- extreme wide
- wide
- medium wide
- medium
- medium close-up
- close-up
- extreme close-up
- over-the-shoulder
- POV
- two-shot
- insert/detail

### Lens language
- 14mm ultra-wide
- 18mm wide
- 24mm
- 35mm
- 50mm natural
- 85mm portrait
- 135mm telephoto
- macro

### Camera position
- eye level
- low angle
- high angle
- bird's-eye
- worm's-eye
- Dutch angle
- over-shoulder
- profile
- rear follow
- front tracking

### Movement
- static
- pan
- tilt
- dolly in/out
- truck left/right
- pedestal
- crane
- orbit
- arc
- tracking
- handheld
- whip pan
- rack focus
- push-pull / dolly zoom

### Motion characteristics
- speed
- acceleration
- easing
- handheld intensity
- stabilization
- motion blur
- shutter feel

### Optics
- focal length
- depth of field
- focus target
- aperture look
- bokeh character
- anamorphic/standard feel
- filtration

## Lighting

The shot spec can express:
- key/fill/rim
- source direction
- hard/soft
- color temperature
- practicals
- volumetrics
- haze
- time of day
- exposure mood
- contrast

## Subject behavior

The agent should explicitly plan:
- starting pose
- gaze
- facial expression
- body action
- hand/arm action
- walking/running/dancing
- interaction with props
- interaction with environment
- entrance/exit
- emotional state
- continuity state from previous shot

## Temporal behavior

Every shot can contain:
- beat 0
- beat 1
- beat 2
- ending pose
- transition intent

This gives the video agent an actual behavioral plan rather than relying on one prompt.

## Shot grammar

A shot object should be:

SUBJECT + ACTION + ENVIRONMENT + CAMERA + LENS + LIGHT + MOTION + BEHAVIOR + AUDIO + CONTINUITY + NEGATIVES

Example:

"Artist walks toward camera, confident restrained expression, rain-soaked street at night;
35mm, low-angle medium-wide, slow backward tracking, neon practicals, shallow depth of field;
right hand adjusts jacket at beat 2; ends three steps from lens; preserve wardrobe and face from Shot 03."

## Coverage planner

For narrative scenes, automatically create coverage where useful:
1. establishing
2. master
3. medium
4. close-up
5. detail/insert
6. reaction
7. transition/B-roll

For performance scenes:
1. master
2. frontal medium
3. low-angle hero
4. side profile
5. close-up
6. moving orbit
7. wide environmental
8. detail

The agent should avoid redundant shots unless requested.
