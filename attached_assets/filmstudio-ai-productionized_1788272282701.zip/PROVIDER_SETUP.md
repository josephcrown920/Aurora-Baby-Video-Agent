# Provider setup

## FAL
Set `FAL_KEY` and a model-specific `FAL_MODEL_ENDPOINT`.
The provider adapter sends a normalized generation request and accepts a
queue id/output URL from the configured endpoint.

## Replicate
Set `REPLICATE_API_TOKEN` and `REPLICATE_MODEL`.
The adapter creates a prediction through Replicate's predictions API.

## Vast GPU
Vast is treated as the GPU execution layer rather than a fixed model vendor.
Deploy your preferred ComfyUI/worker/API on a Vast GPU instance and expose a
small authenticated generation endpoint. Set:
- `VAST_API_KEY`
- `VAST_GENERATION_ENDPOINT`
- `VAST_MODEL`

This lets the same agent send expensive/custom jobs to your own GPU fleet.

## Routing strategy

A production router should score:
1. requested capability
2. model quality
3. identity/character consistency
4. motion quality
5. latency
6. estimated cost
7. queue availability

The current implementation provides the provider abstraction and routing seam;
model-specific scoring can be added without changing the editor or project API.
