export type ProviderKind = "video" | "image" | "voice" | "music" | "caption" | "render";

export interface GenerationRequest {
  prompt: string;
  durationSeconds?: number;
  width?: number;
  height?: number;
  referenceAssetIds?: string[];
  inputUrl?: string;
  model?: string;
}

export interface GenerationResult {
  provider: string;
  model: string;
  status: "queued" | "running" | "complete" | "failed";
  outputUrl?: string;
  jobId?: string;
  error?: string;
}

export interface MediaProvider {
  name: string;
  capabilities: ProviderKind[];
  generate(request: GenerationRequest): Promise<GenerationResult>;
}

/**
 * Provider routing is deliberately centralized. The agent can choose a
 * provider/model without coupling project or editor code to vendor APIs.
 */
export class MockMediaProvider implements MediaProvider {
  name = "mock";
  capabilities: ProviderKind[] = ["video","image","voice","music","caption","render"];

  async generate(_request: GenerationRequest): Promise<GenerationResult> {
    return { provider: this.name, model: "mock-v1", status: "complete" };
  }
}

export class FalProvider implements MediaProvider {
  name = "fal";
  capabilities: ProviderKind[] = ["video","image","voice","music","caption","render"];

  async generate(request: GenerationRequest): Promise<GenerationResult> {
    const key = process.env.FAL_KEY;
    if (!key) return { provider:this.name, model:request.model || "auto", status:"failed", error:"FAL_KEY is not configured" };

    // Generic FAL queue boundary. Configure model-specific endpoints through
    // FAL_MODEL_* environment variables rather than hard-coding one vendor model.
    const endpoint = process.env.FAL_MODEL_ENDPOINT;
    if (!endpoint) return { provider:this.name, model:request.model || "auto", status:"failed", error:"FAL_MODEL_ENDPOINT is not configured" };

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {"Content-Type":"application/json","Authorization":`Key ${key}`},
      body: JSON.stringify({
        prompt: request.prompt,
        duration: request.durationSeconds,
        width: request.width,
        height: request.height,
        image_url: request.inputUrl
      })
    });

    if (!response.ok) return { provider:this.name, model:request.model || endpoint, status:"failed", error:`FAL request failed: ${response.status}` };
    const data = await response.json() as { request_id?: string; output?: { url?: string }; video?: { url?: string } };
    return {
      provider:this.name,
      model:request.model || endpoint,
      status:data.output?.url || data.video?.url ? "complete" : "queued",
      jobId:data.request_id,
      outputUrl:data.output?.url || data.video?.url
    };
  }
}

export class ReplicateProvider implements MediaProvider {
  name = "replicate";
  capabilities: ProviderKind[] = ["video","image","voice","music","caption","render"];

  async generate(request: GenerationRequest): Promise<GenerationResult> {
    const token = process.env.REPLICATE_API_TOKEN;
    const model = request.model || process.env.REPLICATE_MODEL;
    if (!token) return { provider:this.name, model:model || "auto", status:"failed", error:"REPLICATE_API_TOKEN is not configured" };
    if (!model) return { provider:this.name, model:"auto", status:"failed", error:"REPLICATE_MODEL is not configured" };

    const response = await fetch("https://api.replicate.com/v1/predictions", {
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`},
      body:JSON.stringify({
        version:model,
        input:{
          prompt:request.prompt,
          duration:request.durationSeconds,
          width:request.width,
          height:request.height,
          image:request.inputUrl
        }
      })
    });

    if (!response.ok) return { provider:this.name, model, status:"failed", error:`Replicate request failed: ${response.status}` };
    const data = await response.json() as { id?:string; status?:string; output?:string|string[] };
    const output = Array.isArray(data.output) ? data.output[0] : data.output;
    return {
      provider:this.name,
      model,
      status:data.status === "succeeded" ? "complete" : "queued",
      jobId:data.id,
      outputUrl:output
    };
  }
}

export class VastGpuProvider implements MediaProvider {
  name = "vast-gpu";
  capabilities: ProviderKind[] = ["video","image","voice","music","caption","render"];

  async generate(request: GenerationRequest): Promise<GenerationResult> {
    const apiKey = process.env.VAST_API_KEY;
    const endpoint = process.env.VAST_GENERATION_ENDPOINT;
    if (!apiKey) return { provider:this.name, model:request.model || "self-hosted", status:"failed", error:"VAST_API_KEY is not configured" };
    if (!endpoint) return { provider:this.name, model:request.model || "self-hosted", status:"failed", error:"VAST_GENERATION_ENDPOINT is not configured" };

    const response = await fetch(endpoint, {
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${apiKey}`},
      body:JSON.stringify({
        prompt:request.prompt,
        duration:request.durationSeconds,
        width:request.width,
        height:request.height,
        input_url:request.inputUrl,
        model:request.model || process.env.VAST_MODEL || "self-hosted"
      })
    });

    if (!response.ok) return { provider:this.name, model:request.model || "self-hosted", status:"failed", error:`Vast GPU endpoint failed: ${response.status}` };
    const data = await response.json() as { job_id?:string; output_url?:string; status?:string };
    return {
      provider:this.name,
      model:request.model || process.env.VAST_MODEL || "self-hosted",
      status:data.output_url ? "complete" : "queued",
      jobId:data.job_id,
      outputUrl:data.output_url
    };
  }
}

export function chooseProvider(kind: ProviderKind, preferred?: string): MediaProvider {
  const order = preferred ? [preferred] : ["fal","replicate","vast-gpu","mock"];
  for (const name of order) {
    if (name === "fal") return new FalProvider();
    if (name === "replicate") return new ReplicateProvider();
    if (name === "vast-gpu") return new VastGpuProvider();
    if (name === "mock") return new MockMediaProvider();
  }
  return new MockMediaProvider();
}
