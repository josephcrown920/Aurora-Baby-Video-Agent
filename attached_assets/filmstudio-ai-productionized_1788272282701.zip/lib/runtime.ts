import { chooseProvider } from "./providers";
import { recommendModel } from "./provider-registry";
import { newJob, type Job } from "./jobs";
import type { Modality } from "./provider-registry";

export interface RuntimeRequest {
  projectId:string;
  prompt:string;
  modality:Modality;
  durationSeconds?:number;
  width?:number;
  height?:number;
  referenceAssetIds?:string[];
  preferredProvider?:string;
}

export function createGenerationJob(req:RuntimeRequest):Job {
  const model=recommendModel(req.modality);
  const provider=chooseProvider(req.modality, req.preferredProvider || model?.provider);
  const job=newJob(req.projectId,"generate");
  job.provider=provider.name;
  job.model=model?.id;
  job.result={prompt:req.prompt,modality:req.modality};
  return job;
}
