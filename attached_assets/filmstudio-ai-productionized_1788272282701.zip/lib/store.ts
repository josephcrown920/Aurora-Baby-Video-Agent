import fs from "node:fs";
import path from "node:path";
import type { GenerationJob, VideoProject } from "./types";

const dir = path.join(process.cwd(), "data");
const projectsFile = path.join(dir, "projects.json");
const jobsFile = path.join(dir, "jobs.json");

function ensure() {
  fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(projectsFile)) fs.writeFileSync(projectsFile, "[]");
  if (!fs.existsSync(jobsFile)) fs.writeFileSync(jobsFile, "[]");
}

function read<T>(file: string): T[] {
  ensure();
  return JSON.parse(fs.readFileSync(file, "utf8")) as T[];
}

function write<T>(file: string, data: T[]) {
  ensure();
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

export const store = {
  projects(): VideoProject[] { return read<VideoProject>(projectsFile); },
  jobs(): GenerationJob[] { return read<GenerationJob>(jobsFile); },
  getProject(id: string) { return this.projects().find(p => p.id === id); },
  saveProject(project: VideoProject) {
    const all = this.projects();
    const i = all.findIndex(p => p.id === project.id);
    if (i >= 0) all[i] = project; else all.unshift(project);
    write(projectsFile, all);
    return project;
  },
  saveJob(job: GenerationJob) {
    const all = this.jobs();
    const i = all.findIndex(j => j.id === job.id);
    if (i >= 0) all[i] = job; else all.unshift(job);
    write(jobsFile, all);
    return job;
  }
};
