export type ProjectStatus = "draft" | "planning" | "generating" | "editing" | "review" | "complete" | "failed";
export type AspectRatio = "16:9" | "9:16" | "1:1" | "4:5";

export interface VideoBrief {
  prompt: string;
  durationSeconds: number;
  aspectRatio: AspectRatio;
  language: string;
  tone: string;
  audience?: string;
  referenceAssetIds: string[];
}

export interface Shot {
  id: string;
  sceneId: string;
  index: number;
  description: string;
  durationSeconds: number;
  camera: string;
  movement: string;
  lighting: string;
  audio: string;
  visualStyle: string;
  provider?: string;
  model?: string;
  assetIds: string[];
  status: "planned" | "queued" | "generating" | "complete" | "failed";
  outputUrl?: string;
}

export interface Scene {
  id: string;
  index: number;
  title: string;
  purpose: string;
  durationSeconds: number;
  shots: Shot[];
}

export interface Script {
  title: string;
  hook: string;
  narration: string[];
  dialogue: string[];
  cta?: string;
}

export interface VideoProject {
  id: string;
  name: string;
  status: ProjectStatus;
  createdAt: string;
  updatedAt: string;
  brief: VideoBrief;
  script: Script;
  scenes: Scene[];
  creditsUsed: number;
}

export interface GenerationJob {
  id: string;
  projectId: string;
  shotId?: string;
  kind: "video" | "image" | "voice" | "music" | "caption" | "render";
  provider: string;
  model: string;
  status: "queued" | "running" | "complete" | "failed";
  createdAt: string;
  outputUrl?: string;
  error?: string;
}
