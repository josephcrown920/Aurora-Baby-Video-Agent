import type { AuthAdapter, BillingAdapter, QueueAdapter, RenderAdapter, RenderRequest, RenderResult, StorageAdapter, User } from "./production";
import fs from "node:fs/promises";
import path from "node:path";

export class LocalStorage implements StorageAdapter {
  root=path.join(process.cwd(),"data","assets");
  async put(key:string,data:Buffer,contentType:string){void contentType;const p=path.join(this.root,key);await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,data);return `/api/assets/${encodeURIComponent(key)}`;}
  async get(key:string){return fs.readFile(path.join(this.root,key));}
  async delete(key:string){await fs.rm(path.join(this.root,key),{force:true});}
}
export class LocalQueue implements QueueAdapter {
  async enqueue<T>(_name:string,_payload:T){return crypto.randomUUID();}
}
export class LocalBilling implements BillingAdapter {
  async reserveCredits(_userId:string,_amount:number){return true;}
  async refundCredits(_userId:string,_amount:number){return;}
}
export class DevAuth implements AuthAdapter {
  async getUser(_token:string):Promise<User|null>{return {id:"dev-user",email:"dev@filmstudio.local",plan:"pro",credits:10000};}
}
export class RenderStub implements RenderAdapter {
  async render(_req:RenderRequest):Promise<RenderResult>{return {jobId:crypto.randomUUID(),status:"queued"};}
}
