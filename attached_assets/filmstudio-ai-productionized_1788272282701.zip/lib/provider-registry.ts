export type Modality = "video"|"image"|"voice"|"music"|"sfx"|"caption"|"upscale"|"render"|"avatar";

export interface ModelProfile {
  id:string;
  provider:string;
  modalities:Modality[];
  quality:number;
  consistency:number;
  latency:number;
  cost:number;
  maxDuration?:number;
  supportsReferences?:boolean;
  supportsAudio?:boolean;
}

export const MODEL_REGISTRY: ModelProfile[] = [
  {id:"fal-auto",provider:"fal",modalities:["video","image","voice","music","sfx"],quality:.88,consistency:.86,latency:.45,cost:.50,supportsReferences:true},
  {id:"replicate-auto",provider:"replicate",modalities:["video","image","voice","music"],quality:.84,consistency:.82,latency:.55,cost:.55,supportsReferences:true},
  {id:"vast-comfyui",provider:"vast-gpu",modalities:["video","image","voice","music","sfx","upscale","render","avatar"],quality:.95,consistency:.95,latency:.70,cost:.30,supportsReferences:true,supportsAudio:true}
];

export function recommendModel(modality:Modality, constraints:Partial<ModelProfile>={}) {
  const candidates = MODEL_REGISTRY.filter(m=>m.modalities.includes(modality));
  return candidates.sort((a,b)=>{
    const sa=(a.quality*.35+a.consistency*.30+(1-a.latency)*.10+(1-a.cost)*.15+(a.supportsReferences? .10:0));
    const sb=(b.quality*.35+b.consistency*.30+(1-b.latency)*.10+(1-b.cost)*.15+(b.supportsReferences? .10:0));
    return sb-sa;
  })[0];
}
