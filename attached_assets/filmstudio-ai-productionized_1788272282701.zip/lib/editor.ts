export interface TimelineClip {
  id: string;
  trackId: string;
  sourceUrl?: string;
  start: number;
  duration: number;
  trimStart: number;
  trimEnd: number;
  type: "video"|"image"|"audio"|"text"|"caption";
  effects: string[];
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: "video"|"audio"|"text"|"caption";
  clips: TimelineClip[];
}

export interface EditorState {
  duration: number;
  fps: number;
  width: number;
  height: number;
  tracks: TimelineTrack[];
  currentTime: number;
}

export const DEFAULT_EDITOR: EditorState = {
  duration: 60, fps: 30, width: 1920, height: 1080, currentTime: 0,
  tracks: [
    {id:"v1",name:"Video",type:"video",clips:[]},
    {id:"t1",name:"Text",type:"text",clips:[]},
    {id:"c1",name:"Captions",type:"caption",clips:[]},
    {id:"a1",name:"Audio",type:"audio",clips:[]}
  ]
};

export function addClip(state: EditorState, trackId: string, clip: TimelineClip): EditorState {
  return {...state, tracks:state.tracks.map(t=>t.id===trackId?{...t,clips:[...t.clips,clip]}:t)};
}
