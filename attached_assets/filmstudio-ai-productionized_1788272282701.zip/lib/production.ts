export interface User { id:string; email:string; plan:"free"|"pro"|"business"; credits:number; }
export interface Asset { id:string; projectId:string; kind:"video"|"image"|"audio"|"font"|"logo"; url:string; provider?:string; model?:string; metadata:Record<string,unknown>; }
export interface RenderRequest { projectId:string; format:"mp4"; width:number; height:number; fps:number; quality:"draft"|"standard"|"high"; }
export interface RenderResult { jobId:string; status:"queued"|"running"|"complete"|"failed"; outputUrl?:string; }
export interface StorageAdapter { put(key:string,data:Buffer,contentType:string):Promise<string>; get(key:string):Promise<Buffer>; delete(key:string):Promise<void>; }
export interface QueueAdapter { enqueue<T>(name:string,payload:T):Promise<string>; }
export interface BillingAdapter { reserveCredits(userId:string,amount:number):Promise<boolean>; refundCredits(userId:string,amount:number):Promise<void>; }
export interface AuthAdapter { getUser(token:string):Promise<User|null>; }
export interface RenderAdapter { render(req:RenderRequest):Promise<RenderResult>; }
