export type Intent =
  | "create_video" | "edit_video" | "generate_asset" | "repurpose"
  | "script" | "storyboard" | "caption" | "voice" | "music" | "unknown";

export type Capability =
  | "reasoning" | "script" | "storyboard" | "asset_planning" | "video"
  | "image" | "voice" | "music" | "editing" | "caption" | "qa" | "revision" | "render";

export interface AgentContext {
  prompt: string;
  projectId?: string;
  userId?: string;
  constraints: Record<string, unknown>;
}

export interface PlanStep {
  id: string;
  action: string;
  capability: Capability;
  input: Record<string, unknown>;
  dependsOn: string[];
  status: "pending" | "running" | "complete" | "failed";
  attempts: number;
  maxAttempts: number;
}

export interface AgentPlan {
  intent: Intent;
  objective: string;
  assumptions: string[];
  steps: PlanStep[];
  qualityGates: string[];
}

const id = () => crypto.randomUUID();

export function classifyIntent(prompt: string): Intent {
  const p = prompt.toLowerCase();
  if (/(edit|trim|cut|remove|replace|change).*video/.test(p)) return "edit_video";
  if (/(caption|subtitle)/.test(p)) return "caption";
  if (/(voice|voiceover|narration)/.test(p)) return "voice";
  if (/(music|soundtrack|score|sfx)/.test(p)) return "music";
  if (/(script|write).*video/.test(p)) return "script";
  if (/storyboard/.test(p)) return "storyboard";
  if (/(image|poster|thumbnail|asset)/.test(p)) return "generate_asset";
  if (/(shorts|reel|tiktok|repurpose|clip)/.test(p)) return "repurpose";
  if (/(video|film|commercial|ad|documentary|explainer)/.test(p)) return "create_video";
  return "unknown";
}

export function buildPlan(ctx: AgentContext): AgentPlan {
  const intent = classifyIntent(ctx.prompt);
  const steps: PlanStep[] = [];

  const add = (action: string, capability: Capability, input: Record<string, unknown> = {}, dependsOn: string[] = [], maxAttempts = 2) => {
    const step: PlanStep = { id:id(), action, capability, input, dependsOn, status:"pending", attempts:0, maxAttempts };
    steps.push(step);
    return step.id;
  };

  const understand = add("understand brief", "reasoning", {prompt:ctx.prompt});
  const script = add("create or refine script", "script", {}, [understand]);
  const board = add("create storyboard and shot list", "storyboard", {}, [script]);
  const assets = add("plan and gather assets", "asset_planning", {}, [board]);
  const shots = add("generate video shots", "video", {}, [assets]);
  const stills = add("generate supporting images", "image", {}, [assets]);
  const audio = add("generate voice, music and sound", "voice", {}, [script]);
  const music = add("generate music and SFX", "music", {}, [script]);
  const edit = add("assemble and edit timeline", "editing", {}, [shots, stills, audio, music]);
  const captions = add("create and style captions", "caption", {}, [edit]);
  const qa = add("inspect continuity, pacing and quality", "qa", {}, [edit, captions]);
  const revise = add("regenerate weak shots and repair edit", "revision", {}, [qa]);
  const render = add("render final outputs", "render", {}, [revise]);

  if (intent === "caption") {
    return {
      intent, objective:"Create accurate captions for supplied media.", assumptions:[],
      steps:[understand, captions], qualityGates:["timing","readability"]
    };
  }

  if (intent === "repurpose") {
    return {
      intent, objective:"Repurpose source content into platform-specific cuts.",
      assumptions:["Preserve key message.","Reframe rather than simply crop.","Generate multiple output ratios."],
      steps:[understand, edit, captions, qa, render],
      qualityGates:["hook in first seconds","safe zones","captions","platform aspect ratio"]
    };
  }

  return {
    intent,
    objective:ctx.prompt,
    assumptions:[
      "Use configured provider routing.",
      "Preserve references and project continuity.",
      "Prefer the highest-scoring result within configured budget."
    ],
    steps:[understand,script,board,assets,shots,stills,audio,music,edit,captions,qa,revise,render],
    qualityGates:[
      "identity consistency","visual continuity","audio sync",
      "caption timing","resolution/aspect ratio","no failed generation jobs"
    ]
  };
}

export function nextRunnableSteps(plan: AgentPlan): PlanStep[] {
  return plan.steps.filter(s =>
    s.status === "pending" &&
    s.dependsOn.every(dep => plan.steps.find(x => x.id === dep)?.status === "complete")
  );
}

export function scoreProvider(input: {
  quality:number; cost:number; latency:number; consistency:number; availability:number;
}) {
  return input.quality*0.35 + input.consistency*0.30 + input.availability*0.20
    + (1-input.cost)*0.10 + (1-input.latency)*0.05;
}
