export type JobStatus="queued"|"running"|"complete"|"failed"|"cancelled";

export interface Job {
  id:string;
  projectId:string;
  stepId?:string;
  type:"generate"|"stock_search"|"edit"|"caption"|"translate"|"render"|"qa";
  provider?:string;
  model?:string;
  result?:Record<string,unknown>;
  status:JobStatus;
  progress:number;
  attempts:number;
  maxAttempts:number;
  createdAt:string;
  updatedAt:string;
  error?:string;
  result?:Record<string,unknown>;
}

export function newJob(projectId:string,type:Job["type"]):Job {
  const now=new Date().toISOString();
  return {id:crypto.randomUUID(),projectId,type,status:"queued",progress:0,attempts:0,maxAttempts:3,createdAt:now,updatedAt:now};
}
