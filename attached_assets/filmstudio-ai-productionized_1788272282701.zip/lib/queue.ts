import Redis from "ioredis";
export const redis=process.env.REDIS_URL?new Redis(process.env.REDIS_URL):null;
export async function enqueueJob(queue:string,payload:unknown){if(!redis)throw new Error("REDIS_URL is not configured");const id=crypto.randomUUID();await redis.lpush(`queue:${queue}`,JSON.stringify({id,payload,createdAt:new Date().toISOString()}));return id;}
export async function publishProgress(jobId:string,event:Record<string,unknown>){if(redis)await redis.publish(`job:${jobId}`,JSON.stringify(event));}
