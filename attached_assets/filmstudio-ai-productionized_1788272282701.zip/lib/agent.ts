import type { Scene, Script, VideoBrief, VideoProject } from "./types";

const id = () => crypto.randomUUID();

function deterministicPlan(brief: VideoBrief): { script: Script; scenes: Scene[] } {
  const title = brief.prompt.split(/[.!?]/)[0].slice(0, 70) || "Untitled video";
  const duration = Math.max(15, brief.durationSeconds);
  const sceneDurations = [
    Math.max(3, Math.round(duration * 0.12)),
    Math.max(5, Math.round(duration * 0.28)),
    Math.max(5, Math.round(duration * 0.42)),
    Math.max(3, duration - Math.round(duration * 0.82))
  ];

  const sceneTitles = ["Hook", "Build", "Main story", "Resolution"];
  const scenes = sceneTitles.map((sceneTitle, index) => {
    const sceneId = id();
    const d = sceneDurations[index];
    const shots: Scene["shots"] = [];
    const shotCount = index === 2 ? 3 : 2;

    for (let s = 0; s < shotCount; s++) {
      shots.push({
        id: id(),
        sceneId,
        index: s + 1,
        description: `${sceneTitle}: visually communicate "${brief.prompt}" with clear subject continuity.`,
        durationSeconds: Math.max(2, Math.round(d / shotCount)),
        camera: s === 0 ? "wide establishing" : "medium close-up",
        movement: s === 0 ? "slow push-in" : "controlled tracking",
        lighting: "motivated cinematic lighting",
        audio: index === 0 ? "music + hook" : "music + natural ambience",
        visualStyle: brief.tone || "cinematic",
        assetIds: [],
        status: "planned"
      });
    }

    return {
      id: sceneId,
      index: index + 1,
      title: sceneTitle,
      purpose: `${sceneTitle} for the requested video`,
      durationSeconds: d,
      shots
    };
  });

  return {
    script: {
      title,
      hook: `Open immediately with a strong visual tied to: ${brief.prompt}`,
      narration: [`Introduce the premise: ${brief.prompt}`, "Escalate the visual story.", "Resolve with a clear final beat."],
      dialogue: [],
      cta: "End with the requested call to action."
    },
    scenes
  };
}

export async function planVideo(brief: VideoBrief) {
  // The deterministic planner makes the app usable with zero credentials.
  // Production deployments can replace this with an LLM planner while keeping
  // the same Script/Scene/Shot contract.
  return deterministicPlan(brief);
}

export function makeProject(name: string, brief: VideoBrief): VideoProject {
  const plan = deterministicPlan(brief);
  const now = new Date().toISOString();
  return {
    id: id(),
    name,
    status: "draft",
    createdAt: now,
    updatedAt: now,
    brief,
    script: plan.script,
    scenes: plan.scenes,
    creditsUsed: 0
  };
}
