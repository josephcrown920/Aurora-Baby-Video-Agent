export const PRODUCT_FEATURES = [
  "prompt_to_video","script_to_video","url_to_video","image_to_video",
  "ai_images","stock_media","notebook","slate_editor","natural_language_editing",
  "avatars","voice_cloning","voiceover","music","sfx","captions","translation",
  "templates","brand_kits","repurposing","thumbnails","enhancement",
  "background_removal","face_tools","qa","autonomous_revision","render_export",
  "asset_library","projects","versions","collaboration","credits","model_routing",
  "vast_gpu","comfyui"
] as const;

export type ProductFeature=typeof PRODUCT_FEATURES[number];

export interface FeatureStatus {
  feature:ProductFeature;
  status:"prototype"|"adapter"|"production_required";
}

export const FEATURE_STATUS:FeatureStatus[]=PRODUCT_FEATURES.map(feature=>({
  feature,
  status:["prompt_to_video","script_to_video","ai_images","slate_editor","qa","autonomous_revision","model_routing"].includes(feature)
    ? "prototype" : "adapter"
}));
