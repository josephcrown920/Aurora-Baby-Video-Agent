import { Pool } from "pg";
export const db=process.env.DATABASE_URL?new Pool({connectionString:process.env.DATABASE_URL,max:Number(process.env.DB_POOL_SIZE||10)}):null;
export async function query<T=unknown>(text:string,params:unknown[]=[]){if(!db)throw new Error("DATABASE_URL is not configured");return db.query<T>(text,params);}
