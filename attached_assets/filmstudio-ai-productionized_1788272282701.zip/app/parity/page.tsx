const rows = [
["Prompt → video","Agent plan + project creation","FAL / Replicate / Vast"],
["Script","Script plan step","LLM adapter"],
["Storyboard","Scene + shot contracts","LLM adapter"],
["AI video","Shot generation API","FAL / Replicate / Vast"],
["AI images","Asset generation contract","FAL / Replicate / Vast"],
["Voice","Audio capability","Provider adapter"],
["Music / SFX","Audio capability","Provider adapter"],
["Captions","Caption track","Provider adapter"],
["Timeline editor","Editor prototype","Local state"],
["AI revision","QA → revision plan","Generation router"],
["Repurposing","Dedicated intent path","Render adapter"],
["Brand kit","Project feature surface","Asset metadata"],
["Templates","Feature contract","Template registry"],
["Render/export","Render plan","Worker adapter"]
];

export default function Parity() {
  return <main style={{padding:40,maxWidth:1100,margin:"auto"}}><a href="/" style={{color:"inherit"}}>← Workspace</a><h1>Capability parity</h1><p className="muted">Prototype coverage map for the individual autonomous video agent.</p><table style={{width:"100%",borderCollapse:"collapse",marginTop:25}}><thead><tr><th style={{textAlign:"left",padding:12}}>Capability</th><th style={{textAlign:"left",padding:12}}>Agent</th><th style={{textAlign:"left",padding:12}}>Execution layer</th></tr></thead><tbody>{rows.map(r=><tr key={r[0]}>{r.map((c,i)=><td key={i} style={{borderTop:"1px solid #252b33",padding:12,color:i===0?"white":"#aeb6c2"}}>{c}</td>)}</tr>)}</tbody></table></main>;
}
