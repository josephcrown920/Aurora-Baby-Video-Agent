\"use client\";

import { useEffect, useState } from "react";
import type { VideoProject } from "../lib/types";

export default function Home() {
  const [projects, setProjects] = useState<VideoProject[]>([]);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const r = await fetch("/api/projects");
    if (r.ok) setProjects(await r.json());
  }
  useEffect(() => { refresh(); }, []);

  async function create() {
    if (!prompt.trim()) return;
    setBusy(true);
    const r = await fetch("/api/projects", {
      method:"POST",
      headers:{"content-type":"application/json"},
      body: JSON.stringify({ prompt, name: prompt.slice(0, 48), durationSeconds:60, aspectRatio:"16:9", tone:"cinematic", language:"English" })
    });
    setBusy(false);
    if (r.ok) {
      const p = await r.json();
      window.location.href = `/projects/${p.id}`;
    }
  }

  return <main style={{minHeight:"100vh",display:"grid",gridTemplateColumns:"230px 1fr"}}>
    <aside style={{borderRight:"1px solid #20252c",padding:22}}>
      <h2 style={{margin:"4px 0 36px"}}>FilmStudio AI</h2>
      {["Home","Projects","Assets","Templates","Brand Kit","Exports"].map(x=><div key={x} style={{padding:"10px 0",color:"#aeb6c2"}}>{x}</div>)}
    </aside>
    <section style={{padding:"48px 6vw",maxWidth:1100}}>
      <span className="pill">AI VIDEO AGENT</span>
      <h1 style={{fontSize:50,maxWidth:800,lineHeight:1.05,margin:"18px 0 12px"}}>Create a video from one instruction.</h1>
      <p className="muted" style={{fontSize:18,maxWidth:760}}>Plan, storyboard, generate, edit, review and export from one project workspace.</p>
      <div className="card" style={{marginTop:30,padding:18}}>
        <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={6} placeholder="Describe the video you want to make..." style={{width:"100%",background:"transparent",border:0,outline:0,color:"white",fontSize:18,resize:"vertical"}} />
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:12}}>
          <span className="muted">Agent will create the production plan automatically.</span>
          <button disabled={busy} onClick={create} style={{border:0,borderRadius:9,padding:"12px 18px",fontWeight:800}}>{busy?"Planning…":"Create video"}</button>
        </div>
      </div>
      <h3 style={{marginTop:48}}>Recent projects</h3>
      <div style={{display:"flex",gap:10,marginBottom:20}}><a href="/editor" style={{color:"white"}}>Open editor</a><a href="/parity" style={{color:"white"}}>Capability parity</a></div><div style={{display:"grid",gap:12}}>
        {projects.map(p=><a key={p.id} href={`/projects/${p.id}`} className="card" style={{padding:18,textDecoration:"none",color:"inherit"}}><strong>{p.name}</strong><div className="muted" style={{marginTop:6}}>{p.status} · {p.scenes.length} scenes</div></a>)}
      </div>
    </section>
  </main>;
}
