"use client";
import { useState } from "react";

const features = [
  ["AI Director","Turn a brief into a production plan."],
  ["AI Video","Generate and regenerate individual shots."],
  ["AI Images","Create storyboards, thumbnails and assets."],
  ["Voice & Music","Add narration, dialogue, music and SFX."],
  ["AI Editor","Edit by timeline or natural-language instructions."],
  ["Captions","Generate and style subtitles."],
  ["Repurpose","Create Shorts, Reels and multiple aspect ratios."],
  ["Brand Kit","Apply logos, fonts, colors and reusable styles."],
  ["Templates","Start from repeatable production structures."],
  ["QA & Revision","Detect continuity and quality issues before export."],
  ["Render & Export","Prepare platform-specific final outputs."],
  ["Asset Library","Keep generated and uploaded media organized."]
];

export default function Features() {
  const [selected,setSelected]=useState(features[0][0]);
  return <main style={{minHeight:"100vh",padding:40,maxWidth:1100,margin:"auto"}}>
    <a href="/" style={{color:"inherit"}}>← Workspace</a>
    <h1>FilmStudio AI capabilities</h1>
    <p style={{color:"#9da5b2"}}>One workspace for the complete production lifecycle.</p>
    <div style={{display:"grid",gridTemplateColumns:"280px 1fr",gap:20,marginTop:30}}>
      <div>{features.map(([name,desc])=><button key={name} onClick={()=>setSelected(name)} style={{display:"block",width:"100%",textAlign:"left",padding:14,marginBottom:8,background:selected===name?"#1b2028":"#11151b",color:"white",border:"1px solid #282f38",borderRadius:10}}>{name}<div style={{fontSize:12,color:"#8f98a5",marginTop:4}}>{desc}</div></button>)}</div>
      <div className="card" style={{padding:28}}><span className="pill">FEATURE</span><h2>{selected}</h2><p className="muted">This capability is wired to the platform's shared project, asset, agent, provider and render contracts.</p></div>
    </div>
  </main>;
}
