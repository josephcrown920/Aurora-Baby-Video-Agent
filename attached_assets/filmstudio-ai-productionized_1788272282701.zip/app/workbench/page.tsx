"use client";
import { useState } from "react";

const tools=["Agent","Notebook","Slate","Stock","Assets","Templates","Brand Kit","Repurpose","Captions","Voice & Music","Avatars","QA","Export"];

export default function Workbench(){
  const [tab,setTab]=useState("Agent");
  return <main style={{minHeight:"100vh",display:"grid",gridTemplateRows:"64px 48px 1fr"}}>
    <header style={{borderBottom:"1px solid #242a32",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 20px"}}>
      <a href="/" style={{color:"white",textDecoration:"none"}}>FilmStudio AI</a>
      <span className="pill">INDIVIDUAL AGENT</span>
    </header>
    <nav style={{display:"flex",gap:4,padding:"6px 14px",borderBottom:"1px solid #242a32",overflowX:"auto"}}>{tools.map(t=><button key={t} onClick={()=>setTab(t)} style={{whiteSpace:"nowrap",padding:"8px 12px",borderRadius:7,border:"1px solid #2a3038",background:tab===t?"#202630":"#11151b",color:"white"}}>{t}</button>)}</nav>
    <section style={{padding:24,display:"grid",gridTemplateColumns:"1fr 320px",gap:18}}>
      <div className="card" style={{padding:24,minHeight:500}}>
        <span className="pill">{tab.toUpperCase()}</span>
        <h1>{tab}</h1>
        <p className="muted">This is the unified workspace surface. The agent, notebook, editor, stock, assets and export systems share the same project state.</p>
        {tab==="Agent" && <textarea rows={9} placeholder="Tell the agent what to make or change..." style={{width:"100%",background:"#0b0e12",border:"1px solid #292f38",borderRadius:10,color:"white",padding:14,fontSize:16}}/>}
        {tab==="Notebook" && <div className="card" style={{padding:18}}>Model playground — choose a model, test a generation, approve it, and return it to the project.</div>}
        {tab==="Slate" && <div className="card" style={{padding:18}}>Timeline/editor surface — approved shots, audio, text and captions are assembled here.</div>}
        {tab==="Stock" && <div className="card" style={{padding:18}}>Agentic stock search — describe what the scene needs; a licensed stock adapter returns candidate media.</div>}
        {tab==="QA" && <div className="card" style={{padding:18}}>Quality gates — continuity, timing, audio sync, resolution and black-frame checks.</div>}
      </div>
      <aside className="card" style={{padding:20}}>
        <h3>Agent context</h3>
        {["Project memory","Style bible","Character bible","Brand rules","Approved assets","Generation history","Credit budget"].map(x=><div key={x} style={{padding:"11px 0",borderBottom:"1px solid #242a32"}}>{x}<span className="muted" style={{float:"right"}}>linked</span></div>)}
      </aside>
    </section>
  </main>
}
