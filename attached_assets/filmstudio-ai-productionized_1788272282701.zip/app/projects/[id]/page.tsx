\"use client\";

import { useEffect, useState } from "react";
import type { VideoProject } from "../../../lib/types";

export default function ProjectPage({params}:{params:{id:string}}) {
  const [p,setP]=useState<VideoProject|null>(null);
  const [busy,setBusy]=useState(false);

  useEffect(()=>{ fetch(`/api/projects/${params.id}`).then(r=>r.json()).then(setP); },[params.id]);

  async function generate() {
    setBusy(true);
    const r=await fetch(`/api/projects/${params.id}/generate`,{method:"POST"});
    const next=await r.json();
    setP(next.project);
    setBusy(false);
  }

  if(!p) return <main style={{padding:40}}>Loading…</main>;

  return <main style={{minHeight:"100vh",display:"grid",gridTemplateRows:"64px 1fr 220px"}}>
    <header style={{borderBottom:"1px solid #222831",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 22px"}}>
      <a href="/" style={{color:"white",textDecoration:"none"}}>FilmStudio AI</a>
      <div style={{display:"flex",gap:10,alignItems:"center"}}><span className="pill">{p.status}</span><button onClick={generate} disabled={busy} style={{border:0,borderRadius:8,padding:"9px 14px",fontWeight:800}}>{busy?"Generating…":"Generate planned shots"}</button></div>
    </header>
    <section style={{display:"grid",gridTemplateColumns:"280px 1fr 300px",minHeight:0}}>
      <aside style={{borderRight:"1px solid #222831",padding:18,overflow:"auto"}}><h3>Scenes</h3>{p.scenes.map(s=><div key={s.id} className="card" style={{padding:12,marginBottom:10}}><strong>{s.index}. {s.title}</strong><div className="muted" style={{marginTop:5}}>{s.shots.length} shots · {s.durationSeconds}s</div></div>)}</aside>
      <section style={{padding:24,overflow:"auto"}}><div style={{aspectRatio:"16/9",background:"#050608",border:"1px solid #252b33",borderRadius:14,display:"grid",placeItems:"center",color:"#707987"}}>Preview / player surface</div><h2>{p.script.title}</h2><p className="muted">{p.script.hook}</p></section>
      <aside style={{borderLeft:"1px solid #222831",padding:18,overflow:"auto"}}><h3>Agent plan</h3><p className="muted">Brief</p><div>{p.brief.prompt}</div><p className="muted" style={{marginTop:22}}>Aspect ratio</p><div>{p.brief.aspectRatio}</div><p className="muted" style={{marginTop:22}}>Tone</p><div>{p.brief.tone}</div></aside>
    </section>
    <section style={{borderTop:"1px solid #222831",padding:16,overflow:"auto"}}><div style={{display:"flex",gap:8,minWidth:900}}>{p.scenes.flatMap(s=>s.shots).map((shot,i)=><div key={shot.id} className="card" style={{minWidth:170,padding:12}}><strong>Shot {i+1}</strong><div className="muted" style={{fontSize:12,marginTop:7}}>{shot.description.slice(0,100)}</div><div className="pill" style={{marginTop:10}}>{shot.status}</div></div>)}</div></section>
  </main>;
}
