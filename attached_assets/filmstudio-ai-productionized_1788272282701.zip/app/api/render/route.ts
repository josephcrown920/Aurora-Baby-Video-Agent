import { NextRequest, NextResponse } from "next/server";
import { RenderStub } from "../../../lib/local-adapters";
const renderer=new RenderStub();
export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>({}));
  if(!b.projectId) return NextResponse.json({error:"projectId required"},{status:400});
  return NextResponse.json(await renderer.render({
    projectId:b.projectId,format:"mp4",width:Number(b.width)||1920,height:Number(b.height)||1080,
    fps:Number(b.fps)||30,quality:b.quality||"standard"
  }),{status:202});
}
