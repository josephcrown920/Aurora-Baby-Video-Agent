import { NextResponse } from "next/server";
import { store } from "../../../../lib/store";

export async function GET(_: Request,{params}:{params:{id:string}}) {
  const p=store.getProject(params.id);
  return p?NextResponse.json(p):NextResponse.json({error:"not found"},{status:404});
}
