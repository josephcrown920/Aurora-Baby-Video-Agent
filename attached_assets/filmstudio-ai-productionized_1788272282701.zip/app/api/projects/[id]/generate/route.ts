import { NextResponse } from "next/server";
import { store } from "../../../../../lib/store";
import { chooseProvider } from "../../../../../lib/providers";

export async function POST(req: Request,{params}:{params:{id:string}}) {
  const project=store.getProject(params.id);
  if(!project) return NextResponse.json({error:"not found"},{status:404});

  const body=await req.json().catch(()=>({}));
  const preferred=typeof body.provider==="string"?body.provider:undefined;
  const provider=chooseProvider("video",preferred);

  project.status="generating";

  for(const scene of project.scenes) {
    for(const shot of scene.shots) {
      shot.status="generating";
      const result=await provider.generate({
        prompt:shot.description,
        durationSeconds:shot.durationSeconds,
        model:shot.model
      });
      shot.provider=result.provider;
      shot.model=result.model;
      shot.outputUrl=result.outputUrl;
      shot.status=result.status==="complete"?"complete":result.status==="failed"?"failed":"queued";
      if(result.error) console.error(result.error);
    }
  }

  project.status="review";
  project.updatedAt=new Date().toISOString();
  project.creditsUsed += project.scenes.flatMap(s=>s.shots).length;
  store.saveProject(project);
  return NextResponse.json({project});
}
