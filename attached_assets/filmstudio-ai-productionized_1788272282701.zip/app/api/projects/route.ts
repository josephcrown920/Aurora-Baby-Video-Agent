import { NextRequest, NextResponse } from "next/server";
import { makeProject } from "../../../lib/agent";
import { store } from "../../../lib/store";
import type { AspectRatio } from "../../../lib/types";

export async function GET() { return NextResponse.json(store.projects()); }

export async function POST(req: NextRequest) {
  const b = await req.json().catch(()=>({}));
  if(typeof b.prompt !== "string" || !b.prompt.trim()) return NextResponse.json({error:"prompt required"},{status:400});
  const project = makeProject(String(b.name || "Untitled project"), {
    prompt:b.prompt.trim(),
    durationSeconds:Number(b.durationSeconds)||60,
    aspectRatio:(b.aspectRatio||"16:9") as AspectRatio,
    language:String(b.language||"English"),
    tone:String(b.tone||"cinematic"),
    audience:b.audience,
    referenceAssetIds:Array.isArray(b.referenceAssetIds)?b.referenceAssetIds:[]
  });
  project.status="planning";
  store.saveProject(project);
  return NextResponse.json(project,{status:201});
}
