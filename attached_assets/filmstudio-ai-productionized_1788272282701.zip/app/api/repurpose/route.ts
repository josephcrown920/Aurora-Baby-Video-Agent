import { NextRequest, NextResponse } from "next/server";
export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>({}));
  const ratios=Array.isArray(b.ratios)?b.ratios:["9:16","1:1","4:5","16:9"];
  return NextResponse.json({jobId:crypto.randomUUID(),ratios,status:"queued",workflow:"smart-reframe"});
}
