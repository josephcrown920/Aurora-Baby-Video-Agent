import {NextRequest,NextResponse} from "next/server"; import {publishProgress} from "../../../../lib/queue";
export async function POST(req:NextRequest){const b=await req.json().catch(()=>({}));const id=b.id;if(id)await publishProgress(String(id),{status:b.status||"complete",progress:b.status==="succeeded"||!b.status?100:50,result:b.output||b.video});return NextResponse.json({ok:true});}
