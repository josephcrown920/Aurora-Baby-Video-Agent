import { NextRequest, NextResponse } from "next/server";
import { createGenerationJob } from "../../../../lib/runtime";
import { chooseProvider } from "../../../../lib/providers";
import { store } from "../../../../lib/store";

export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>({}));
  if(!b.projectId || !b.prompt || !b.modality)
    return NextResponse.json({error:"projectId, prompt and modality are required"},{status:400});

  const job=createGenerationJob({
    projectId:b.projectId,prompt:b.prompt,modality:b.modality,
    durationSeconds:b.durationSeconds,width:b.width,height:b.height,
    referenceAssetIds:b.referenceAssetIds,preferredProvider:b.preferredProvider
  });

  const provider=chooseProvider(b.modality,b.preferredProvider);
  job.status="running"; job.progress=10;
  store.saveJob(job);

  const result=await provider.generate({
    prompt:b.prompt,durationSeconds:b.durationSeconds,width:b.width,height:b.height,
    referenceAssetIds:b.referenceAssetIds
  });

  job.provider=result.provider; job.model=result.model; job.progress=result.status==="complete"?100:25;
  job.status=result.status==="complete"?"complete":result.status==="failed"?"failed":"queued";
  job.result={...job.result,outputUrl:result.outputUrl};
  job.error=result.error;
  job.updatedAt=new Date().toISOString();
  store.saveJob(job);

  return NextResponse.json(job,{status:201});
}
