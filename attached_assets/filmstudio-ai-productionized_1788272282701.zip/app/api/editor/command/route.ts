import { NextRequest, NextResponse } from "next/server";
import { store } from "../../../../lib/store";

export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>({}));
  if(!b.projectId || !b.command) return NextResponse.json({error:"projectId and command required"},{status:400});
  const project=store.getProject(b.projectId);
  if(!project) return NextResponse.json({error:"project not found"},{status:404});

  const command=String(b.command);
  const lower=command.toLowerCase();

  // Safe prototype mutations. More complex commands become agent plan steps.
  if(lower.includes("delete scene")){
    const n=Number((lower.match(/scene\s+(\d+)/)||[])[1]);
    if(n) project.scenes=project.scenes.filter(s=>s.index!==n);
  }

  project.updatedAt=new Date().toISOString();
  store.saveProject(project);

  return NextResponse.json({
    status:"accepted",
    project,
    command,
    execution:"timeline mutation / agent revision"
  });
}
