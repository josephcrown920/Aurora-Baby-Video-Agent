import { NextResponse } from "next/server";
import fs from "node:fs";
import path from "node:path";

export async function GET() {
  const file = path.join(process.cwd(), "CAPABILITY_MANIFEST.json");
  return NextResponse.json(JSON.parse(fs.readFileSync(file, "utf8")));
}
