import { NextRequest, NextResponse } from "next/server";
import { buildPlan, nextRunnableSteps } from "../../../../lib/brain";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  if (typeof body.prompt !== "string" || !body.prompt.trim())
    return NextResponse.json({error:"prompt required"},{status:400});

  const plan = buildPlan({
    prompt:body.prompt,
    projectId:body.projectId,
    userId:body.userId,
    constraints:body.constraints || {}
  });

  // Execution is intentionally represented as a deterministic orchestration
  // plan. Real workers/providers plug into these capability steps.
  return NextResponse.json({
    runId:crypto.randomUUID(),
    status:"planned",
    next:nextRunnableSteps(plan),
    plan
  });
}
