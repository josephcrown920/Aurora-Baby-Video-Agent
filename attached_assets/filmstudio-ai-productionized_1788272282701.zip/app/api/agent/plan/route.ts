import { NextRequest, NextResponse } from "next/server";
import { buildPlan } from "../../../../lib/brain";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  if (typeof body.prompt !== "string" || !body.prompt.trim())
    return NextResponse.json({error:"prompt required"},{status:400});
  return NextResponse.json(buildPlan({
    prompt: body.prompt,
    projectId: body.projectId,
    userId: body.userId,
    constraints: body.constraints || {}
  }));
}
