import { NextRequest, NextResponse } from "next/server";
import { buildPlan } from "../../../../lib/brain";
export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>({}));
  if(typeof b.command!=="string"||!b.command.trim()) return NextResponse.json({error:"command required"},{status:400});
  return NextResponse.json({
    status:"planned",
    command:b.command,
    plan:buildPlan({prompt:b.command,projectId:b.projectId,userId:b.userId,constraints:b.constraints||{}})
  });
}
