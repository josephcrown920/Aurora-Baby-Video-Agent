import { NextRequest, NextResponse } from "next/server";
const versions=new Map<string,unknown[]>();
export async function GET(req:NextRequest){return NextResponse.json(versions.get(req.nextUrl.searchParams.get("projectId")||"")||[]);}
export async function POST(req:NextRequest){const b=await req.json();const key=String(b.projectId);const list=versions.get(key)||[];const v={id:crypto.randomUUID(),createdAt:new Date().toISOString(),snapshot:b.snapshot};list.unshift(v);versions.set(key,list);return NextResponse.json(v,{status:201});}
