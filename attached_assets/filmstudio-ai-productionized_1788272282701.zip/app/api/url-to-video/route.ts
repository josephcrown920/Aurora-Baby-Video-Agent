import { NextRequest, NextResponse } from "next/server";
export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>({}));
  if(typeof b.url!=="string") return NextResponse.json({error:"url required"},{status:400});
  return NextResponse.json({jobId:crypto.randomUUID(),url:b.url,status:"queued",workflow:"url-to-video"});
}
