import { NextResponse } from "next/server";
export async function GET(){return NextResponse.json({creditsRemaining:10000,period:"prototype",reserved:0});}
