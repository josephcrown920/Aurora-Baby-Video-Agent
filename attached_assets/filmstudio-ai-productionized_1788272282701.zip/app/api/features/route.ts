import { NextResponse } from "next/server";
import { FEATURE_STATUS } from "../../../lib/features";
export async function GET(){ return NextResponse.json(FEATURE_STATUS); }
