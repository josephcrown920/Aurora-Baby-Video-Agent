import { NextRequest, NextResponse } from "next/server";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json({assetId:crypto.randomUUID(),status:"registered",asset:b});}
