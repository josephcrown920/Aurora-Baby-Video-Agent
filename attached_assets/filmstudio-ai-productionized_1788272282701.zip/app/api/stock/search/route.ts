import { NextRequest, NextResponse } from "next/server";
export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>({}));
  if(typeof b.query!=="string"||!b.query.trim()) return NextResponse.json({error:"query required"},{status:400});
  return NextResponse.json({query:b.query,results:[],provider:"stock-adapter",message:"Connect licensed stock APIs here."});
}
