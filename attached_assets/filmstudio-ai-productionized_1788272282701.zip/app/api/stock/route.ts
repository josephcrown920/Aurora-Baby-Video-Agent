import { NextRequest, NextResponse } from "next/server";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json({query:b.query||"",results:[],licenseRequired:true,status:"adapter-ready"});}
