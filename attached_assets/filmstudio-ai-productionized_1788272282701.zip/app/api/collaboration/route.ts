import { NextRequest, NextResponse } from "next/server";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json({projectId:b.projectId,member:b.member,role:b.role||"editor",status:"invited"});}
