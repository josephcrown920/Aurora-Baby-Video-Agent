import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    providers: [
      { name:"fal", configured:Boolean(process.env.FAL_KEY && process.env.FAL_MODEL_ENDPOINT), roles:["video","image","voice","music","render"] },
      { name:"replicate", configured:Boolean(process.env.REPLICATE_API_TOKEN && process.env.REPLICATE_MODEL), roles:["video","image","voice","music"] },
      { name:"vast-gpu", configured:Boolean(process.env.VAST_API_KEY && process.env.VAST_GENERATION_ENDPOINT), roles:["video","image","render","custom-models"] }
    ]
  });
}
