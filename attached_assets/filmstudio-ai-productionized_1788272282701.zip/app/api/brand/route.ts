import { NextRequest, NextResponse } from "next/server";
const brands=new Map<string,unknown>();
export async function GET(req:NextRequest){return NextResponse.json(brands.get(req.nextUrl.searchParams.get("projectId")||"")||{});}
export async function POST(req:NextRequest){const b=await req.json();brands.set(String(b.projectId),b);return NextResponse.json(b,{status:201});}
