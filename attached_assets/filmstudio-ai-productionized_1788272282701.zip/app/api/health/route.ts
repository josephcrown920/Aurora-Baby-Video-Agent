import {NextResponse} from "next/server";
export async function GET(){return NextResponse.json({ok:true,time:new Date().toISOString(),integrations:{fal:!!process.env.FAL_KEY,replicate:!!process.env.REPLICATE_API_TOKEN,vast:!!process.env.VAST_API_KEY,database:!!process.env.DATABASE_URL,redis:!!process.env.REDIS_URL,storage:!!process.env.S3_ENDPOINT}});}
