import {NextResponse} from "next/server"; import {MODEL_REGISTRY} from "../../../lib/provider-registry";
export async function GET(){return NextResponse.json(MODEL_REGISTRY);}
