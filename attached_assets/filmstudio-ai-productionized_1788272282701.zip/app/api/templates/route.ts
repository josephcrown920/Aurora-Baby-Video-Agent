import { NextResponse } from "next/server";
const templates=[
{id:"social-short",name:"Social Short",aspectRatio:"9:16",duration:30},
{id:"product-launch",name:"Product Launch",aspectRatio:"16:9",duration:60},
{id:"explainer",name:"Explainer",aspectRatio:"16:9",duration:90},
{id:"talking-head",name:"Talking Head",aspectRatio:"16:9",duration:60}
];
export async function GET(){return NextResponse.json(templates);}
