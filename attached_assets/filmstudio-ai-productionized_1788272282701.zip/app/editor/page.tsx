"use client";
import { useState } from "react";

const tracks = [
  {name:"Video", items:["Shot 01","Shot 02","Shot 03","Shot 04"]},
  {name:"Overlay", items:["Title","Product callout"]},
  {name:"Captions", items:["Auto captions"]},
  {name:"Voice", items:["Voiceover"]},
  {name:"Music", items:["Soundtrack"]},
];

export default function Editor() {
  const [selected,setSelected] = useState("Shot 01");
  return <main style={{minHeight:"100vh",display:"grid",gridTemplateRows:"64px 1fr 260px"}}>
    <header style={{borderBottom:"1px solid #222831",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 20px"}}>
      <a href="/" style={{color:"white",textDecoration:"none"}}>FilmStudio AI</a>
      <div style={{display:"flex",gap:8}}>{["Undo","Redo","Split","Delete","Regenerate","Export"].map(x=><button key={x} style={{background:"#171b21",border:"1px solid #2a3039",color:"white",borderRadius:7,padding:"8px 11px"}}>{x}</button>)}</div>
    </header>
    <section style={{display:"grid",gridTemplateColumns:"260px 1fr 300px",minHeight:0}}>
      <aside style={{borderRight:"1px solid #222831",padding:16,overflow:"auto"}}><h3>Media</h3><input placeholder="Search assets" style={{width:"100%",padding:10,background:"#11151b",border:"1px solid #282f38",borderRadius:8,color:"white"}}/><div style={{marginTop:15}}>{["Uploads","Generated","Stock","Audio","Brand"].map(x=><div key={x} className="card" style={{padding:12,marginBottom:8}}>{x}</div>)}</div></aside>
      <section style={{padding:22,background:"#0c0f13"}}><div style={{height:"100%",display:"grid",placeItems:"center"}}><div style={{width:"80%",aspectRatio:"16/9",background:"#050608",border:"1px solid #252b33",borderRadius:12,display:"grid",placeItems:"center",color:"#727b88"}}>Preview canvas<br/><span style={{fontSize:12}}>Selected: {selected}</span></div></div></section>
      <aside style={{borderLeft:"1px solid #222831",padding:16,overflow:"auto"}}><h3>Inspector</h3><p className="muted">Selected clip</p><h4>{selected}</h4>{["Trim","Speed","Volume","Opacity","Position","Scale","Effects","Transitions"].map(x=><div key={x} className="card" style={{padding:11,marginBottom:8}}>{x}</div>)}</aside>
    </section>
    <section style={{borderTop:"1px solid #222831",padding:14,overflow:"auto"}}>
      {tracks.map(t=><div key={t.name} style={{display:"grid",gridTemplateColumns:"90px 1fr",gap:8,marginBottom:8,alignItems:"center"}}><div className="muted">{t.name}</div><div style={{display:"flex",gap:7}}>{t.items.map((item,i)=><button key={item} onClick={()=>setSelected(item)} style={{textAlign:"left",minWidth:120,padding:11,border:"1px solid #303742",background:item===selected?"#202631":"#13171d",color:"white",borderRadius:7}}>{item}<div className="muted" style={{fontSize:11,marginTop:3}}>{i*5}s</div></button>)}</div></div>)}
    </section>
  </main>;
}
