# Productionized build

## Included in this pass
- Postgres schema and connection layer
- Redis queue/event layer
- worker process
- SSE job progress
- FAL/Replicate webhook surfaces
- Vast GPU/ComfyUI provider boundary from previous build
- camera/behavior/shot compiler
- model registry
- health endpoint
- Docker/Compose-ready infrastructure contracts
- CI/test configuration
- production environment boundaries

## What still requires external provisioning
Live vendor accounts, keys, model/version IDs, a Vast GPU worker, production database,
Redis, object storage/CDN, FFmpeg worker, stock/TTS/music/avatar providers, auth and
billing accounts. Source code cannot provision those external resources.

## Recommended activation order
1. Postgres + Redis
2. Object storage
3. Vast + ComfyUI worker
4. FAL + Replicate credentials
5. FFmpeg render worker
6. TTS/music/avatar/stock providers
7. Auth + billing
8. Observability + load testing
