import Redis from "ioredis";
const redis=process.env.REDIS_URL?new Redis(process.env.REDIS_URL):null;
async function main(){if(!redis)throw new Error("REDIS_URL required");console.log("FilmStudio worker online");while(true){const item=await redis.brpop("queue:generation",0);if(!item)continue;const [,raw]=item;const job=JSON.parse(raw);await redis.publish(`job:${job.id}`,JSON.stringify({status:"running",progress:10}));await new Promise(r=>setTimeout(r,100));await redis.publish(`job:${job.id}`,JSON.stringify({status:"queued",progress:25}));}}
main().catch(e=>{console.error(e);process.exit(1)});
