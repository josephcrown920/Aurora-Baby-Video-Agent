# Recommended upgrades

## Tier 1 — Make the prototype genuinely usable
- Connect one real FAL video model.
- Connect one Replicate video model.
- Stand up one Vast GPU with ComfyUI.
- Add persistent Postgres.
- Add S3-compatible media storage.
- Add Redis workers.
- Add FFmpeg render worker.
- Add live generation progress.
- Add upload/reference image flow.

## Tier 2 — Make it feel like a modern agent
- Visual memory graph.
- Character identity lock.
- Style bible compiler.
- Camera planner.
- Coverage planner.
- Automatic shot selection.
- Prompt-to-timeline compiler.
- Agentic stock retrieval.
- Natural-language edit compiler.
- Frame-level QA.

## Tier 3 — Differentiate from InVideo
- Multi-model A/B generation.
- Automatic cost/quality optimization.
- Persistent creative memory across projects.
- Reusable personal production presets.
- Custom ComfyUI workflow marketplace/registry.
- “Director mode” with deterministic shot grammar.
- Multi-version parallel editing.
- One-click campaign expansion: one brief → long-form + Shorts + ads + thumbnails.
- Creator-specific style learning with user-approved references.
