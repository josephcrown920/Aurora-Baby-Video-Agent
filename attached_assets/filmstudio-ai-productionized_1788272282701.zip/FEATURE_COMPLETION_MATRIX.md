# Feature completion matrix

## Prototype implemented
- [x] Individual agent planning
- [x] Project/workspace model
- [x] Script/storyboard/shot contracts
- [x] FAL/Replicate/Vast provider boundaries
- [x] Provider model registry
- [x] Slate-style editor surface
- [x] Notebook-style model playground concept
- [x] Natural-language editor command API
- [x] Stock adapter contract
- [x] URL-to-video contract
- [x] Repurpose contract
- [x] QA/revision planning
- [x] Brand/template/asset contracts
- [x] Captions/translation/avatar API surfaces
- [x] Production runbook
- [x] Camera/behavior/shot grammar
- [x] Capability manifest

## Still required for a production SaaS
- [ ] real FAL model endpoints and webhook/polling implementation
- [ ] real Replicate model versions and polling/webhooks
- [ ] live Vast GPU + ComfyUI worker
- [ ] persistent Postgres schema/migrations
- [ ] Redis queue workers
- [ ] object storage + signed URLs
- [ ] FFmpeg render workers
- [ ] WebSocket/SSE live progress
- [ ] real stock provider + license metadata
- [ ] real TTS/music/avatar integrations
- [ ] authentication/authorization
- [ ] billing/payment provider
- [ ] credit ledger + reservation/refunds
- [ ] moderation/safety pipeline
- [ ] collaboration presence/conflict resolution
- [ ] production observability
- [ ] automated integration/e2e tests
- [ ] deployment/CI/CD
- [ ] CDN/media delivery
- [ ] rate limiting/abuse prevention

## High-value upgrades
1. Reference-aware identity engine
2. Shot-to-shot continuity graph
3. Automatic coverage planner
4. Cost-aware model router
5. Parallel generation workers
6. Native ComfyUI workflow registry
7. Timeline diff/versioning
8. semantic asset search
9. edit-by-command compiler
10. automated visual QA with frame sampling
