# FilmStudio AI — InVideo Capability Parity Prototype

## Product target

The prototype is an **individual autonomous video agent** benchmarked against the current InVideo-style workflow, while keeping the implementation modular and vendor-independent.

### Capability matrix

| Capability | Agent contract | UI surface | Provider hook |
|---|---|---|---|
| Prompt → video | yes | yes | FAL / Replicate / Vast |
| Script generation | yes | project script | LLM seam |
| Storyboard | yes | scene/shot plan | LLM seam |
| Shot generation | yes | timeline | FAL / Replicate / Vast |
| Image generation | yes | asset library | FAL / Replicate / Vast |
| Voice | yes | audio track | provider seam |
| Music/SFX | yes | audio track | provider seam |
| Captions | yes | caption track | provider seam |
| Stock media | contract | asset library | stock adapter seam |
| Timeline editing | yes | workspace | local editor state |
| Templates | contract | template surface | template registry |
| Brand kit | contract | brand surface | project metadata |
| Repurposing | plan step | export surface | render adapter |
| AI revision | plan step | agent action | generation adapter |
| QA | plan step | review surface | QA service seam |
| Render/export | plan step | export surface | render worker seam |
| Credits | project counter | usage surface | billing seam |
| Asset persistence | project refs | library surface | object storage seam |

## Acceptance rule

A feature is not considered complete just because it has a button. It needs:
1. a domain contract,
2. an API/workflow,
3. a UI entry point,
4. a provider/worker boundary,
5. an observable status,
6. a failure path,
7. a revision path where applicable.
