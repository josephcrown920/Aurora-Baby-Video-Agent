# FilmStudio AI — Individual Autonomous Video Agent

## Mission

Build a new individual autonomous video agent with the **current InVideo capability surface
as the baseline**, while making the agent the intelligence layer that operates the entire
production workspace.

This is an independent implementation. It does not copy proprietary InVideo source code.

## Core experience

A user gives one instruction:

> "Create a 60-second cinematic launch video for my product."

The agent should:
1. understand intent and constraints,
2. choose a workflow,
3. write/refine the script,
4. create storyboard and coverage,
5. compile structured shot specifications,
6. decide generated vs stock assets,
7. select the best model/provider,
8. generate media,
9. build the Slate timeline,
10. create voice/music/SFX/captions,
11. inspect the result,
12. repair weak shots,
13. render,
14. verify the exported file,
15. produce platform variants.

## The three execution layers

### FAL
Hosted generation for fast access to modern media models.

### Replicate
Model/version marketplace layer for alternative models and experiments.

### Vast GPU + ComfyUI
Our custom high-control execution layer for identity, camera control,
special workflows, upscaling and models that are cheaper/better to self-host.

The agent sees all three through one normalized provider contract.

## Agent brain

The brain is not just an LLM prompt. It has:
- intent classifier
- planner
- tool registry
- project memory
- visual/character/location bibles
- shot compiler
- model router
- cost guardrails
- job orchestration
- QA
- revision loop
- versioning

## Camera control

Every shot can express:
- framing
- angle
- lens/focal length
- camera position
- movement
- movement speed
- stabilization
- depth of field
- focus target
- lighting
- atmosphere
- subject behavior
- temporal beats
- continuity constraints

See `CAMERA_AND_SHOT_SPEC.md` and `SHOT_SCHEMA.json`.

## Current capability benchmark

The prototype accounts for:
- prompt-to-video
- script-to-video
- URL-to-video
- image-to-video
- AI image/video generation
- stock media
- Notebook
- Slate
- natural-language editing
- avatars
- voice/voice cloning
- music/SFX
- captions
- translation/dubbing
- templates
- brand kits
- repurposing
- thumbnails
- enhancement/background/face-tool contracts
- QA
- autonomous revision
- render/export
- projects/assets/versions
- collaboration
- credits
- multi-model routing
- Vast/ComfyUI

## What is actually production-ready vs. what is an adapter

The source includes working local application behavior and integration boundaries.
Third-party services are not provisioned by source code alone.

For production, configure:
- FAL credentials/endpoints
- Replicate credentials/model versions
- Vast GPU + ComfyUI worker
- Postgres
- Redis
- S3-compatible storage
- FFmpeg workers
- stock provider
- TTS/music/avatar providers
- authentication
- billing
- monitoring

See:
- `FEATURE_COMPLETION_MATRIX.md`
- `MODEL_INTEGRATION_GUIDE.md`
- `PRODUCTION_RUNBOOK.md`
- `UPGRADES.md`

## Run

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Deployment

The app can be containerized with the included Dockerfile. For long-running generation,
move provider/render work to workers instead of executing it inside request handlers.

## Non-negotiable product principle

**The Agent and the Editor share the same project graph.**

When a user says:
- "make shot 4 darker"
- "replace the voice"
- "turn this into a 9:16 Reel"
- "use a 35mm low-angle tracking shot"
- "keep everything except scene 3"

the agent should mutate the existing production state and create a version—not throw
away the project and start again.
