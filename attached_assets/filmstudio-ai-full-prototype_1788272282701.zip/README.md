# FilmStudio AI — Full Individual Video Agent Prototype

This is the current prototype direction for the task:

> Build a new individual autonomous video agent whose capability baseline matches
> the current InVideo product, while using our own architecture and provider layer.

## What is included

### Brain
- intent classification
- planning
- specialized production roles
- script/storyboard/shot planning
- asset planning
- provider/model routing
- generation
- editing
- captions
- QA
- autonomous revision
- rendering

### InVideo-style capability coverage
- prompt-to-video
- script-to-video
- URL-to-video contract
- image/video generation
- stock search/agentic placement contract
- Notebook-style model playground
- Slate-style editor
- natural-language edit contract
- avatars/voice-clone contract
- voice/music/SFX
- captions
- translation/dubbing contract
- templates
- brand kits
- repurposing
- thumbnails
- enhancement/background/face-tool contracts
- collaboration/versioning contracts
- credits
- asset library
- provider registry
- FAL + Replicate + Vast GPU/ComfyUI execution layer
- QA and revision
- render/export

## Important implementation boundary

The prototype is source code and contracts, not a claim that third-party credentials,
licensed stock catalogs, GPU workers, or vendor infrastructure are magically provisioned.

To become a production SaaS, connect:
- real FAL model endpoints
- Replicate model/version IDs
- Vast GPU ComfyUI worker/API
- licensed stock APIs
- object storage
- Postgres
- Redis/queue workers
- FFmpeg render workers
- auth/billing
- webhook/event processing

The architecture is deliberately built so these replace adapters rather than rewrite
the agent or editor.

## Run

npm install
npm run dev
