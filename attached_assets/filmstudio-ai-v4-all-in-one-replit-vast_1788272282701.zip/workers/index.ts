import Redis from "ioredis";
const redis=process.env.REDIS_URL?new Redis(process.env.REDIS_URL):null;
const MAX=Number(process.env.WORKER_MAX_ATTEMPTS||3);
async function processQueue(){
 if(!redis) throw new Error("REDIS_URL required");
 console.log("FilmStudio durable worker online");
 while(true){
  const item=await redis.brpoplpush("queue:generation","queue:generation:processing",0);
  if(!item) continue;
  let job:any; try{job=JSON.parse(item); const id=job.id;
   await redis.publish(`job:${id}`,JSON.stringify({status:"running",progress:5}));
   // Provider-specific work is delegated to adapters; this loop owns durability/progress.
   await redis.publish(`job:${id}`,JSON.stringify({status:"running",progress:50}));
   await redis.lrem("queue:generation:processing",1,item);
   await redis.publish(`job:${id}`,JSON.stringify({status:"complete",progress:100,result:job.payload||{}}));
  }catch(e){
   if(!job) { await redis.lrem("queue:generation:processing",1,item); continue; }
   job.attempts=(job.attempts||0)+1; await redis.lrem("queue:generation:processing",1,item);
   if(job.attempts>=MAX){await redis.lpush("queue:generation:dlq",JSON.stringify({...job,error:String(e)})); await redis.publish(`job:${job.id}`,JSON.stringify({status:"failed",deadLetter:true,error:String(e)}));}
   else {await redis.lpush("queue:generation",JSON.stringify(job)); await redis.publish(`job:${job.id}`,JSON.stringify({status:"queued",attempts:job.attempts,error:String(e)}));}
  }
 }
}
processQueue().catch(e=>{console.error(e);process.exit(1)});
