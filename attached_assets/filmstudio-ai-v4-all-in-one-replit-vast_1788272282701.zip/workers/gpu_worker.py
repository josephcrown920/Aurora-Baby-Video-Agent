import os, json, time, uuid
from redis import Redis

r=Redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
QUEUE="queue:gpu"
PROCESSING="queue:gpu:processing"
DLQ="queue:gpu:dlq"
MAX_ATTEMPTS=int(os.getenv("WORKER_MAX_ATTEMPTS","3"))

def emit(job_id,event):
    r.publish(f"job:{job_id}",json.dumps(event))

def run(job):
    job_id=job["id"]
    emit(job_id,{"status":"running","progress":5,"worker":"vast-comfyui"})
    # Actual ComfyUI HTTP submission belongs here; keep it injectable through COMFY_URL.
    # The worker contract is durable and idempotent even when the provider adapter changes.
    time.sleep(0.05)
    emit(job_id,{"status":"running","progress":50,"worker":"vast-comfyui"})
    time.sleep(0.05)
    emit(job_id,{"status":"complete","progress":100,"worker":"vast-comfyui","result":job.get("payload",{})})

while True:
    item=r.brpoplpush(QUEUE,PROCESSING,timeout=5)
    if not item: continue
    try:
        job=json.loads(item); run(job)
        r.lrem(PROCESSING,1,item)
    except Exception as e:
        job=json.loads(item); attempts=int(job.get("attempts",0))+1; job["attempts"]=attempts
        r.lrem(PROCESSING,1,item)
        if attempts>=MAX_ATTEMPTS:
            r.lpush(DLQ,json.dumps({**job,"error":str(e)})); emit(job["id"],{"status":"failed","error":str(e),"deadLetter":True})
        else:
            r.lpush(QUEUE,json.dumps(job)); emit(job["id"],{"status":"queued","attempts":attempts,"error":str(e)})
