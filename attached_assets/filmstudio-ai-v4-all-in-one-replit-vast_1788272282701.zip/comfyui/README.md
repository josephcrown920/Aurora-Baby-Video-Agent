# ComfyUI production workflows

These workflow contracts define the inputs/outputs the FilmStudio workers expect. They are deliberately checkpoint-agnostic: install your licensed/approved checkpoints and bind the actual nodes in ComfyUI rather than shipping model weights inside the application ZIP.

Required production workflows:
- layer decomposition (up to 20 layers)
- targeted layer edit
- 2x upscale
- 4x upscale
- optional face/identity preservation
- optional background replacement
- optional relighting

The worker adapter treats each workflow as an idempotent job and stores the resulting manifest with the asset.
