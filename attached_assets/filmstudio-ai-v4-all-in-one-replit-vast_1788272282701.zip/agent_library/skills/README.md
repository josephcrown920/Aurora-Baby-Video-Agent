# FilmStudio Agent Skills

The agent skill registry is intentionally model-agnostic. Skills describe *what* the agent must accomplish;
workflows describe *how* providers are chained; prompts describe reusable instruction templates.

## Core skills
- brief-to-production
- research-and-fact-check
- script-and-voiceover
- character-bible
- environment-bible
- reference-generation
- storyboard-and-shotlist
- camera-direction
- motion-and-behavior
- image-layer-decomposition
- layer-edit
- object/face/outfit swap
- relight/background replacement
- upscale/enhance
- image-to-video
- video-to-video
- lip-sync/avatar
- TTS/music/SFX
- continuity QA
- candidate scoring
- automatic repair
- edit/timeline assembly
- captions/subtitles
- brand/template adaptation
- FFmpeg mastering
- delivery/export
