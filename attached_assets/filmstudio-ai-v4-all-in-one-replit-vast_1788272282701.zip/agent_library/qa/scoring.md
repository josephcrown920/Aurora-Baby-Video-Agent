# Candidate scoring

Score each candidate 0–100:
- identity/subject consistency: 25
- prompt adherence: 20
- temporal stability: 15
- camera execution: 15
- anatomy/object integrity: 10
- lighting/material continuity: 10
- composition: 5

Hard failures:
- identity replacement
- major anatomy corruption
- camera discontinuity
- severe flicker/warping
- broken object topology
- text corruption when text must be exact

Repair should target the failed dimension rather than blindly regenerate the entire shot.
