# Camera & shot library

## Establishing
- 18–24mm wide
- locked tripod
- slow crane
- aerial top-down

## Cinematic coverage
- 28–35mm environmental medium
- 50mm natural perspective
- 85mm portrait/compression
- 100–135mm detail/telephoto

## Movement
- dolly-in / dolly-out
- truck left/right
- pedestal
- crane
- orbit
- arc
- handheld
- steadicam
- whip pan
- rack focus
- push-pull / dolly zoom
- FPV
- overhead
- Dutch tilt

Every generated shot should encode camera position, movement vector, speed curve and focus behavior.
