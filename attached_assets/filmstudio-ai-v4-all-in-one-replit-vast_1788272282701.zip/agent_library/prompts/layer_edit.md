# Layer edit prompt template

Edit ONLY the selected layer(s): {layers}.
Requested change: {change}.

Keep all unselected layers pixel-consistent where possible.
Preserve camera perspective, composition, shadows, reflections, occlusion, material response,
color relationships and scene geometry. Recalculate only physically necessary contact shadows/reflections.
Do not regenerate untouched subjects.
