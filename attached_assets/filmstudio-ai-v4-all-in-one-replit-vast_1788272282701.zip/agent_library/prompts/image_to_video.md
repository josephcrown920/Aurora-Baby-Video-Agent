# Image-to-video prompt template

Use the supplied reference image as the immutable visual starting point.
Preserve subject identity, facial structure, wardrobe, body proportions, environment geometry,
materials and lighting unless explicitly instructed otherwise.

CAMERA:
{camera}

SUBJECT BEHAVIOR:
{behavior}

ENVIRONMENT / PHYSICS:
{environment}

TIMING:
{timing}

MOTION INTENSITY:
{motion}

CONTINUITY LOCKS:
{locks}

NEGATIVE:
no identity drift, no wardrobe drift, no anatomy drift, no background mutation, no random objects,
no camera teleportation, no unexplained lighting changes, no frame warping
