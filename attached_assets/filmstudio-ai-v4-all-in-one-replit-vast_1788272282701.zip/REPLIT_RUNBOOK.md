# Replit runbook

## Web
`npm run dev`

## Production web
`npm run build && npm start`

## Durable worker
`npm run worker`

## Required Replit Secrets
ARK_API_KEY, ARK_BASE_URL, MODELARK_IMAGE_MODEL, MODELARK_VIDEO_MODEL, SEEDANCE_ENDPOINT, REDIS_URL, DATABASE_URL, S3_ENDPOINT, S3_BUCKET, S3_ACCESS_KEY, S3_SECRET_KEY, AUTH_SECRET.

## Vast
Deploy `vast/worker-entrypoint.sh` with a pinned CUDA/ComfyUI image and connect it to the same Redis/S3 services.

Never commit provider keys or model weights.
