#!/usr/bin/env python3
"""Tiny ModelArk CLI for FilmStudio smoke tests."""
import argparse, os, json
from byteplussdkarkruntime import Ark

def main():
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest="cmd",required=True)
    for name in ("chat","image"):
        q=sub.add_parser(name); q.add_argument("prompt")
    a=p.parse_args(); client=Ark(base_url=os.getenv("ARK_BASE_URL","https://ark.ap-southeast.bytepluses.com/api/v3"),api_key=os.environ["ARK_API_KEY"])
    if a.cmd=="chat":
        r=client.responses.create(model=os.getenv("ARK_REASONING_MODEL","deepseek-v4-pro-ga-260813"),input=[{"role":"user","content":a.prompt}]); print(r)
    else:
        r=client.images.generate(model=os.getenv("MODELARK_IMAGE_MODEL","seedream-4-5-251128"),prompt=a.prompt,sequential_image_generation="disabled",response_format="url",size=os.getenv("MODELARK_IMAGE_SIZE","2K"),stream=False,watermark=False); print(json.dumps({"url":r.data[0].url}))
if __name__=="__main__": main()
