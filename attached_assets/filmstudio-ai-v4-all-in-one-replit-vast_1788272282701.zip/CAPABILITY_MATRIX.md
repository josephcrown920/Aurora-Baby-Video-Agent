# Capability matrix

## Agent intelligence
- brief interpretation
- research
- script
- storyboard
- shot planning
- model routing
- prompt compilation
- automatic repair

## Visual production
- text-to-image
- image-to-image
- image-to-video
- video-to-video
- character consistency
- environment consistency
- camera control
- behavior control
- reference locking

## Layer editing
- decompose flat image
- up to 20 editable layers
- background isolation
- person/object isolation
- text layer
- face/character/outfit/object replacement
- relight
- add/remove objects
- targeted recomposition
- 2x/4x upscale

## Finishing
- candidate scoring
- frame QA
- continuity QA
- FFmpeg
- captions
- TTS
- music/SFX
- multi-aspect export
- S3/CDN delivery

## Provider strategy
BytePlus/ModelArk, FAL, Replicate and Vast/ComfyUI are adapters behind one router.
