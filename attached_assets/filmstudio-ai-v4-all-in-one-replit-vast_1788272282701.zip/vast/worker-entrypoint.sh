#!/usr/bin/env bash
set -euo pipefail
: "${REDIS_URL:?REDIS_URL required}"
echo "FilmStudio GPU worker starting"
# Install/launch your pinned ComfyUI build here on the Vast image.
# Keep model downloads outside the app repository and pin exact revisions.
exec python workers/gpu_worker.py
