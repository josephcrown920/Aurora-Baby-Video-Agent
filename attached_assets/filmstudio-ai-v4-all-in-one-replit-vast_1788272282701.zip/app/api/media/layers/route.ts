import {NextRequest,NextResponse} from "next/server";

export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>null);
  if(!b?.assetUrl)return NextResponse.json({error:"assetUrl required"},{status:400});
  return NextResponse.json({
    status:"queued",
    operation:"layer_decomposition",
    assetUrl:b.assetUrl,
    maxLayers:Math.min(Number(b.maxLayers||20),20),
    mode:b.mode||"decompose",
    workflow:"agent_library/workflows/layers.yaml",
    message:"Worker adapter ready. Connect the production ComfyUI/provider workflow to execute."
  },{status:202});
}
