import {NextRequest,NextResponse} from "next/server";
import {compileNaturalEdit} from "../../../../lib/edit-compiler";
export async function POST(req:NextRequest){
 const b=await req.json().catch(()=>null); if(!b?.projectId)return NextResponse.json({error:"projectId required"},{status:400});
 const command=b.command||""; const operations=compileNaturalEdit(command);
 return NextResponse.json({status:"compiled",projectId:b.projectId,operations,timeline:b.timeline||{tracks:[],duration:0}});
}
