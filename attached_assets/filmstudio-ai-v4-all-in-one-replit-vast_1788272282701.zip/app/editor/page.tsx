"use client";
import {useMemo,useState} from "react";

type Clip={id:string;name:string;start:number;duration:number;track:string};
const initial:Clip[]=[
 {id:"s1",name:"Shot 01",start:0,duration:4,track:"Video"},{id:"s2",name:"Shot 02",start:4,duration:5,track:"Video"},{id:"s3",name:"Shot 03",start:9,duration:4,track:"Video"},
 {id:"t1",name:"Title",start:1,duration:3,track:"Overlay"},{id:"c1",name:"Auto captions",start:0,duration:13,track:"Captions"},{id:"v1",name:"Voiceover",start:0,duration:13,track:"Voice"},{id:"m1",name:"Soundtrack",start:0,duration:13,track:"Music"}
];
const tracks=["Video","Overlay","Captions","Voice","Music"];
const layers=["Background","Character A","Character B","Wardrobe","Object","Shadows","Reflections","Text"];
export default function Editor(){
 const [clips,setClips]=useState(initial),[selected,setSelected]=useState("s1"),[selectedLayers,setSelectedLayers]=useState<string[]>(["Character A"]),[prompt,setPrompt]=useState("");
 const [zoom,setZoom]=useState(70),[playing,setPlaying]=useState(false),[time,setTime]=useState(2.2),[camera,setCamera]=useState("50mm · slow dolly-in");
 const clip=clips.find(x=>x.id===selected)||clips[0];
 const total=13;
 const edit=()=>{if(!prompt)return;fetch("/api/editor/timeline",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({projectId:"demo",command:prompt})}).catch(()=>{});setPrompt("")};
 const toggleLayer=(x:string)=>setSelectedLayers(v=>v.includes(x)?v.filter(y=>y!==x):[...v,x]);
 const seek=(e:React.MouseEvent<HTMLDivElement>)=>{const r=e.currentTarget.getBoundingClientRect();setTime(Math.max(0,Math.min(total,((e.clientX-r.left)/r.width)*total)))};
 return <main style={{minHeight:"100vh",background:"#080a0d",color:"#f4f6f8",display:"grid",gridTemplateRows:"60px 1fr 290px",fontFamily:"Inter,system-ui"}}>
  <header style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 18px",borderBottom:"1px solid #222831",background:"#0d1015"}}>
   <div style={{display:"flex",gap:18,alignItems:"center"}}><b>FilmStudio AI</b><span style={{fontSize:12,color:"#89919d"}}>Editor · Untitled Production</span></div>
   <div style={{display:"flex",gap:7}}>{["Undo","Redo","Split","Delete","Regenerate"].map(x=><button key={x} className="editorBtn">{x}</button>)}<button className="editorBtn" style={{background:"#b9ff18",color:"#0b0e11",borderColor:"#b9ff18"}}>Export</button></div>
  </header>
  <section style={{display:"grid",gridTemplateColumns:"245px 1fr 290px",minHeight:0}}>
   <aside style={{borderRight:"1px solid #222831",padding:14,overflow:"auto"}}><div style={{fontSize:11,color:"#7d8692",letterSpacing:1}}>MEDIA</div><input className="darkInput" placeholder="Search assets"/>
    {[["Uploads","12"],["Generated","24"],["Stock","0"],["Audio","8"],["Brand","4"]].map(([x,n])=><div key={x} className="assetRow"><span>{x}</span><span className="count">{n}</span></div>)}
    <div style={{marginTop:20,fontSize:11,color:"#7d8692",letterSpacing:1}}>AI TOOLS</div>
    {["Generate shot","Layer edit","Upscale 2×","Upscale 4×","Remove background","Relight","Reframe","Lip-sync"].map(x=><button key={x} className="toolRow">{x}<span>›</span></button>)}
   </aside>
   <section style={{display:"grid",gridTemplateRows:"1fr 62px",minWidth:0}}>
    <div style={{display:"grid",placeItems:"center",background:"radial-gradient(circle at 50% 35%,#1b222a,#080a0d 62%)",padding:28}}>
     <div style={{width:"min(78%,900px)",aspectRatio:"16/9",borderRadius:12,border:"1px solid #2b333d",background:"linear-gradient(135deg,#182028,#080a0d)",position:"relative",overflow:"hidden",boxShadow:"0 18px 70px #000"}}>
      <div style={{position:"absolute",inset:0,display:"grid",placeItems:"center",color:"#68727f"}}><div style={{textAlign:"center"}}><div style={{fontSize:34}}>▶</div><div style={{fontSize:12}}>Preview · {time.toFixed(1)}s</div></div></div>
      <div style={{position:"absolute",left:14,top:12,padding:"5px 8px",borderRadius:99,background:"#b9ff18",color:"#0a0d0f",fontSize:10,fontWeight:700}}>SHOT {clip.name.split(" ")[1]||"01"}</div>
      <div style={{position:"absolute",right:12,top:12,padding:"5px 8px",background:"#11161cdd",borderRadius:6,fontSize:10}}>{camera}</div>
     </div>
    </div>
    <div style={{padding:"10px 18px",display:"flex",gap:8,alignItems:"center",borderTop:"1px solid #222831"}}><button className="play" onClick={()=>setPlaying(!playing)}>{playing?"Ⅱ":"▶"}</button><div onClick={seek} style={{height:5,background:"#252c34",borderRadius:99,flex:1,cursor:"pointer"}}><div style={{height:"100%",width:`${time/total*100}%`,background:"#b9ff18",borderRadius:99}}/></div><span style={{fontSize:11,color:"#89919d"}}>{time.toFixed(1)} / {total.toFixed(1)}</span></div>
   </section>
   <aside style={{borderLeft:"1px solid #222831",padding:14,overflow:"auto"}}><div style={{display:"flex",justifyContent:"space-between"}}><b>Inspector</b><span className="count">{clip.name}</span></div>
    <div className="panel"><label>CAMERA</label><select value={camera} onChange={e=>setCamera(e.target.value)} className="darkInput"><option>24mm · wide push</option><option>35mm · handheld</option><option>50mm · slow dolly-in</option><option>85mm · portrait orbit</option><option>135mm · compressed close-up</option><option>Top-down · crane</option><option>Dutch · 28mm</option></select></div>
    <div className="panel"><label>BEHAVIOR</label><div className="chips">{["Walk","Turn","Look","Gesture","Run","Dance"].map(x=><button className="chip" key={x}>{x}</button>)}</div></div>
    <div className="panel"><label>LAYERS · {selectedLayers.length} SELECTED</label>{layers.map(x=><button key={x} onClick={()=>toggleLayer(x)} className={"layer "+(selectedLayers.includes(x)?"active":"")}><span>◈</span>{x}<span style={{marginLeft:"auto"}}>◌</span></button>)}</div>
    <button className="primary" onClick={()=>fetch("/api/media/layers/"+clip.id,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({selectedLayers,instruction:prompt})}).catch(()=>{})}>Apply targeted layer edit</button>
   </aside>
  </section>
  <section style={{borderTop:"1px solid #222831",background:"#0d1015",display:"grid",gridTemplateRows:"54px 1fr",minHeight:0}}>
   <div style={{display:"flex",alignItems:"center",gap:10,padding:"0 14px",borderBottom:"1px solid #222831"}}><input value={prompt} onChange={e=>setPrompt(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")edit()}} placeholder="Tell the agent what to change… e.g. Make Shot 02 a slow orbit and change his outfit to medieval armor" className="prompt"/><button className="primary" onClick={edit}>✦ Edit with Agent</button><span className="count">{zoom}%</span><input type="range" min="40" max="120" value={zoom} onChange={e=>setZoom(Number(e.target.value))}/></div>
   <div style={{overflow:"auto",padding:"10px 14px"}}><div style={{minWidth:760}}>{tracks.map(t=><div key={t} style={{display:"grid",gridTemplateColumns:"80px 1fr",height:42,alignItems:"center"}}><div style={{fontSize:10,color:"#7d8692"}}>{t}</div><div className="track" onClick={seek}>{clips.filter(c=>c.track===t).map(c=><button key={c.id} onClick={(e)=>{e.stopPropagation();setSelected(c.id)}} className={"clip "+(c.id===selected?"selected":"")} style={{left:`${c.start/total*100}%`,width:`${c.duration/total*100}%`}}>{c.name}</button>)}</div></div>)}</div></div>
  </section>
 </main>
}
