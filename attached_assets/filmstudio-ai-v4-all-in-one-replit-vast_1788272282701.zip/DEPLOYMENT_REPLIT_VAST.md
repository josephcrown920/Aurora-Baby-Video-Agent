# Replit + Vast deployment

Replit is the control plane:
- Next.js UI/API
- ModelArk orchestration
- auth/billing
- project state
- job submission

Vast is the GPU execution plane:
- ComfyUI
- layer decomposition
- upscale
- local image/video workflows
- heavy FFmpeg jobs

Redis carries durable jobs between them.
Postgres stores production state.
S3-compatible storage stores media.
CDN serves signed media.

Worker classes:
1. generation-worker
2. layer-worker
3. upscale-worker
4. qa-worker
5. render-worker
6. media-worker

Workers must be idempotent, retry with exponential backoff, and move poison jobs to a DLQ.
