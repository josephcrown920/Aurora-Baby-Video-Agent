create table if not exists projects (id text primary key, name text not null, user_id text, created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists assets (id text primary key, project_id text references projects(id), kind text not null, url text, metadata jsonb default '{}', created_at timestamptz default now());
create table if not exists jobs (id text primary key, project_id text references projects(id), type text not null, status text not null, progress int default 0, attempts int default 0, max_attempts int default 3, provider text, model text, payload jsonb default '{}', result jsonb, error text, created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists timelines (id text primary key, project_id text references projects(id), version int not null, document jsonb not null, created_at timestamptz default now());
create table if not exists credit_ledger (id text primary key, user_id text not null, job_id text, delta bigint not null, reason text not null, created_at timestamptz default now());
create index if not exists jobs_status_idx on jobs(status,created_at);
create index if not exists assets_project_idx on assets(project_id,created_at);
