# Replit deploy now

1. Import this ZIP into the Replit project.
2. Add the variables from `.env.example` as Replit Secrets.
3. Run `npm install`.
4. Run `npm run build`.
5. Start the web process with `npm start`.
6. Start the worker with `npm run worker` in a separate worker/deployment process.
7. Provision PostgreSQL and Redis and set DATABASE_URL/REDIS_URL.
8. Configure S3-compatible object storage and CDN.
9. Deploy the Vast GPU worker with `vast/worker-entrypoint.sh` and connect it to Redis/S3.
10. Install the exact ComfyUI checkpoints/workflows on Vast.
11. Run the ModelArk Seedream → Seedance smoke test.
12. Enable FAL/Replicate as fallbacks.
13. Run integration/E2E tests and load tests before public launch.
