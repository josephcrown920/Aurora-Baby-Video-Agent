# FilmStudio AI — Production V4

This build combines the agent, editor, provider router, ModelArk integration, layer system,
upscale system, ComfyUI contracts, Replit control plane and Vast GPU worker contract.

## End-to-end capabilities

1. Natural-language brief → production plan
2. Research → script → storyboard → shot list
3. Character/environment/style bibles
4. Seedream reference generation
5. Seedance image-to-video handoff
6. Camera and behavior specification
7. Multi-candidate generation and scoring
8. Continuity and frame QA
9. Targeted repair instead of blind full rerender
10. Layer decomposition/editing contract (up to 20 layers)
11. Object/character/outfit/background/relight edits
12. 2x / 4x upscale
13. Timeline editor with tracks and natural-language edit bar
14. Captions, TTS, music, avatar and stock adapters
15. FFmpeg mastering
16. Reframe/repurpose/export
17. Redis durable queues + processing lists + DLQ
18. PostgreSQL project/job/asset/timeline/credit schema
19. S3-compatible media storage + CDN integration
20. Replit control plane + Vast/ComfyUI GPU plane
21. ModelArk CLI + server-side SDK integration
22. Provider routing: ModelArk / FAL / Replicate / Vast

## Important production boundary

The ZIP cannot contain external account credentials, licensed stock subscriptions, provider-side
model permissions, or GPU instances. Those are injected as Replit Secrets/environment variables.
Model weights should be installed on the GPU worker and pinned by revision.

## Quick start on Replit

```bash
npm install
npm run build
npm start
```

Worker:

```bash
npm run worker
```

ModelArk:

```bash
npm run modelark:install
python scripts/modelark-cli.py image "cinematic product hero"
```

## Live vertical slice

Configure ARK_API_KEY, MODELARK_IMAGE_MODEL, MODELARK_VIDEO_MODEL and SEEDANCE_ENDPOINT.
Then run `python scripts/live-vertical-slice.py "..."`.

## Security

Never commit provider keys. Any key pasted into chat, screenshots, logs or a repository should be
revoked/rotated and replaced with a new secret before production deployment.
