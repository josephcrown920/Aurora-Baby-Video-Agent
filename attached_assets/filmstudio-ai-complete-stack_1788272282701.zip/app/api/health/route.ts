import { NextResponse } from "next/server";
export async function GET(){
  return NextResponse.json({
    ok:true,
    service:"filmstudio-ai",
    time:new Date().toISOString(),
    integrations:{
      fal:Boolean(process.env.FAL_KEY),
      replicate:Boolean(process.env.REPLICATE_API_TOKEN),
      vast:Boolean(process.env.VAST_API_KEY),
      database:Boolean(process.env.DATABASE_URL),
      redis:Boolean(process.env.REDIS_URL),
      storage:Boolean(process.env.S3_ENDPOINT)
    }
  });
}
