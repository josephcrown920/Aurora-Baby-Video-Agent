import {z} from "zod";
export const CameraSchema=z.object({
 framing:z.string().default("medium"), angle:z.string().default("eye-level"),
 lensMm:z.number().min(8).max(300).default(50), movement:z.string().default("static"),
 speed:z.string().default("natural"), stabilization:z.string().default("cinematic"),
 dof:z.string().default("natural"), focusTarget:z.string().default("subject")
});
export const ShotSchema=z.object({
 id:z.string(), scene:z.number(), duration:z.number().positive(), prompt:z.string(),
 camera:CameraSchema, behavior:z.object({emotion:z.string(),beats:z.array(z.string())}),
 continuity:z.object({lockedAssets:z.array(z.string()),previousState:z.string(),endingState:z.string()})
});
export const AgentCommandSchema=z.object({
 projectId:z.string().optional(), command:z.string().min(1), constraints:z.record(z.string(),z.any()).optional()
});
export const GenerationSchema=z.object({
 projectId:z.string(), prompt:z.string().min(1), modality:z.enum(["video","image","voice","music","sfx","avatar","upscale"]),
 durationSeconds:z.number().optional(), width:z.number().optional(), height:z.number().optional(),
 referenceAssetIds:z.array(z.string()).optional(), preferredProvider:z.string().optional()
});
export type Shot=z.infer<typeof ShotSchema>;
