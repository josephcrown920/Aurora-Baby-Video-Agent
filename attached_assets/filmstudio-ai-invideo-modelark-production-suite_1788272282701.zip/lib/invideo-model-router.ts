import catalog from "../config/invideo-model-catalog.json";

export type ShotNeed =
  | "dialogue"|"motion"|"character_consistency"|"reference_heavy"|"cinematic"
  | "image"|"image_edit"|"upscale"|"avatar"|"voice"|"music"|"sfx";

const strengths:Record<ShotNeed,string[]> = {
 dialogue:["google-veo-3.1","sora-2-pro","kling-3.0"],
 motion:["kling-3.0","seedance-2.0","seedance-2.5"],
 character_consistency:["seedance-2.5","seedance-2.0","kling-3.0"],
 reference_heavy:["seedance-2.5","seedance-2.0","kling-3.0-omni-video"],
 cinematic:["google-veo-3.1","sora-2-pro","runway-gen-4.5"],
 image:["recraft-v4","nano-banana-pro","gpt-image-2"],
 image_edit:["qwen-image-edit-plus","gpt-image-2","recraft-v4"],
 upscale:["topaz-astra","topaz-video-upscaler","seedvr-video-upscaler"],
 avatar:["heygen-photo-avatar","kling-lipsync","runway-act-two"],
 voice:["elevenlabs-voice"],
 music:["elevenlabs-music"],
 sfx:["mmaudio-v2","pixverse-sfx"]
};

export function chooseInVideoStyleModel(need:ShotNeed){
  const ids=strengths[need]||[];
  return ids.map(id=>catalog.models.find((m:any)=>m.id===id)).filter(Boolean)[0] || catalog.models[0];
}
export function rankModels(need:ShotNeed, budget:"low"|"balanced"|"quality"="balanced"){
  const ids=strengths[need]||[];
  return catalog.models
    .filter((m:any)=>m.modality==="video" && (need==="image" ? false : true))
    .map((m:any)=>{
      let score=m.quality*.4+m.consistency*.3+(1-m.relativeCost)*.2;
      const rank=ids.indexOf(m.id); if(rank>=0)score+=(ids.length-rank)*.05;
      if(budget==="quality")score+=m.quality*.15;
      if(budget==="low")score+=(1-m.relativeCost)*.15;
      return {...m,score};
    }).sort((a:any,b:any)=>b.score-a.score);
}
