import {MODEL_REGISTRY} from "./provider-registry";
export type RouterRequest={modality:string;needsIdentity?:boolean;needsCameraControl?:boolean;needsReferences?:boolean;budget:"low"|"balanced"|"quality"};
export function routeModel(r:RouterRequest){
  const candidates=MODEL_REGISTRY.filter(m=>m.modalities.includes(r.modality as any));
  return candidates.map(m=>{
    let score=m.quality*.35+m.consistency*.25+(1-m.latency)*.1+(1-m.cost)*.15;
    if(r.needsReferences&&m.supportsReferences)score+=.08;
    if(r.needsIdentity&&m.provider==="vast-gpu")score+=.08;
    if(r.needsCameraControl&&m.provider==="vast-gpu")score+=.10;
    if(r.budget==="low")score+=(1-m.cost)*.15;
    if(r.budget==="quality")score+=m.quality*.15;
    return {model:m,score};
  }).sort((a,b)=>b.score-a.score)[0]?.model;
}
