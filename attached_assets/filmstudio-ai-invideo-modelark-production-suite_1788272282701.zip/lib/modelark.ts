export interface ModelArkRequest {
  prompt:string; model?:string; duration?:number; width?:number; height?:number;
  images?:string[]; seed?:number; extra?:Record<string,unknown>;
}
export async function modelArkGenerate(req:ModelArkRequest){
  if(!process.env.BYTEPLUS_API_KEY) throw new Error("BYTEPLUS_API_KEY is not configured");
  const base=process.env.BYTEPLUS_BASE_URL;
  if(!base) throw new Error("BYTEPLUS_BASE_URL is not configured");
  const r=await fetch(`${base.replace(/\/$/,"")}/contents/generations/tasks`,{
    method:"POST",
    headers:{"Authorization":`Bearer ${process.env.BYTEPLUS_API_KEY}`,"Content-Type":"application/json"},
    body:JSON.stringify({model:req.model||process.env.MODELARK_VIDEO_MODEL,input:req.prompt,images:req.images,duration:req.duration,width:req.width,height:req.height,seed:req.seed,...req.extra})
  });
  const body=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(`ModelArk ${r.status}: ${body?.message||body?.error||"request failed"}`);
  return body;
}
