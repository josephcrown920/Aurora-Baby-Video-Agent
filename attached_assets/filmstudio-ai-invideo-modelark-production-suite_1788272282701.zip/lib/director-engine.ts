export type Shot = {
  id:string; scene:number; duration:number; prompt:string;
  camera:{framing:string;angle:string;lensMm:number;movement:string;speed:string};
  behavior:{emotion:string;beats:string[]};
  continuity:{lockedAssets:string[];previousState:string;endingState:string};
};
export type DirectorBrief = {
  concept:string; duration:number; aspectRatio:string;
  styleBible:Record<string,string>; characterBible:Record<string,string>;
  locationBible:Record<string,string>;
};
const coverage=["establishing","master","medium","close-up","detail"];
export function buildDirectorPlan(b:DirectorBrief):Shot[]{
  const count=Math.max(3,Math.ceil(b.duration/8));
  return Array.from({length:count},(_,i)=>{
    const framing=coverage[i%coverage.length];
    const lens={establishing:24,master:35,medium:50,"close-up":85,detail:100}[framing]||50;
    return {
      id:`shot-${i+1}`,scene:Math.floor(i/3)+1,duration:Math.min(8,b.duration-i*8>0?b.duration-i*8:8),
      prompt:`${b.concept}; ${JSON.stringify(b.styleBible)}; preserve ${JSON.stringify(b.characterBible)}`,
      camera:{framing,angle:i%4===0?"low-angle":"eye-level",lensMm:lens,movement:i%3===0?"slow push-in":"controlled tracking",speed:"cinematic"},
      behavior:{emotion:"context-appropriate",beats:["establish","action","hold"]},
      continuity:{lockedAssets:Object.keys(b.characterBible),previousState:i?"previous shot approved state":"none",endingState:"carry forward identity, wardrobe, lighting and location"}
    };
  });
}
export function continuityDelta(previous:Shot|undefined,current:Shot){
  if(!previous)return {ok:true,issues:[]};
  const issues:string[]=[];
  if(previous.continuity.endingState!==current.continuity.previousState) issues.push("state handoff mismatch");
  if(previous.camera.lensMm!==current.camera.lensMm) issues.push("lens change");
  return {ok:issues.length===0,issues};
}
