import {query} from "./db";
export async function reserveCredits(userId:string,amount:number,jobId?:string){
 const r=await query<{credits:number}>("UPDATE users SET credits=credits-$2 WHERE id=$1 AND credits >= $2 RETURNING credits",[userId,amount]);
 if(!r.rows.length)return false;
 await query("INSERT INTO credit_ledger(user_id,job_id,delta,reason) VALUES($1,$2,$3,$4)",[userId,jobId||null,-amount,"reservation"]);
 return true;
}
export async function refundCredits(userId:string,amount:number,jobId?:string){
 await query("UPDATE users SET credits=credits+$2 WHERE id=$1",[userId,amount]);
 await query("INSERT INTO credit_ledger(user_id,job_id,delta,reason) VALUES($1,$2,$3,$4)",[userId,jobId||null,amount,"refund"]);
}
