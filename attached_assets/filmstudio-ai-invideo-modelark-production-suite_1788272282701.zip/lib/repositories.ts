import {query} from "./db";
export async function createProject(userId:string,name:string){
 const r=await query<{id:string}>("INSERT INTO projects(user_id,name) VALUES($1,$2) RETURNING id",[userId,name]); return r.rows[0];
}
export async function saveJob(j:{projectId:string;type:string;provider?:string;model?:string;payload?:unknown}){
 const r=await query<{id:string}>(
 "INSERT INTO jobs(project_id,type,provider,model,payload) VALUES($1,$2,$3,$4,$5) RETURNING id",
 [j.projectId,j.type,j.provider||null,j.model||null,j.payload||{}]); return r.rows[0];
}
export async function updateJob(id:string,status:string,progress:number,result:unknown={},error?:string){
 await query("UPDATE jobs SET status=$2,progress=$3,result=$4,error=$5,updated_at=now() WHERE id=$1",[id,status,progress,result,error||null]);
}
