export const AGENT_TOOLS=[
 "create_project","inspect_project","write_script","build_storyboard","plan_coverage",
 "compile_shot","search_stock","generate_image","generate_video","generate_voice",
 "generate_music","generate_sfx","generate_avatar","transcribe","translate",
 "add_to_slate","edit_timeline","replace_shot","reframe","caption","run_qa",
 "score_candidates","repair_shot","render","export","create_version"
] as const;
export type AgentTool=typeof AGENT_TOOLS[number];
export const STATE_MACHINE=["brief","plan","script","storyboard","coverage","generation","assembly","qa","revision","render","delivery"] as const;
