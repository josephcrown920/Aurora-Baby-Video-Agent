export interface LiveGenerationInput {
 prompt:string; durationSeconds?:number; width?:number; height?:number;
 referenceAssetIds?:string[]; camera?:Record<string,unknown>; seed?:number;
}
export interface LiveGenerationResult {
 provider:string; model:string; status:"queued"|"running"|"complete"|"failed";
 requestId?:string; outputUrl?:string; error?:string;
}
export interface LiveProvider {name:string; generate(input:LiveGenerationInput):Promise<LiveGenerationResult>;}

async function jsonFetch(url:string,init:RequestInit){
 const r=await fetch(url,init); const text=await r.text();
 let body:any; try{body=JSON.parse(text)}catch{body={raw:text}};
 if(!r.ok) throw new Error(`${r.status}: ${body?.detail||body?.error||text}`);
 return body;
}

export const falProvider:LiveProvider={
 name:"fal",
 async generate(input){
   if(!process.env.FAL_KEY||!process.env.FAL_MODEL_ENDPOINT) return {provider:"fal",model:process.env.FAL_MODEL_ENDPOINT||"unset",status:"failed",error:"FAL_KEY/FAL_MODEL_ENDPOINT not configured"};
   try{
     const body=await jsonFetch(process.env.FAL_MODEL_ENDPOINT,{method:"POST",headers:{"Authorization":`Key ${process.env.FAL_KEY}`,"Content-Type":"application/json"},body:JSON.stringify(input)});
     return {provider:"fal",model:process.env.FAL_MODEL_ENDPOINT,requestId:body.request_id||body.id,status:"queued",outputUrl:body.video?.url||body.output?.url};
   }catch(e){return {provider:"fal",model:process.env.FAL_MODEL_ENDPOINT,status:"failed",error:String(e)}}
 }
};

export const replicateProvider:LiveProvider={
 name:"replicate",
 async generate(input){
   if(!process.env.REPLICATE_API_TOKEN||!process.env.REPLICATE_MODEL)return {provider:"replicate",model:process.env.REPLICATE_MODEL||"unset",status:"failed",error:"REPLICATE_API_TOKEN/REPLICATE_MODEL not configured"};
   try{
     const body=await jsonFetch("https://api.replicate.com/v1/predictions",{method:"POST",headers:{"Authorization":`Bearer ${process.env.REPLICATE_API_TOKEN}`,"Content-Type":"application/json"},body:JSON.stringify({version:process.env.REPLICATE_MODEL,input})});
     return {provider:"replicate",model:process.env.REPLICATE_MODEL,requestId:body.id,status:body.status==="succeeded"?"complete":"queued",outputUrl:Array.isArray(body.output)?body.output[0]:body.output};
   }catch(e){return {provider:"replicate",model:process.env.REPLICATE_MODEL,status:"failed",error:String(e)}}
 }
};

export const vastProvider:LiveProvider={
 name:"vast-gpu",
 async generate(input){
   if(!process.env.VAST_API_KEY||!process.env.VAST_GENERATION_ENDPOINT)return {provider:"vast-gpu",model:process.env.VAST_MODEL||"unset",status:"failed",error:"VAST_API_KEY/VAST_GENERATION_ENDPOINT not configured"};
   try{
     const body=await jsonFetch(process.env.VAST_GENERATION_ENDPOINT,{method:"POST",headers:{"Authorization":`Bearer ${process.env.VAST_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({model:process.env.VAST_MODEL,input})});
     return {provider:"vast-gpu",model:process.env.VAST_MODEL||"comfyui",requestId:body.id||body.job_id,status:"queued",outputUrl:body.output_url};
   }catch(e){return {provider:"vast-gpu",model:process.env.VAST_MODEL||"comfyui",status:"failed",error:String(e)}}
 }
};
