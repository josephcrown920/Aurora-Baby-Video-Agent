# FilmStudio AI — Ultimate Individual Video Agent

## What this build is

This is the consolidated prototype/productionization package for the **individual autonomous
video agent** we have been building. The benchmark is the current InVideo capability model,
but the implementation is independent.

The design goal is:

> Give one agent a creative brief and let it plan, generate, direct, edit, revise and deliver
> the finished video while preserving project memory and human control.

## End-to-end flow

```text
BRIEF
  ↓
INTENT
  ↓
PRODUCER PLAN
  ↓
SCRIPT
  ↓
STORYBOARD
  ↓
COVERAGE PLAN
  ↓
DIRECTOR / CAMERA COMPILER
  ↓
MODEL ROUTER
  ├── FAL
  ├── REPLICATE
  └── VAST GPU / COMFYUI
  ↓
IMAGE / VIDEO / STOCK / VOICE / MUSIC / SFX / AVATAR
  ↓
SLATE TIMELINE
  ↓
CAPTIONS / TRANSLATION / REFRAME
  ↓
VISUAL + AUDIO QA
  ↓
TARGETED REGENERATION
  ↓
FFMPEG RENDER
  ↓
PLATFORM EXPORTS
```

## Agent roles

One visible agent internally operates specialized roles:

- Producer
- Writer
- Storyboard artist
- Director
- Cinematographer
- Asset/stock researcher
- Editor
- Sound designer
- Voice director
- Colorist
- QA supervisor
- Revision supervisor

## Director engine

`lib/director-engine.ts` turns a brief into structured shots.

Each shot includes:
- scene
- duration
- framing
- angle
- lens
- movement
- speed
- subject behavior
- emotional state
- temporal beats
- continuity state
- locked assets
- style references

The director engine is designed to prevent the common AI-video failure mode where every
shot looks like it came from a different film.

## Camera control

Supported camera concepts include:
- static
- pan
- tilt
- dolly
- truck
- pedestal
- crane
- orbit
- arc
- tracking
- handheld
- whip pan
- rack focus
- dolly zoom
- low/high/eye-level/Dutch/bird's-eye/worm's-eye
- 14–135mm lens language
- depth of field
- focus targets
- motion blur
- stabilization
- lighting and haze

## Behavior system

The agent can represent:
- starting pose
- gaze
- facial expression
- emotional state
- body movement
- hand action
- prop interaction
- environment interaction
- beat-by-beat action
- ending pose
- next-shot continuity state

## Continuity engine

The project maintains:
- character identity
- wardrobe
- location
- props
- lighting
- camera grammar
- approved references
- previous shot state
- next shot intent

The agent can regenerate one shot without throwing away the rest of the project.

## Model router

The router chooses based on:
- modality
- quality
- consistency
- latency
- cost
- references
- identity requirements
- camera-control requirements
- budget

Vast/ComfyUI receives a quality/control advantage for identity and custom camera workflows.

## Multi-candidate generation

Important shots can request multiple candidates. The intended production loop is:

generate → score → inspect → select → lock → continue.

This prevents the first generated clip from automatically becoming canon.

## Backend

Included architecture:
- Postgres
- Redis
- async worker
- SSE progress
- webhook endpoints
- object storage contract
- FFmpeg render contract
- credits/ledger contract
- health endpoint
- Docker
- Compose
- CI
- tests
- security headers

## Product surface

The capability layer includes:
- prompt-to-video
- script-to-video
- URL-to-video
- image-to-video
- image generation
- stock
- Notebook
- Slate
- natural-language editing
- voice
- voice cloning
- music
- SFX
- avatars
- captions
- translation/dubbing
- templates
- brand kits
- repurposing
- thumbnails
- enhancement
- background/face tools
- QA
- autonomous revision
- projects/assets/versions
- collaboration
- credits
- model routing
- FAL
- Replicate
- Vast/ComfyUI

## How to run

```bash
npm install
npm run dev
```

Production:

```bash
npm run typecheck
npm test
npm run build
npm start
```

Infrastructure:

```bash
docker compose up --build
```

Worker:

```bash
npm run worker
```

## Required environment

See `.env.example`.

At minimum for live generation:
- FAL key/endpoints
- Replicate token/model versions
- Vast GPU/ComfyUI endpoint

For production:
- Postgres
- Redis
- S3-compatible storage
- FFmpeg worker
- auth
- billing
- stock
- TTS/music/avatar services
- monitoring

## What is still left after this build

### External provisioning
These cannot be created by code alone:
1. Live FAL credentials/model endpoints
2. Live Replicate credentials/model versions
3. Live Vast GPU instance
4. Actual ComfyUI model files/workflows
5. Production Postgres instance
6. Production Redis
7. S3/object storage account
8. CDN
9. Licensed stock account
10. TTS/music/avatar accounts
11. Auth provider
12. Payment/billing provider

### Engineering hardening
These are the remaining production engineering tasks:
13. Wire every provider adapter to real vendor SDK/API responses
14. Persist all job events in Postgres
15. Replace local in-memory stores with Postgres repositories
16. Implement queue retries/dead-letter queues
17. Implement actual FFmpeg render worker
18. Implement real frame sampling + vision QA
19. Implement real candidate scoring
20. Implement conflict-safe collaboration
21. Complete authentication/authorization
22. Complete credit reservation/settlement/refunds
23. Add signed uploads/downloads
24. Add production rate limits
25. Add moderation policy and review queues
26. Add load tests and provider integration tests
27. Deploy staging + production
28. Add observability/alerts
29. Security audit
30. UX polish and accessibility

## Highest-value upgrades already added

- Director engine
- Structured shot schema
- Camera compiler
- Behavior system
- Continuity engine
- Model router
- Candidate generation
- Cost estimation
- Smart reframe contract
- Agent tool registry
- State machine
- Feedback endpoint
- Moderation endpoint
- Voice/music endpoints
- Production health
- SSE progress
- Webhooks
- Docker/Compose
- CI/test foundation

## Next major differentiators

1. **Visual Continuity AI** — compare frames against character/style/location bibles.
2. **Director-grade camera control** — compile shot intent into model-specific controls.
3. **Autonomous coverage** — decide the minimum set of shots needed to tell the story.
4. **Parallel model competition** — FAL vs Replicate vs Vast candidates scored automatically.
5. **Creative memory** — remember approved creative language across projects.
6. **Campaign factory** — one master video automatically becomes ads, Shorts, Reels,
   TikToks, thumbnails and alternate aspect ratios.
7. **ComfyUI workflow marketplace** — specialized internal workflows selected by the agent.
8. **Edit compiler** — natural-language changes become reversible timeline diffs.
9. **Visual QA** — frame-level detection of identity drift, artifacts, continuity and composition.
10. **Cost intelligence** — live price/queue-aware routing.

## Product north star

The user should eventually be able to say:

> "Make a 90-second cinematic launch film. Use my brand, keep the same character throughout,
> start with a 24mm aerial establishing shot, move into 35mm tracking coverage, use 85mm
> close-ups for emotional beats, build the sound design, add narration, create captions,
> generate three versions of the hero shot, pick the best one, then export 16:9, 9:16 and
> 1:1 versions."

The agent should execute that as one production job with transparent progress and editable
human checkpoints.

That is the target architecture.
