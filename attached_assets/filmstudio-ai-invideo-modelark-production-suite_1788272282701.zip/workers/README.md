# Worker topology

Production should run separate worker pools:

- `generation` — FAL / Replicate / ModelArk / Vast
- `render` — FFmpeg
- `qa` — frame sampling + visual/audio analysis
- `media` — thumbnails, transcodes, captions, translation
- `stock` — licensed stock search/licensing
- `cleanup` — orphaned assets and expired files

Redis is the transport. Postgres is the durable source of truth.
Object storage is the media source of truth.

Workers must be idempotent, retryable and capable of dead-lettering.
