import {spawn} from "node:child_process";
export function renderWithFfmpeg(input:string,output:string){
 return new Promise<void>((resolve,reject)=>{
  const p=spawn("ffmpeg",["-y","-i",input,"-c:v","libx264","-pix_fmt","yuv420p","-c:a","aac",output],{stdio:"inherit"});
  p.on("exit",code=>code===0?resolve():reject(new Error(`ffmpeg exited ${code}`)));
  p.on("error",reject);
 });
}
