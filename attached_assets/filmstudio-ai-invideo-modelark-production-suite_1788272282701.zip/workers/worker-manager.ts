export const QUEUES=["generation","render","qa","media","stock","cleanup"] as const;
export type QueueName=typeof QUEUES[number];
export function workerConfig(name:QueueName){
  return {name,concurrency:Number(process.env[`WORKER_${name.toUpperCase()}_CONCURRENCY`]||2),maxAttempts:3};
}
