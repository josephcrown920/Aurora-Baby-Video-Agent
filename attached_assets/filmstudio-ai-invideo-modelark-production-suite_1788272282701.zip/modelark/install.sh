npm install -g @byteplus/ark-cli
