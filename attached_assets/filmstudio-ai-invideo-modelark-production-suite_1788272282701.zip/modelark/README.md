# BytePlus ModelArk CLI integration

ModelArk provides BytePlus model access and an official CLI/coding package. The
project treats ModelArk as a first-class provider in the same router as FAL,
Replicate and Vast.

## Install

```bash
npm install -g @byteplus/ark-cli
```

The ModelArk Coding Plan page currently documents this package and installation.

## Configuration

Use environment variables or the ModelArk CLI's own authenticated configuration.
Do not put tokens in source control.

Recommended project variables:

```bash
BYTEPLUS_API_KEY=
BYTEPLUS_BASE_URL=
BYTEPLUS_REGION=ap-southeast-1
MODELARK_VIDEO_MODEL=seedance-2.5
MODELARK_IMAGE_MODEL=
MODELARK_TEXT_MODEL=
```

## Role in FilmStudio AI

ModelArk is used for:
- Seedance video generation
- ByteDance image/video models exposed through ModelArk
- agent text/reasoning where configured
- provider-side model discovery

The agent does not hard-code a single model. Model IDs remain configuration.

## CLI

Use the CLI for local model/provider diagnostics and developer workflows. For
production generation, use a server-side API adapter so jobs, credits, retries,
webhooks and audit records remain inside FilmStudio AI.

## Security

Never send BYTEPLUS_API_KEY to the browser. Store it only in the server/worker
environment or a secrets manager.
