# FilmStudio AI — InVideo Model + ModelArk Production Layer

## Why this layer exists

Current InVideo publicly describes a 200+ model roster and per-shot model routing.
Its public model catalog includes models across video, image, audio, avatar/lip-sync
and finishing. The FilmStudio router now has a maintained catalog and specialization
layer so the individual agent can select a model by shot requirements.

## Current public InVideo model families represented

### Video
- Google Veo 3.1 / 3.1 Fast / 3 / 3 Fast / 2
- Kling 3.0 / 3.0 Omni / 3.0 Turbo / Motion Control
- Kling 2.6 / 2.6 Motion Control
- Seedance 2.5 / 2.0 / 2.0 Fast / 1.5 Pro
- Runway Gen-4.5 / Gen-4 Aleph / Act-Two
- PixVerse 5.6 / 5.5 / V6 / C1
- Wan 2.6 / 2.5 / 2.5 Preview / Animate variants
- MiniMax Hailuo variants
- Sora 2 / Sora 2 Pro
- LTX variants
- Grok Imagine Video variants
- Firefly Video
- P-Video variants
- HappyHorse variants
- Higgsfield
- other models in the public catalog

### Image
- Recraft V4
- Nano Banana Pro
- GPT-Image-2
- Qwen Image Edit Plus
- FLUX family
- additional catalog image models

### Finishing / audio / avatar
- Topaz Astra / Video Upscaler
- FlashVSR
- SeedVR
- ByteDance Video Upscaler
- ElevenLabs music/voice
- HeyGen avatar/lipsync
- Kling/PixVerse/VEED/Rapid lipsync
- MMAudio
- PixVerse SFX

The exact provider/version mapping is configuration, because vendor endpoints and
availability change. Do not hard-code private endpoint URLs.

## Model routing philosophy

The agent should route per shot, not per project.

Examples:

- dialogue + synchronized audio → Veo 3.1
- motion-heavy/reference-heavy shot → Kling or Seedance
- character-consistent narrative → Seedance
- high-control custom workflow → Vast/ComfyUI
- image/character sheet → Recraft / Nano Banana / GPT-Image-2
- finishing/upscale → Topaz-class tools
- voice → ElevenLabs-class provider
- avatar/lipsync → HeyGen/Kling/etc.

These are routing defaults, not hard rules.

## BytePlus ModelArk

ModelArk is added as a first-class provider, particularly for ByteDance/Seedance
workflows.

Developer CLI package:

```bash
npm install -g @byteplus/ark-cli
```

Production environment:

```bash
BYTEPLUS_API_KEY=
BYTEPLUS_BASE_URL=
BYTEPLUS_REGION=ap-southeast-1
MODELARK_VIDEO_MODEL=seedance-2.5
```

The CLI is useful for developer workflows and diagnostics. Production generation
should use a server-side adapter so FilmStudio controls:
- credits
- retries
- job state
- audit logs
- provider routing
- webhooks
- artifact storage

## Storage architecture

Postgres:
- users
- projects
- assets
- jobs
- credit ledger
- versions

Redis:
- queues
- live job events
- worker coordination

S3-compatible storage:
- uploaded references
- generated images/video
- renders
- thumbnails
- captions
- audio

CDN:
- signed media delivery

## Worker architecture

Separate queues:
- generation
- render
- QA
- media
- stock
- cleanup

The generation queue can route to:
FAL → Replicate → ModelArk → Vast/ComfyUI.

The QA queue can inspect generated frames and send failures back to generation.

The render queue creates final deliverables.

## Upgrades included in the wider build

- director engine
- camera compiler
- behavior engine
- continuity graph
- model router
- multi-candidate generation
- cost estimator
- smart reframe
- creative memory
- agent tool registry
- production state machine
- Postgres
- Redis
- workers
- S3 adapter
- Docker
- CI
- webhooks
- SSE progress
- credits
- FFmpeg worker contract
- production health
- upgrade roadmap

## Remaining work

The codebase now contains the architecture and integration surfaces. The remaining
work is primarily live provisioning and production hardening:

1. supply actual API keys/model IDs
2. configure exact FAL endpoints for selected models
3. configure Replicate versions
4. configure ModelArk API/base URL and production model IDs
5. deploy Vast GPU + ComfyUI workflows
6. deploy Postgres/Redis/S3/CDN
7. connect licensed stock
8. connect real TTS/music/avatar providers
9. complete authentication/billing
10. run live integration/e2e/load tests
11. implement frame-level visual QA
12. implement durable retries/dead-letter queues
13. finish production collaboration and moderation
14. security audit
15. deploy staging then production

This is the point where real provider credentials and infrastructure determine the
last mile rather than another architectural rewrite.
