# Upgrade plan

## Highest-value upgrades

### Visual Continuity AI
Use sampled frames + reference embeddings to compare:
identity, wardrobe, props, location, lighting, lens language and style.

### Director Engine v2
Add deterministic shot grammar, coverage selection, scene blocking,
camera-path generation and model-specific camera parameter translation.

### Multi-model competition
Generate candidates across FAL, Replicate and Vast, score them against the
shot specification, and automatically lock the winner.

### Edit compiler
Translate natural-language commands into reversible Slate timeline diffs.

### Creative memory
Persist approved character, style, camera, location and brand rules across projects.

### Campaign factory
One master project → hero video + Shorts + Reels + TikTok + ads + thumbnails,
with shared identity and style state.

### Workflow marketplace
Version and select ComfyUI workflows automatically based on shot requirements.

### Autonomous cost control
Use live provider cost/latency/queue data to choose execution strategy.

### Human checkpoints
Allow the user to lock or override:
script, storyboard, hero shots, voice, music, final render.

### Production reliability
Add dead-letter queues, distributed locks, idempotency keys, signed media URLs,
backpressure, autoscaling, load tests and disaster recovery.
