import {NextRequest,NextResponse} from "next/server"; import {chooseInVideoStyleModel,rankModels} from "../../../../lib/invideo-model-router";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json({recommended:chooseInVideoStyleModel(b.need||"cinematic"),alternatives:rankModels(b.need||"cinematic",b.budget||"balanced").slice(0,10)});}
