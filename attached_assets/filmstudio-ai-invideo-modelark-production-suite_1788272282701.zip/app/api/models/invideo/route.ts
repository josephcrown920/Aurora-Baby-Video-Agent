import {NextResponse} from "next/server"; import catalog from "../../../../config/invideo-model-catalog.json";
export async function GET(){return NextResponse.json(catalog);}
