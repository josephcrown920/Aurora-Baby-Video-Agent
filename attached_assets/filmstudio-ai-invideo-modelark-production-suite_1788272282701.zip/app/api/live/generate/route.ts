import {NextRequest,NextResponse} from "next/server";
import {GenerationSchema} from "../../../../lib/schemas";
import {falProvider,replicateProvider,vastProvider} from "../../../../lib/live-providers";
import {routeModel} from "../../../../lib/model-router";

export async function POST(req:NextRequest){
 const parsed=GenerationSchema.safeParse(await req.json().catch(()=>null));
 if(!parsed.success)return NextResponse.json({error:parsed.error.flatten()},{status:400});
 const b=parsed.data;
 const model=routeModel({modality:b.modality,needsReferences:!!b.referenceAssetIds?.length,needsIdentity:!!b.referenceAssetIds?.length,needsCameraControl:b.modality==="video",budget:"balanced"});
 const provider=model?.provider==="fal"?falProvider:model?.provider==="replicate"?replicateProvider:vastProvider;
 return NextResponse.json({selected:model,result:await provider.generate(b)},{status:202});
}
