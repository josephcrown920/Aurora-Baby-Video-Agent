import {NextRequest,NextResponse} from "next/server"; import {continuityDelta} from "../../../../lib/director-engine";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json(continuityDelta(b.previous,b.current));}
