import {NextRequest,NextResponse} from "next/server"; import {modelArkGenerate} from "../../../../lib/modelark";
export async function POST(req:NextRequest){const b=await req.json();try{return NextResponse.json({status:"queued",provider:"byteplus-modelark",result:await modelArkGenerate(b)},{status:202});}catch(e){return NextResponse.json({error:String(e)},{status:503});}}
