import {NextRequest,NextResponse} from "next/server";
import {AgentCommandSchema} from "../../../../lib/schemas";
import {createAgentRun} from "../../../../lib/orchestrator";
export async function POST(req:NextRequest){
 const parsed=AgentCommandSchema.safeParse(await req.json().catch(()=>null));
 if(!parsed.success)return NextResponse.json({error:parsed.error.flatten()},{status:400});
 return NextResponse.json(createAgentRun(parsed.data.command,parsed.data.projectId),{status:202});
}
