import {NextRequest,NextResponse} from "next/server";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json({allowed:true,flags:[],assetId:b.assetId||null});}
