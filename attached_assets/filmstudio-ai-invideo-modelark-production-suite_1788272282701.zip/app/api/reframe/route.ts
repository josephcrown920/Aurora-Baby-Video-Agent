import {NextRequest,NextResponse} from "next/server";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json({jobId:crypto.randomUUID(),status:"queued",targets:b.targets||["9:16","1:1","4:5","16:9"],strategy:"subject-aware smart reframe"});}
