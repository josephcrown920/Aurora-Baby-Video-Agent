import {NextRequest,NextResponse} from "next/server";
export async function POST(req:NextRequest){const b=await req.json();const seconds=Number(b.seconds)||30;const shots=Number(b.shots)||Math.ceil(seconds/6);return NextResponse.json({shots,estimatedCredits:shots*10,range:{min:shots*5,max:shots*25}});}
