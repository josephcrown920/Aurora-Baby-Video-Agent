import {NextRequest,NextResponse} from "next/server";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json({jobId:crypto.randomUUID(),status:"queued",duration:b.duration||30,mood:b.mood||"cinematic"});}
