import {NextRequest,NextResponse} from "next/server";
import {buildDirectorPlan} from "../../../../lib/director-engine";
export async function POST(req:NextRequest){
 const b=await req.json().catch(()=>({}));
 if(!b.concept)return NextResponse.json({error:"concept required"},{status:400});
 return NextResponse.json({shots:buildDirectorPlan({
   concept:b.concept,duration:Number(b.duration)||30,aspectRatio:b.aspectRatio||"16:9",
   styleBible:b.styleBible||{},characterBible:b.characterBible||{},locationBible:b.locationBible||{}
 })});
}
