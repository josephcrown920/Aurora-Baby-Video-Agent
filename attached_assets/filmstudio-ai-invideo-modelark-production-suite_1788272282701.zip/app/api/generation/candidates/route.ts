import {NextRequest,NextResponse} from "next/server";
export async function POST(req:NextRequest){const b=await req.json();const n=Math.min(8,Math.max(2,Number(b.count)||4));return NextResponse.json({candidates:Array.from({length:n},(_,i)=>({id:crypto.randomUUID(),rank:i+1,status:"queued"}))});}
