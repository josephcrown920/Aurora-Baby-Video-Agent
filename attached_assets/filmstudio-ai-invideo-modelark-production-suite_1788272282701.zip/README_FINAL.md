# FilmStudio AI — Final Production Suite

## Mission

An independent individual autonomous video agent benchmarked against the current
InVideo product surface. The objective is end-to-end production, not merely
prompt-to-video.

## End-to-end behavior

Brief → intent → production plan → script → storyboard → coverage → director →
camera/behavior compiler → model router → generation/stock → Slate → audio/voice →
captions/translation → QA → targeted revision → render → platform variants.

## What this package now contains

### Agent
- structured orchestration
- tool registry
- state machine
- project memory contracts
- director planning
- camera compiler
- behavior/continuity
- model routing
- candidate generation
- cost estimation
- feedback
- QA/revision surfaces

### Model layer
- FAL live HTTP adapter
- Replicate live prediction adapter
- Vast GPU/ComfyUI live HTTP adapter
- provider selection
- webhook surfaces
- SSE progress
- environment configuration

### Backend
- Postgres schema/repositories
- Redis queue/events
- worker architecture
- credits/ledger
- render worker
- Docker/Compose
- CI
- health endpoint

### Media/product
- Slate editor surface
- Notebook surface
- stock contract
- URL-to-video
- repurposing
- captions
- translation
- avatars
- voice/music
- templates
- brand kits
- assets
- versions
- collaboration
- thumbnails
- moderation

## Camera system

Each shot can explicitly encode:
framing, angle, focal length, movement, speed, stabilization, DOF, focus target,
lighting, atmosphere, behavior, emotion, beats, continuity and negative constraints.

## Model routing

The router can favor Vast/ComfyUI when identity/reference/camera control matters,
while using hosted providers for speed or model diversity.

## Live integrations

Live FAL, Replicate and Vast execution is environment-driven. The code does not
contain or invent credentials.

Set:
- FAL_KEY
- FAL_MODEL_ENDPOINT
- REPLICATE_API_TOKEN
- REPLICATE_MODEL
- VAST_API_KEY
- VAST_GENERATION_ENDPOINT
- VAST_MODEL

## Run

```bash
npm install
npm run dev
```

Production:
```bash
npm run typecheck
npm test
npm run build
npm start
```

Infrastructure:
```bash
docker compose up --build
```

Worker:
```bash
npm run worker
```

## What is left

### Must be provisioned externally
1. Actual provider credentials/model IDs.
2. Vast GPU instance and ComfyUI checkpoints/workflows.
3. Production Postgres/Redis.
4. S3-compatible storage and CDN.
5. Licensed stock.
6. TTS/music/avatar providers.
7. Auth provider.
8. Billing provider.

### Must still be hardened/connected in engineering
1. Replace remaining prototype stores with Postgres repositories.
2. Fully implement vendor-specific FAL polling/webhook semantics for chosen models.
3. Fully implement Replicate polling/webhook verification.
4. Implement the exact Vast/ComfyUI workflow payloads and artifact uploads.
5. Implement durable Redis worker retries/dead-letter queues.
6. Implement real FFmpeg render orchestration and media download/upload.
7. Implement real frame sampling and visual QA.
8. Implement candidate scoring against actual outputs.
9. Implement production auth/authorization.
10. Implement signed object-storage URLs.
11. Implement real credit pricing and settlement.
12. Implement production collaboration/presence.
13. Complete moderation and abuse prevention.
14. Complete integration/e2e/load tests against live services.
15. Deploy staging and production.
16. Security audit and disaster recovery.

## Important status

This package is the **productionized source foundation**, including live-provider
integration seams and infrastructure scaffolding. It is not honest to call it a
fully deployed production SaaS until the external services above are provisioned
and the live integrations are tested end-to-end.

## Upgrade roadmap

The next differentiation layer is:
Visual Continuity AI → Director v2 → multi-model competition → edit compiler →
creative memory → campaign factory → ComfyUI workflow marketplace → autonomous
cost control → human checkpoints → production reliability.

The north star is one command producing an editable, consistent, multi-shot,
multi-format finished video while the agent transparently manages the underlying
production pipeline.
