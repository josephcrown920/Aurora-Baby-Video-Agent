# Live BytePlus vertical slice

This build contains the first real end-to-end provider test:

**ModelArk/Seedream → reference URL → Seedance task**

## Configure

```bash
export ARK_API_KEY='YOUR_ROTATED_KEY'
export ARK_BASE_URL='https://ark.ap-southeast.bytepluses.com/api/v3'
export MODELARK_IMAGE_MODEL='seedream-4-5-251128'
export MODELARK_VIDEO_MODEL='YOUR_ENABLED_SEEDANCE_MODEL'
export SEEDANCE_ENDPOINT='YOUR_ENABLED_SEEDANCE_TASK_ENDPOINT'
```

Install the Python SDK used by the server-side integration:

```bash
pip install --upgrade 'byteplussdkarkruntime'
```

Run:

```bash
python scripts/live-vertical-slice.py "Create an 8-second cinematic hero shot..."
```

Or use the deployed API:

`POST /api/production/live-vertical-slice`

with:

```json
{
  "brief":"Create an 8-second cinematic hero shot",
  "characterPrompt":"A consistent lead character in a black tailored outfit",
  "shotPrompt":"Slow dolly-in, 50mm lens, shallow depth of field, dramatic rim light",
  "duration":8,
  "ratio":"16:9"
}
```

The endpoint returns the Seedream reference URL and the Seedance task response.

## Production safety

Never commit `ARK_API_KEY`. Rotate keys that have been exposed in chat,
screenshots, logs or repositories.
