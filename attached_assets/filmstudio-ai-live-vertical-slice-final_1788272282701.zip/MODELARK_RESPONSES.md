# BytePlus ModelArk Responses API

FilmStudio now supports the BytePlus ModelArk Responses API as a first-class
reasoning/web-research layer.

## Endpoint

`POST /api/modelark/responses`

The server forwards supported Responses API fields to:

`https://ark.ap-southeast.bytepluses.com/api/v3/responses`

## Web search

`POST /api/modelark/web-search`

Example payload:

```json
{"prompt":"What are the latest developments in AI video generation?"}
```

The server invokes ModelArk's `web_search` tool.

## Reasoning

The agent can use the Responses API for:
- brief interpretation
- creative planning
- research
- shot planning
- model selection reasoning
- continuity analysis
- production decisions

## Security

Never place `ARK_API_KEY` in frontend code, git, client-side JavaScript,
screenshots, or public repositories. Rotate any key that has been exposed
outside a private secret store.

The API base URL and model are configurable through environment variables.
