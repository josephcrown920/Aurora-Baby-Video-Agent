# Deploy both: Agent UI + ModelArk/Seedance/Seedream

1. Install Python SDK:
   `pip install --upgrade 'byteplussdkarkruntime'`
2. Set server environment:
   `ARK_API_KEY`, `ARK_BASE_URL`, `ARK_REASONING_MODEL`,
   `MODELARK_IMAGE_MODEL=seedream-4-5-251128`,
   and the exact enabled Seedance model/endpoint.
3. Deploy the app and workers with the same environment.
4. Open `/agent` for the Individual Agent workspace.
5. Create a test brief. The UI calls `/api/modelark/responses`.
6. Seedream references are generated server-side and can feed Seedance.
7. Keep all provider keys out of client code and git.

The UI is intentionally provider-agnostic: users see the production workflow,
while the router selects the underlying model.
