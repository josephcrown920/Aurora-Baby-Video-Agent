# Character + Storyboard → Seedream → Seedance

## Canonical flow

1. ModelArk Responses interprets the brief.
2. FilmStudio creates a Character Bible and World Bible.
3. Seedream creates canonical reference images.
4. Approved reference assets are locked in the project.
5. Storyboard compiler creates shot specifications.
6. Each shot inherits identity/wardrobe/world locks.
7. Seedance receives the shot prompt plus approved reference image(s).
8. Generated video is sampled and scored.
9. Failed shots are regenerated with targeted changes.
10. Approved shots enter Slate.
11. FFmpeg renders final deliverables.

## Character lock

Do not regenerate identity unnecessarily. A character reference is a versioned
asset. New wardrobe/location states should preserve the identity lock.

## Storyboard lock

A storyboard frame is the visual contract for a shot:
framing, angle, lens, movement, lighting, behavior, environment, dialogue and
continuity.

## Provider behavior

Seedream is the preferred reference/image layer when configured.
Seedance is the preferred BytePlus video layer when configured.
FAL/Replicate/Vast/ComfyUI remain fallbacks or specialized execution paths.

## Credentials

Use `ARK_API_KEY` only on the server/worker. Never expose it in browser code.
Pin exact model IDs and endpoints from the BytePlus account.
