import os
from .client import responses

def plan_video(brief: str):
    return responses(
        [
          {"role":"system","content":"You are FilmStudio's autonomous producer/director. Return a structured production plan: intent, scenes, shots, camera, behavior, continuity, audio, model choices, QA, and delivery formats."},
          {"role":"user","content":[{"type":"input_text","text":brief}]}
        ],
        model=os.getenv("ARK_REASONING_MODEL","deepseek-v4-pro-ga-260813"),
    )
