import os, requests

def generate_video(prompt:str, image_urls:list[str]|None=None, model=None, **kwargs):
    key=os.environ["ARK_API_KEY"]
    base=os.getenv("SEEDANCE_BASE_URL",os.getenv("ARK_BASE_URL","https://ark.ap-southeast.bytepluses.com/api/v3")).rstrip("/")
    endpoint=os.getenv("SEEDANCE_ENDPOINT",f"{base}/contents/generations/tasks")
    payload={"model":model or os.getenv("MODELARK_VIDEO_MODEL"),"prompt":prompt}
    if image_urls: payload["image_urls"]=image_urls
    payload.update({k:v for k,v in kwargs.items() if v is not None})
    r=requests.post(endpoint,headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"},json=payload,timeout=60)
    r.raise_for_status()
    return r.json()
