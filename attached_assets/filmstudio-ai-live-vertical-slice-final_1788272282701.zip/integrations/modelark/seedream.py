import os
from byteplussdkarkruntime import Ark

def client():
    return Ark(
        base_url=os.getenv("ARK_BASE_URL","https://ark.ap-southeast.bytepluses.com/api/v3"),
        api_key=os.environ["ARK_API_KEY"],
    )

def generate_reference(prompt:str, model:str|None=None, size:str="2K", watermark:bool=False):
    response=client().images.generate(
        model=model or os.getenv("MODELARK_IMAGE_MODEL","seedream-4-5-251128"),
        prompt=prompt,
        sequential_image_generation="disabled",
        response_format="url",
        size=size,
        stream=False,
        watermark=watermark,
    )
    return response.data[0].url
