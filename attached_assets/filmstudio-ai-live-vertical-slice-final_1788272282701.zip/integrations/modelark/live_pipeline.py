import os, json
from .seedream import generate_reference
from .seedance import generate_video

def run_vertical_slice(brief: str, character_prompt: str, shot_prompt: str):
    """
    Live-provider vertical slice:
      Seedream reference -> Seedance video.
    ModelArk Responses remains the planning/brain layer in the app.
    """
    reference_url = generate_reference(
        character_prompt,
        model=os.getenv("MODELARK_IMAGE_MODEL","seedream-4-5-251128"),
        size=os.getenv("MODELARK_IMAGE_SIZE","2K"),
        watermark=os.getenv("MODELARK_IMAGE_WATERMARK","false").lower()=="true",
    )
    video = generate_video(
        prompt=shot_prompt,
        image_urls=[reference_url],
        model=os.getenv("MODELARK_VIDEO_MODEL"),
    )
    return {"brief":brief,"reference_url":reference_url,"seedance":video}
