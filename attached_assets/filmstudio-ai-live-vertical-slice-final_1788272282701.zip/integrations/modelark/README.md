# BytePlus ModelArk SDK

Install:
```bash
pip install --upgrade 'byteplus-python-sdk-v2'
```

Used server-side for the ModelArk Responses/reasoning layer. Keep ARK_API_KEY private.
