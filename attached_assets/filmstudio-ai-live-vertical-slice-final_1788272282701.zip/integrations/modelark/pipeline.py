import os
from .seedream import generate_reference
from .seedance import generate_video

def character_to_video(character_prompt:str, shot_prompt:str, image_model=None, video_model=None):
    ref=generate_reference(character_prompt, model=image_model)
    result=generate_video(
        prompt=shot_prompt,
        image_urls=[ref],
        model=video_model,
    )
    return {"reference_url":ref,"video":result}
