import os
from typing import Any
from byteplus import BytePlus

def get_client():
    return BytePlus(
        api_key=os.environ["ARK_API_KEY"],
        base_url=os.getenv("ARK_BASE_URL","https://ark.ap-southeast.bytepluses.com/api/v3"),
    )

def responses(input_data: Any, model: str|None=None, tools: list[dict]|None=None):
    c=get_client()
    return c.responses.create(
        model=model or os.getenv("ARK_REASONING_MODEL","deepseek-v4-pro-ga-260813"),
        input=input_data,
        tools=tools,
    )

def web_search(prompt: str):
    return responses(
        [{"role":"user","content":[{"type":"input_text","text":prompt}]}],
        tools=[{"type":"web_search","max_keyword":3}],
    )
