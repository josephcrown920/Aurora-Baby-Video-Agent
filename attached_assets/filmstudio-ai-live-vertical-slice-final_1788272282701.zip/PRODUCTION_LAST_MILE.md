# Production last-mile checklist

## Provider activation
- Configure FAL key and exact endpoint/model IDs.
- Configure Replicate token and pinned model versions.
- Configure BytePlus ModelArk API key/base URL/model IDs.
- Provision Vast GPU and install pinned ComfyUI workflows/checkpoints.
- Test one real image, video, voice and edit job per provider.

## Data plane
- Create managed Postgres and run `db/001_init.sql` plus migrations.
- Create managed Redis.
- Create private S3-compatible bucket.
- Configure lifecycle/retention and signed delivery.
- Put CDN in front of media delivery.

## Workers
- Run separate generation, render, QA, media, stock and cleanup pools.
- Enable retries and dead-letter queues.
- Make every job idempotent.
- Persist job events/results.
- Use FFmpeg in the render pool, never inside the request handler.

## QA
- Sample generated frames.
- Run identity, continuity, camera, artifact and text-artifact checks.
- Rank multiple candidates.
- Automatically regenerate only failed shots.
- Require final render QA before delivery.

## Security
- Production auth and role checks.
- Never expose provider secrets to browser.
- Signed object URLs.
- MIME/size validation.
- Rate limiting.
- Audit logs.
- Secret rotation.
- Backups and restore drills.

## Release
- Staging environment first.
- Provider sandbox tests.
- Load test generation queue.
- Canary deployment.
- Monitor error rate, latency, queue depth, spend and render failures.
- Promote to production only after the complete brief→render test passes.
