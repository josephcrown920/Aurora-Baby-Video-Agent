import os, sys, json
from integrations.modelark.live_pipeline import run_vertical_slice

if __name__=="__main__":
    required=["ARK_API_KEY","MODELARK_IMAGE_MODEL","MODELARK_VIDEO_MODEL"]
    missing=[x for x in required if not os.getenv(x)]
    if missing:
        print("Missing:", ", ".join(missing))
        print("Configure the real BytePlus values before running the live test.")
        sys.exit(2)
    brief=sys.argv[1] if len(sys.argv)>1 else "Create a cinematic 8-second character-driven shot."
    result=run_vertical_slice(
        brief=brief,
        character_prompt="Create a canonical cinematic character reference for this production: "+brief,
        shot_prompt="Create a cinematic video shot from the approved character reference. Preserve identity, wardrobe and proportions. "+brief
    )
    print(json.dumps(result,indent=2))
