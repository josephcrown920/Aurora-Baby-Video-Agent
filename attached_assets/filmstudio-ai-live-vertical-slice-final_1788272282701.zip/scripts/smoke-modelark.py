import os, sys
from integrations.modelark.seedream import generate_reference

if __name__=="__main__":
    if not os.getenv("ARK_API_KEY"):
        print("ARK_API_KEY not configured; smoke test not executed.")
        sys.exit(2)
    print(generate_reference("cinematic neutral character reference, production turnaround, no text"))
