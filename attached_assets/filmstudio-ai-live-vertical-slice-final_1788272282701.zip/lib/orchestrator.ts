import {AGENT_TOOLS} from "./agent-tools";
import {routeModel} from "./model-router";
import {arkReason} from "./modelark-responses";

export type Stage="understand"|"plan"|"script"|"storyboard"|"coverage"|"generate"|"assemble"|"qa"|"revise"|"render"|"deliver";
export interface AgentRun {id:string; projectId?:string; input:string; stage:Stage; steps:string[]; selectedModels:unknown[]; createdAt:string;}

export async function reasonOverBrief(input:string){ return arkReason(`You are the FilmStudio producer/director brain. Analyze this brief, identify intent, constraints, scenes, shots, models, continuity risks, and production steps. Return structured JSON when possible.\n\nBRIEF:\n${input}`);}\n\nexport function createAgentRun(input:string,projectId?:string):AgentRun{
  return {id:crypto.randomUUID(),projectId,input,stage:"understand",steps:[
    "understand_intent","create_production_plan","write_script","build_storyboard",
    "plan_coverage","compile_camera_behavior","generate_or_retrieve_assets",
    "assemble_slate","run_visual_audio_qa","revise_failed_shots","render","deliver"
  ],selectedModels:[
    routeModel({modality:"video",needsReferences:true,needsIdentity:true,needsCameraControl:true,budget:"balanced"})
  ],createdAt:new Date().toISOString()};
}

export function allowedTool(tool:string){return (AGENT_TOOLS as readonly string[]).includes(tool);}
