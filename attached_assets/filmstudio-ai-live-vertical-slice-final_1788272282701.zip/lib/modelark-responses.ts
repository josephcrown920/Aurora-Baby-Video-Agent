export interface ArkResponseInput {
  model?: string;
  input: unknown;
  tools?: unknown[];
  stream?: boolean;
  thinking?: {type:"enabled"|"disabled"};
  previousResponseId?: string;
  extra?: Record<string,unknown>;
}

const base = () => (process.env.ARK_BASE_URL || "https://ark.ap-southeast.bytepluses.com/api/v3").replace(/\/$/,"");

export async function arkResponses(input: ArkResponseInput) {
  const key = process.env.ARK_API_KEY;
  if (!key) throw new Error("ARK_API_KEY is not configured");

  const payload:any = {
    model: input.model || process.env.ARK_REASONING_MODEL || "deepseek-v4-pro-ga-260813",
    input: input.input,
    ...(input.tools ? {tools: input.tools} : {}),
    ...(input.stream !== undefined ? {stream: input.stream} : {}),
    ...(input.thinking ? {thinking: input.thinking} : {}),
    ...(input.previousResponseId ? {previous_response_id: input.previousResponseId} : {}),
    ...(input.extra || {})
  };

  const r = await fetch(`${base()}/responses`, {
    method:"POST",
    headers:{
      "Authorization":`Bearer ${key}`,
      "Content-Type":"application/json"
    },
    body:JSON.stringify(payload)
  });

  const body = await r.json().catch(()=>({}));
  if (!r.ok) {
    throw new Error(`ModelArk Responses ${r.status}: ${body?.error?.message || body?.message || "request failed"}`);
  }
  return body;
}

export async function arkWebSearch(prompt:string) {
  return arkResponses({
    input:[{
      role:"user",
      content:[{type:"input_text",text:prompt}]
    }],
    tools:[{type:"web_search",max_keyword:3}]
  });
}

export async function arkReason(prompt:string) {
  return arkResponses({
    input:[{
      role:"user",
      content:[{type:"input_text",text:prompt}]
    }],
    thinking:{type:"enabled"}
  });
}
