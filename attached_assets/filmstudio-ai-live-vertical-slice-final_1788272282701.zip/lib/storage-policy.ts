export function objectKey(projectId:string,kind:string,filename:string){
  const safe=filename.replace(/[^a-zA-Z0-9._-]/g,"_");
  return `projects/${projectId}/${kind}/${crypto.randomUUID()}-${safe}`;
}
export function assertMime(mime:string){
  const allowed=["video/","image/","audio/","text/","application/pdf"];
  if(!allowed.some(p=>mime.startsWith(p)))throw new Error("Unsupported media type");
}
