import {falProvider,replicateProvider,vastProvider} from "./live-providers";
import {modelArkGenerate} from "./modelark";
export async function generateWithFallback(input:any,order=("modelark,fal,replicate,vast").split(",")){
  const errors:any[]=[];
  for(const name of order){
    try{
      if(name==="modelark")return {provider:name,result:await modelArkGenerate(input)};
      const p=name==="fal"?falProvider:name==="replicate"?replicateProvider:vastProvider;
      const r=await p.generate(input);
      if(r.status!=="failed")return {provider:name,result:r};
      errors.push({provider:name,error:r.error});
    }catch(e){errors.push({provider:name,error:String(e)});}
  }
  throw new Error(JSON.stringify({message:"All providers failed",errors}));
}
