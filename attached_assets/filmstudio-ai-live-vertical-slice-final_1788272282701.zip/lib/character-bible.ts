export interface CharacterBible {
  id:string; name:string; identityLocks:string[]; physical:string[];
  face:string[]; hair:string[]; wardrobe:string[]; accessories:string[];
  expressions:string[]; poses:string[]; negative:string[];
  approvedReferenceAssetIds:string[]; version:number;
}
export function characterReferencePrompt(c:CharacterBible,shotContext:string){
 return [
  `Create a production reference image for character "${c.name}".`,
  `IDENTITY LOCKS: ${c.identityLocks.join("; ")}`,
  `PHYSICAL: ${c.physical.join("; ")}`,
  `FACE: ${c.face.join("; ")}`,
  `HAIR: ${c.hair.join("; ")}`,
  `WARDROBE: ${c.wardrobe.join("; ")}`,
  `ACCESSORIES: ${c.accessories.join("; ")}`,
  `EXPRESSION/POSE: ${[...c.expressions,...c.poses].join("; ")}`,
  `NEGATIVE: ${c.negative.join("; ")}`,
  `SHOT CONTEXT: ${shotContext}`,
  `Preserve identity and proportions. Do not invent logos, text or accessories.`
 ].join("\n");
}
