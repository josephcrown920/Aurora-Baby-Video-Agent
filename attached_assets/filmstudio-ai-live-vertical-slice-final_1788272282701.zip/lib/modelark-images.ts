export interface ModelArkImageRequest {
  model?: string; prompt: string;
  sequential_image_generation?: "disabled"|"auto";
  response_format?: "url"|"b64_json"; size?: string; stream?: boolean;
  watermark?: boolean; extra?: Record<string,unknown>;
}
const base=()=> (process.env.ARK_BASE_URL||"https://ark.ap-southeast.bytepluses.com/api/v3").replace(/\/$/,"");
export async function modelArkImageGenerate(input:ModelArkImageRequest){
  const key=process.env.ARK_API_KEY; if(!key) throw new Error("ARK_API_KEY is not configured");
  const payload={model:input.model||process.env.MODELARK_IMAGE_MODEL||"seedream-4-5-251128",
    prompt:input.prompt,sequential_image_generation:input.sequential_image_generation||"disabled",
    response_format:input.response_format||"url",size:input.size||"2K",
    stream:input.stream??false,watermark:input.watermark??false,...(input.extra||{})};
  const r=await fetch(`${base()}/images/generations`,{method:"POST",
    headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},
    body:JSON.stringify(payload)});
  const body=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(`ModelArk Images ${r.status}: ${body?.error?.message||body?.message||"request failed"}`);
  return body;
}
