export type JobStatus="queued"|"running"|"succeeded"|"failed"|"cancelled";
export type QueueName="generation"|"render"|"qa"|"media"|"stock"|"cleanup";
export interface JobEnvelope<T=unknown>{
  id:string; queue:QueueName; type:string; projectId:string; userId?:string;
  idempotencyKey:string; attempts:number; maxAttempts:number; payload:T;
  createdAt:string; updatedAt:string;
}
export interface JobEvent{jobId:string;status:JobStatus;progress:number;message?:string;data?:unknown;at:string;}
