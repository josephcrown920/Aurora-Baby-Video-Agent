export const productionConfig={
  maxGenerationAttempts:Number(process.env.MAX_GENERATION_ATTEMPTS||3),
  maxRenderAttempts:Number(process.env.MAX_RENDER_ATTEMPTS||2),
  signedUrlSeconds:Number(process.env.SIGNED_URL_SECONDS||900),
  maxUploadMb:Number(process.env.MAX_UPLOAD_MB||512),
  publicBaseUrl:process.env.PUBLIC_BASE_URL||"",
  environment:process.env.NODE_ENV||"development"
};
export function assertProductionSecrets(){
  if(productionConfig.environment!=="production")return;
  const required=["AUTH_SECRET","DATABASE_URL","REDIS_URL","S3_BUCKET"];
  const missing=required.filter(k=>!process.env[k]);
  if(missing.length)throw new Error(`Missing production secrets: ${missing.join(", ")}`);
}
