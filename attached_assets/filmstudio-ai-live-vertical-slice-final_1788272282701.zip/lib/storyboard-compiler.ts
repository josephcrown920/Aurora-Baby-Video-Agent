export interface StoryboardFrame {
 id:string; scene:number; shot:number; duration:number; description:string;
 dialogue?:string; characterIds:string[]; referenceAssetIds:string[];
 camera:{framing:string;angle:string;lensMm:number;movement:string;speed:string;dof:string;focus:string};
 lighting:string; environment:string; behavior:string; transition?:string;
}
export function compileStoryboardToShots(frames:StoryboardFrame[]){
 return frames.map(f=>({
   id:`s${f.scene}-sh${f.shot}`,scene:f.scene,shot:f.shot,duration:f.duration,
   generationPrompt:[
    f.description,`Camera: ${f.framing||f.camera.framing}, ${f.camera.angle}, ${f.camera.lensMm}mm, ${f.camera.movement}, ${f.camera.speed}.`,
    `DOF: ${f.camera.dof}; focus: ${f.camera.focus}.`,
    `Lighting: ${f.lighting}. Environment: ${f.environment}.`,
    `Behavior: ${f.behavior}.`,
    f.dialogue?`Dialogue/lip-sync intent: ${f.dialogue}`:"",
    "Maintain all approved character and world continuity locks."
   ].filter(Boolean).join("\n"),
   referenceAssetIds:f.referenceAssetIds,
   camera:f.camera,characterIds:f.characterIds
 }));
}
