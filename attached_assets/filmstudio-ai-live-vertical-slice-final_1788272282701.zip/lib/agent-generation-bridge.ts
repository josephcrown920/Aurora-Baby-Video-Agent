import {arkReason} from "./modelark-responses";
import {generateWithFallback} from "./model-fallback";

export async function planAndGenerate(brief:string,generationInput:any){
  const plan=await arkReason(`You are FilmStudio's producer/director brain.
Analyze this brief and return a structured production plan including scenes,
shots, camera language, character continuity, behavior, audio and model choice.
BRIEF:\n${brief}`);
  const generated=await generateWithFallback(generationInput);
  return {plan,generated};
}
