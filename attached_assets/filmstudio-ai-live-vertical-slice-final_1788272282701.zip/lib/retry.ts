export async function withRetry<T>(fn:()=>Promise<T>,opts:{maxAttempts?:number;baseMs?:number}={}){
  const max=opts.maxAttempts??3, base=opts.baseMs??500;
  let last:unknown;
  for(let attempt=1;attempt<=max;attempt++){
    try{return await fn()}catch(e){last=e;if(attempt<max)await new Promise(r=>setTimeout(r,base*2**(attempt-1)));}
  }
  throw last;
}
