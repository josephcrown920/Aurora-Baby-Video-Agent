export interface Candidate{
  id:string; visualQuality:number; identity:number; motion:number; promptCompliance:number;
  continuity:number; artifactFree:number; cost:number; latency:number;
}
export function rankCandidates(candidates:Candidate[]){
  return candidates.map(c=>{
    const score=.24*c.visualQuality+.20*c.identity+.14*c.motion+.16*c.promptCompliance+
      .14*c.continuity+.12*c.artifactFree+.06*(1-Math.min(1,c.cost))+.04*(1-Math.min(1,c.latency));
    return {...c,score};
  }).sort((a,b)=>b.score-a.score);
}
