export type EditOperation=
  | {op:"replace_shot";shotId:string;prompt:string}
  | {op:"trim";shotId:string;start?:number;end?:number}
  | {op:"reframe";shotId:string;aspectRatio:string}
  | {op:"replace_audio";assetId:string}
  | {op:"set_camera";shotId:string;camera:Record<string,unknown>}
  | {op:"lock";entity:string;value:string};
export function compileNaturalEdit(command:string):EditOperation[]{
  const c=command.toLowerCase(), ops:EditOperation[]=[];
  const shot=c.match(/shot\s+(\d+)/)?.[1];
  if(c.includes("replace")&&shot)ops.push({op:"replace_shot",shotId:`shot-${shot}`,prompt:command});
  if(c.includes("reframe"))ops.push({op:"reframe",shotId:shot?`shot-${shot}`:"current",aspectRatio:c.includes("vertical")?"9:16":"16:9"});
  if(c.includes("music")||c.includes("audio"))ops.push({op:"replace_audio",assetId:"pending"});
  if(c.includes("keep the character")||c.includes("preserve character"))ops.push({op:"lock",entity:"character","value":"preserve approved identity"});
  return ops;
}
