export interface SeedanceTaskInput {
  model?: string; prompt: string; image_urls?: string[]; video_urls?: string[];
  duration?: number; ratio?: string; seed?: number; callback_url?: string;
  extra?: Record<string,unknown>;
}
const base=()=> (process.env.SEEDANCE_BASE_URL||"https://ark.ap-southeast.bytepluses.com/api/v3").replace(/\/$/,"");
const headers=()=>({"Authorization":`Bearer ${process.env.ARK_API_KEY||""}`,"Content-Type":"application/json"});
export async function createSeedanceTask(input:SeedanceTaskInput){
  if(!process.env.ARK_API_KEY) throw new Error("ARK_API_KEY is not configured");
  const endpoint=process.env.SEEDANCE_ENDPOINT||`${base()}/contents/generations/tasks`;
  const r=await fetch(endpoint,{method:"POST",headers:headers(),body:JSON.stringify({
    model:input.model||process.env.MODELARK_VIDEO_MODEL,
    prompt:input.prompt,
    ...(input.image_urls?.length?{image_urls:input.image_urls}:{}),
    ...(input.video_urls?.length?{video_urls:input.video_urls}:{}),
    ...(input.duration?{duration:input.duration}:{}),
    ...(input.ratio?{ratio:input.ratio}:{}),
    ...(input.seed!==undefined?{seed:input.seed}:{}),
    ...(input.callback_url?{callback_url:input.callback_url}:{}),
    ...(input.extra||{})
  })});
  const body=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(`Seedance create ${r.status}: ${body?.error?.message||body?.message||"request failed"}`);
  return body;
}
export async function getSeedanceTask(taskId:string){
  const endpoint=process.env.SEEDANCE_TASK_ENDPOINT
    ? process.env.SEEDANCE_TASK_ENDPOINT.replace("{taskId}",taskId)
    : `${base()}/contents/generations/tasks/${encodeURIComponent(taskId)}`;
  const r=await fetch(endpoint,{headers:headers()});
  const body=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(`Seedance status ${r.status}: ${body?.error?.message||body?.message||"request failed"}`);
  return body;
}
