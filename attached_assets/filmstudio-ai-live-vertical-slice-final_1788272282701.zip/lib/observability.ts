export function logEvent(event:string,data:Record<string,unknown>={}){
  console.log(JSON.stringify({event,at:new Date().toISOString(),...data}));
}
export function timer(name:string){
  const start=Date.now();
  return ()=>({name,durationMs:Date.now()-start});
}
