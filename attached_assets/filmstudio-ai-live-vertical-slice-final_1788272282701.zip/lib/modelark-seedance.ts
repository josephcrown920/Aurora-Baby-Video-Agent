export interface SeedanceInput{
 model?:string; prompt:string; imageUrls?:string[]; videoUrls?:string[];
 duration?:number; ratio?:string; seed?:number; callbackUrl?:string;
 extra?:Record<string,unknown>;
}
const base=()=> (process.env.SEEDANCE_BASE_URL||process.env.ARK_BASE_URL||"https://ark.ap-southeast.bytepluses.com/api/v3").replace(/\/$/,"");
export async function seedanceGenerate(input:SeedanceInput){
 const key=process.env.ARK_API_KEY;
 if(!key)throw new Error("ARK_API_KEY is not configured");
 const endpoint=process.env.SEEDANCE_ENDPOINT||`${base()}/contents/generations/tasks`;
 const payload={
   model:input.model||process.env.MODELARK_VIDEO_MODEL,
   prompt:input.prompt,
   ...(input.imageUrls?.length?{image_urls:input.imageUrls}:{}),
   ...(input.videoUrls?.length?{video_urls:input.videoUrls}:{}),
   ...(input.duration?{duration:input.duration}:{}),
   ...(input.ratio?{ratio:input.ratio}:{}),
   ...(input.seed!==undefined?{seed:input.seed}:{}),
   ...(input.callbackUrl?{callback_url:input.callbackUrl}:{}),
   ...(input.extra||{})
 };
 const r=await fetch(endpoint,{method:"POST",headers:{
   "Authorization":`Bearer ${key}`,"Content-Type":"application/json"
 },body:JSON.stringify(payload)});
 const body=await r.json().catch(()=>({}));
 if(!r.ok)throw new Error(`Seedance ${r.status}: ${body?.error?.message||body?.message||"request failed"}`);
 return body;
}
