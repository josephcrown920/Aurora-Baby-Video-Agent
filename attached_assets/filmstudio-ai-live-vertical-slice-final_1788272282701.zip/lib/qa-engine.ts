export interface FrameSignal{
  index:number; identityScore:number; compositionScore:number; artifactScore:number;
  textArtifactScore:number; continuityScore:number; cameraComplianceScore:number;
}
export interface QAScore{pass:boolean;score:number;issues:string[];signals:FrameSignal[];}
export function scoreFrameSignals(signals:FrameSignal[]):QAScore{
  if(!signals.length)return {pass:false,score:0,issues:["no frames sampled"],signals};
  const avg=(k:keyof FrameSignal)=>signals.reduce((s,x)=>s+Number(x[k]),0)/signals.length;
  const score=.22*avg("identityScore")+.16*avg("compositionScore")+.16*avg("artifactScore")+
    .12*avg("textArtifactScore")+.18*avg("continuityScore")+.16*avg("cameraComplianceScore");
  const issues:string[]=[];
  if(avg("identityScore")<.8)issues.push("identity drift");
  if(avg("compositionScore")<.75)issues.push("composition");
  if(avg("artifactScore")<.8)issues.push("visual artifacts");
  if(avg("textArtifactScore")<.8)issues.push("text artifacts");
  if(avg("continuityScore")<.8)issues.push("continuity");
  if(avg("cameraComplianceScore")<.8)issues.push("camera mismatch");
  return {pass:score>=.82 && issues.length<=1,score,issues,signals};
}
