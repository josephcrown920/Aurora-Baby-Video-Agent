export interface Principal{userId:string;roles:string[];}
export function requireRole(p:Principal,role:string){
  if(!p.roles.includes(role)&&!p.roles.includes("admin"))throw new Error("Forbidden");
  return p;
}
export function canEditProject(p:Principal,ownerId:string){return p.userId===ownerId||p.roles.includes("editor")||p.roles.includes("admin");}
