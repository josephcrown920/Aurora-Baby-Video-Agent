# ModelArk + Seedance + Seedream

FilmStudio now coordinates two BytePlus layers:

1. ModelArk Responses API for reasoning, research and production planning.
2. Seedance/Seedream generation through the configured BytePlus generation surface.

Flow:
Brief → ModelArk brain → scenes/shots/camera/behavior/continuity →
Seedream references → Seedance video → FAL/Replicate/Vast fallback →
QA/candidate scoring → Slate → FFmpeg → S3/CDN.

Install the Python SDK:
```bash
pip install --upgrade 'byteplus-python-sdk-v2'
```

Never commit ARK_API_KEY or other provider credentials.
