# Model routing matrix

The router is deliberately per-shot.

| Requirement | Preferred family | Fallback |
|---|---|---|
| Cinematic general | Veo / Sora / Runway | Kling / Seedance |
| Dialogue + native audio | Veo | Sora / Kling |
| Motion-heavy | Kling / Seedance | Wan / Hailuo |
| Character/reference-heavy | Seedance / Kling | Vast + ComfyUI |
| Custom camera/control | Vast + ComfyUI | Kling / Seedance |
| Image creation | Recraft / Nano Banana / GPT Image | FLUX |
| Image editing | Qwen Image Edit / GPT Image | Recraft |
| Voice | ElevenLabs | configured TTS provider |
| Music | ElevenLabs Music | configured music provider |
| Avatar/lip-sync | HeyGen / Kling / Runway | configured avatar provider |
| Upscale | Topaz / SeedVR / FlashVSR | configured enhancer |

Exact model availability and vendor IDs must be configured from the provider accounts.
