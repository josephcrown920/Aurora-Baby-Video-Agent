# Final integration status

## Implemented in source
- InVideo-style Individual Agent workspace
- ModelArk Responses reasoning + web-search layer
- Seedream 4.5 image-generation adapter
- Seedance task creation + task polling adapter
- Character Bible and reference locking
- Storyboard → shot compiler
- Seedream reference → Seedance handoff contract
- FAL/Replicate/Vast fallback
- frame QA and candidate scoring contracts
- Postgres/Redis/S3 architecture
- worker topology and retry primitives
- production provider status dashboard

## External activation still required
- set the real ARK_API_KEY
- set the exact Seedance model ID enabled on the account
- set SEEDANCE_ENDPOINT if the account uses a service-specific endpoint
- deploy the worker processes
- configure managed Postgres/Redis/S3
- configure FAL/Replicate/Vast credentials
- connect stock/TTS/music/avatar providers
- run live end-to-end generation
- load test and security audit

The application must not claim production-ready until the live acceptance test passes.
