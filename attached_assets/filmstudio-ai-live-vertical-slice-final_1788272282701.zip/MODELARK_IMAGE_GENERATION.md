# ModelArk Seedream image generation

FilmStudio now exposes a server-side ModelArk image generation route:
`POST /api/modelark/images/generations`.

Default model: `seedream-4-5-251128`.

Example:
```json
{"model":"seedream-4-5-251128","prompt":"cinematic production reference","sequential_image_generation":"disabled","response_format":"url","size":"2K","stream":false,"watermark":false}
```

The generated image can become a character reference, location reference,
storyboard frame, keyframe, wardrobe/style reference or image-to-video input.

Never expose `ARK_API_KEY` to the browser or commit it to source control.
