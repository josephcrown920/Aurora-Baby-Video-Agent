import {NextRequest,NextResponse} from "next/server";
import {modelArkImageGenerate} from "../../../../lib/modelark-images";
import {createSeedanceTask} from "../../../../lib/seedance-client";

export async function POST(req:NextRequest){
  const b=await req.json().catch(()=>null);
  if(!b?.brief)return NextResponse.json({error:"brief required"},{status:400});
  try{
    const ref=await modelArkImageGenerate({
      model:b.imageModel||process.env.MODELARK_IMAGE_MODEL||"seedream-4-5-251128",
      prompt:b.characterPrompt||`Create a canonical character reference for: ${b.brief}`,
      sequential_image_generation:"disabled",response_format:"url",
      size:b.size||"2K",stream:false,watermark:false
    });
    const referenceUrl=ref?.data?.[0]?.url;
    if(!referenceUrl)throw new Error("Seedream returned no reference URL");
    const video=await createSeedanceTask({
      model:b.videoModel||process.env.MODELARK_VIDEO_MODEL,
      prompt:b.shotPrompt||b.brief,
      image_urls:[referenceUrl],
      duration:b.duration||8,
      ratio:b.ratio||"16:9",
      callback_url:b.callbackUrl||process.env.SEEDANCE_CALLBACK_URL
    });
    return NextResponse.json({stage:"seedance_queued",referenceUrl,video},{status:202});
  }catch(e){
    return NextResponse.json({stage:"failed",error:String(e)},{status:502});
  }
}
