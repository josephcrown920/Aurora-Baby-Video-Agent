import {NextRequest,NextResponse} from "next/server";
import {characterReferencePrompt} from "../../../../../lib/character-bible";
import {seedanceGenerate} from "../../../../../lib/modelark-seedance";

export async function POST(req:NextRequest){
 const b=await req.json().catch(()=>null);
 if(!b?.character||!b?.shot)return NextResponse.json({error:"character and shot required"},{status:400});
 const referencePrompt=characterReferencePrompt(b.character,b.shot.context||b.shot.description||"");
 return NextResponse.json({
   stage:"reference_ready",
   referencePrompt,
   next:{
     imageModel:b.imageModel||process.env.MODELARK_IMAGE_MODEL||"seedream-4-5-251128",
     videoModel:b.videoModel||process.env.MODELARK_VIDEO_MODEL||"configured-seedance",
     action:"generate-reference-with-seedream-then-pass-reference-url-to-seedance"
   }
 });
}
