import {NextResponse} from "next/server";
const keys=["ARK_API_KEY","MODELARK_IMAGE_MODEL","MODELARK_VIDEO_MODEL","FAL_KEY","REPLICATE_API_TOKEN","VAST_API_KEY","DATABASE_URL","REDIS_URL","S3_BUCKET","AUTH_SECRET"];
export async function GET(){
 const configured=Object.fromEntries(keys.map(k=>[k,Boolean(process.env[k])]));
 const critical=["ARK_API_KEY","MODELARK_IMAGE_MODEL","MODELARK_VIDEO_MODEL","DATABASE_URL","REDIS_URL","S3_BUCKET"];
 return NextResponse.json({
   environment:process.env.NODE_ENV||"development",
   configured,
   configuredCritical:critical.every(k=>configured[k]),
   liveProviderVerification:"not-run",
   note:"Configuration is not proof of live provider success. Run the vertical-slice smoke test."
 });
}
