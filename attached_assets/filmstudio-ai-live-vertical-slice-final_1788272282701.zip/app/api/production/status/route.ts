import {NextResponse} from "next/server";
export async function GET(){
 const vars=["ARK_API_KEY","MODELARK_IMAGE_MODEL","MODELARK_VIDEO_MODEL","FAL_KEY","REPLICATE_API_TOKEN","VAST_API_KEY","DATABASE_URL","REDIS_URL","S3_BUCKET"];
 const status=Object.fromEntries(vars.map(k=>[k,Boolean(process.env[k])]));
 return NextResponse.json({providers:{
   modelark:{ready:status.ARK_API_KEY,models:[process.env.MODELARK_IMAGE_MODEL||"seedream-4-5-251128",process.env.MODELARK_VIDEO_MODEL||"not configured"]},
   fal:{ready:status.FAL_KEY},replicate:{ready:status.REPLICATE_API_TOKEN},
   vast:{ready:status.VAST_API_KEY},storage:{ready:status.S3_BUCKET},
   database:{ready:status.DATABASE_URL},queue:{ready:status.REDIS_URL}
 },environment:process.env.NODE_ENV||"development"});
}