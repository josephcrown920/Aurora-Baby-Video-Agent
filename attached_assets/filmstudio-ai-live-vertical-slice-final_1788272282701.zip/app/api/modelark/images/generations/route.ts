import {NextRequest,NextResponse} from "next/server";
import {modelArkImageGenerate} from "../../../../../lib/modelark-images";
export async function POST(req:NextRequest){
 const body=await req.json().catch(()=>null);
 if(!body?.prompt)return NextResponse.json({error:"prompt required"},{status:400});
 try{return NextResponse.json(await modelArkImageGenerate(body));}
 catch(e){return NextResponse.json({error:String(e)},{status:502});}
}
