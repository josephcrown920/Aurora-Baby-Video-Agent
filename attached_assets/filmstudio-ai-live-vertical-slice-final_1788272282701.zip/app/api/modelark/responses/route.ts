import {NextRequest,NextResponse} from "next/server";
import {arkResponses} from "../../../../lib/modelark-responses";

export async function POST(req:NextRequest){
  const body=await req.json().catch(()=>null);
  if(!body?.input)return NextResponse.json({error:"input required"},{status:400});
  try {
    const result=await arkResponses(body);
    return NextResponse.json(result);
  } catch(e) {
    return NextResponse.json({error:String(e)},{status:502});
  }
}
