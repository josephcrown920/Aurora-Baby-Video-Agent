import {NextResponse} from "next/server";
import {getSeedanceTask} from "../../../../../../lib/seedance-client";
export async function GET(_:Request,{params}:{params:Promise<{taskId:string}>}){
 const {taskId}=await params;
 try{return NextResponse.json(await getSeedanceTask(taskId))}
 catch(e){return NextResponse.json({error:String(e)},{status:502})}
}
