import {NextRequest,NextResponse} from "next/server";
import {arkWebSearch} from "../../../../lib/modelark-responses";
export async function POST(req:NextRequest){
 const b=await req.json().catch(()=>null);
 if(!b?.prompt)return NextResponse.json({error:"prompt required"},{status:400});
 try{return NextResponse.json(await arkWebSearch(b.prompt));}
 catch(e){return NextResponse.json({error:String(e)},{status:502});}
}
