import {NextRequest,NextResponse} from "next/server";
import {compileNaturalEdit} from "../../../../lib/edit-compiler";
export async function POST(req:NextRequest){
 const b=await req.json().catch(()=>({}));
 if(!b.command)return NextResponse.json({error:"command required"},{status:400});
 return NextResponse.json({operations:compileNaturalEdit(b.command),command:b.command});
}
