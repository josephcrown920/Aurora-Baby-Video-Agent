import {NextRequest,NextResponse} from "next/server";
import {generateWithFallback} from "../../../lib/model-fallback";
export async function POST(req:NextRequest){const b=await req.json();try{return NextResponse.json(await generateWithFallback(b,b.providerOrder));}catch(e){return NextResponse.json({error:String(e)},{status:503});}}
