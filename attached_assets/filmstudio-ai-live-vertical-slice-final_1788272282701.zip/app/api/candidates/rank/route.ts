import {NextRequest,NextResponse} from "next/server";
import {rankCandidates} from "../../../lib/candidate-scoring";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json({ranked:rankCandidates(b.candidates||[])});}
