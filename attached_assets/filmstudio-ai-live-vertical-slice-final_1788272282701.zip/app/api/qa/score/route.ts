import {NextRequest,NextResponse} from "next/server";
import {scoreFrameSignals} from "../../../lib/qa-engine";
export async function POST(req:NextRequest){const b=await req.json();return NextResponse.json(scoreFrameSignals(b.signals||[]));}
