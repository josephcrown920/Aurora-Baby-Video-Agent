"use client";
import {useEffect,useMemo,useState} from "react";

const nav=["Agent","Projects","Storyboard","Characters","Assets","Models","Render"];
const models=[
 ["Seedance 2.5","BytePlus","VIDEO"],
 ["Seedream 4.5","BytePlus","IMAGE"],
 ["Veo 3.1","Google","VIDEO"],
 ["Kling 3.0","Kling","VIDEO"],
 ["Runway Gen-4.5","Runway","VIDEO"],
];
const stages=["Brief","Research","Characters","Storyboard","References","Generation","QA","Render"];

export default function AgentPage(){
 const [brief,setBrief]=useState("");
 const [running,setRunning]=useState(false);
 const [status,setStatus]=useState("Ready");
 const [active,setActive]=useState("Agent");
 const [providers,setProviders]=useState<any>(null);
 useEffect(()=>{fetch("/api/production/status").then(r=>r.json()).then(setProviders).catch(()=>null)},[]);
 const ready=providers?.providers?.modelark?.ready;
 async function create(){
  if(!brief.trim())return;
  setRunning(true);setStatus("ModelArk is planning your production…");
  try{
   const r=await fetch("/api/modelark/responses",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({input:[{role:"user",content:[{type:"input_text",text:
    `Act as FilmStudio's autonomous producer/director. Plan this production end-to-end. Return scenes, shots, character bible, storyboard, camera, behavior, continuity locks, Seedream references, Seedance model choices, QA and final delivery.\n\n${brief}`}]}]})});
   if(!r.ok)throw new Error();
   setStatus("Production plan ready — generation can begin.");
  }catch{setStatus("ModelArk is not configured in this deployment.")}
  finally{setRunning(false)}
 }
 return <main className="min-h-screen bg-[#f5f5f7] text-[#111]">
  <div className="flex min-h-screen">
   <aside className="w-64 shrink-0 bg-[#fbfbfc] border-r border-black/5 p-5 hidden lg:flex flex-col">
    <div className="text-xl font-semibold tracking-[-.03em] mb-8">FilmStudio <span className="text-black/30">AI</span></div>
    <div className="space-y-1">{nav.map(x=><button onClick={()=>setActive(x)} key={x} className={`w-full text-left px-3 py-2.5 rounded-xl text-sm ${active===x?"bg-black text-white":"text-black/55 hover:bg-black/5"}`}>{x}</button>)}</div>
    <div className="mt-auto">
     <div className="text-[10px] tracking-[.18em] uppercase text-black/30 mb-2">Infrastructure</div>
     <div className="rounded-2xl bg-white border border-black/5 p-3 space-y-2 text-xs">
      {[
       ["ModelArk",providers?.providers?.modelark?.ready],
       ["FAL",providers?.providers?.fal?.ready],
       ["Replicate",providers?.providers?.replicate?.ready],
       ["Vast",providers?.providers?.vast?.ready],
       ["Postgres",providers?.providers?.database?.ready],
       ["Redis",providers?.providers?.queue?.ready],
       ["S3",providers?.providers?.storage?.ready],
      ].map(([n,v])=><div key={n} className="flex justify-between"><span>{n}</span><span className={v?"text-emerald-600":"text-amber-600"}>● {v?"Ready":"Setup"}</span></div>)}
     </div>
    </div>
   </aside>
   <section className="flex-1 min-w-0">
    <header className="h-16 bg-white border-b border-black/5 flex items-center justify-between px-5 md:px-8 sticky top-0 z-10">
     <div className="font-medium">{active}</div>
     <div className="flex items-center gap-2"><span className="text-xs text-black/35 hidden sm:block">{ready?"ModelArk connected":"ModelArk setup required"}</span><button onClick={()=>setActive("Agent")} className="px-4 py-2 rounded-xl bg-black text-white text-xs">New production</button></div>
    </header>
    <div className="max-w-7xl mx-auto p-5 md:p-8">
     <div className="flex items-center gap-2 overflow-x-auto pb-4">{stages.map((x,i)=><div key={x} className="flex items-center gap-2 shrink-0"><div className={`px-3 py-1.5 rounded-full text-[11px] ${i===0?"bg-black text-white":"bg-white border border-black/5 text-black/40"}`}>{x}</div>{i<stages.length-1&&<span className="text-black/15">→</span>}</div>)}</div>
     <div className="grid xl:grid-cols-[1.35fr_.65fr] gap-6">
      <div className="bg-white rounded-[28px] border border-black/5 p-6 md:p-8 shadow-[0_12px_40px_rgba(0,0,0,.04)]">
       <div className="text-[10px] uppercase tracking-[.2em] text-black/35 mb-3">Autonomous video agent</div>
       <h1 className="text-4xl md:text-6xl font-semibold tracking-[-.055em] leading-[.95] max-w-3xl">One brief.<br/>One production.</h1>
       <p className="mt-5 text-sm md:text-base text-black/45 max-w-2xl leading-6">FilmStudio researches, plans, builds characters, storyboards every shot, selects models, generates references and video, checks continuity, repairs failures and renders the final deliverables.</p>
       <textarea value={brief} onChange={e=>setBrief(e.target.value)} placeholder="Describe the film, commercial, social video, documentary or story you want…" className="mt-7 w-full min-h-44 rounded-2xl bg-[#f7f7f8] p-5 text-sm outline-none resize-none border border-black/5 focus:border-black/20"/>
       <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"><span className="text-xs text-black/40">{status}</span><button disabled={running||!brief.trim()} onClick={create} className="px-6 py-3 rounded-xl bg-black text-white text-sm disabled:opacity-30">{running?"Planning production…":"Create production"}</button></div>
      </div>
      <div className="space-y-4">
       <div className="bg-white rounded-[28px] border border-black/5 p-6"><div className="flex justify-between mb-5"><span className="font-medium">Autonomous pipeline</span><span className="text-[10px] uppercase tracking-widest text-black/30">LIVE</span></div>{stages.map((x,i)=><div key={x} className="flex items-center gap-3 py-2.5 text-sm"><div className={`w-2 h-2 rounded-full ${i===0?"bg-black":"bg-black/10"}`}/><span>{x}</span><span className="ml-auto text-[10px] text-black/25">{i===0?"READY":"AUTO"}</span></div>)}</div>
       <div className="bg-white rounded-[28px] border border-black/5 p-6"><div className="font-medium mb-4">Intelligent model routing</div>{models.map(m=><div key={m[0]} className="flex items-center justify-between py-2.5 text-xs border-b last:border-0 border-black/5"><span>{m[0]}</span><span className="text-black/35">{m[1]} · {m[2]}</span></div>)}</div>
      </div>
     </div>
    </div>
   </section>
  </div>
 </main>
