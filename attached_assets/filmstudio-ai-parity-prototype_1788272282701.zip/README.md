# FilmStudio AI — End-to-End Agent + Editor Build

This release adds the **brain layer** and the **feature layer** to the existing app.

## Brain

The agent now has explicit contracts for:

1. Intent classification
2. Brief understanding
3. Script planning
4. Storyboard / shot planning
5. Asset planning
6. Provider routing
7. Generation
8. Audio
9. Timeline assembly
10. Captions
11. QA
12. Automatic revision
13. Render/export

`lib/brain.ts` is the orchestration kernel. It is intentionally provider-agnostic.

## Feature layer

The UI/API surface now exposes:

- projects
- agent planning
- agent runs
- generation
- provider status
- timeline/editor state
- assets
- captions
- brand/template concepts
- render/export concepts
- feature workspace

## Real production deployment

For a real SaaS launch, replace the local JSON store with Postgres, add object storage, Redis/queue workers, FFmpeg/render workers, authentication, billing, webhook handling, moderation, rate limits and model-specific FAL/Replicate/Vast adapters.

The current code does not pretend those external credentials or infrastructure exist. Configure them through `.env`.
